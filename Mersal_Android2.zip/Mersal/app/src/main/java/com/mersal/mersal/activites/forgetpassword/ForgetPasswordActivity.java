package com.mersal.mersal.activites.forgetpassword;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.mersal.mersal.R;
import com.mersal.mersal.activites.auth.OtpVerificationActivity;
import com.mersal.mersal.activites.base.BaseActivity;
import com.mersal.mersal.activites.resetpassword.ResetPasswordActivity;
import com.mersal.mersal.activites.resetpassword.ResetPasswordByPhoneActivity;
import com.mersal.mersal.customviews.HeaderCustomTV;
import com.mersal.mersal.customviews.NoDataFoundCustomTV;
import com.mersal.mersal.generic.Interfaces.Generic;
import com.mersal.mersal.internetconnections.NetworkConnection;
import com.mersal.mersal.retrofit.baseapi.ApiService;
import com.mersal.mersal.retrofit.baseapi.AppWebServices;
import com.mersal.mersal.retrofit.defualt.DefaultResult;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Map;
import java.util.Random;

import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ForgetPasswordActivity extends BaseActivity {

    TextView tv_submit;
    RelativeLayout rl_submit, rl_body, header_left_rl;
    String st_email = "";
    EditText et_email;
    EditText et_phone;
    ProgressBar progressBar;
    NoDataFoundCustomTV tv_noresult;
    public static ForgetPasswordActivity objForgetPasswordActivity;
    NetworkConnection ntobj = new NetworkConnection(ForgetPasswordActivity.this);
    Generic generic;
    ImageView back_arrow;
    HeaderCustomTV toolbar_title;
    RadioButton radioPhone;
    RadioButton radioEmail;
    int random_numbers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_password);
        if (ForgetPasswordActivity.this instanceof BaseActivity) {
            generic = (Generic) ForgetPasswordActivity.this;
        }
        generic.hideStatusBarForAuth();
        objForgetPasswordActivity = this;

        init();
        clickListener();
        objectBAJava.hideKeyboard();
    }

    public void init() {
        header_left_rl = (RelativeLayout) findViewById(R.id.header_left_rl);
        tv_submit = (TextView) findViewById(R.id.tv_submit);
        rl_submit = (RelativeLayout) findViewById(R.id.rl_submit);
        rl_body = (RelativeLayout) findViewById(R.id.rl_body);
        et_email = (EditText) findViewById(R.id.et_email);
        et_phone = (EditText) findViewById(R.id.et_phone);
        et_email.setTypeface(objectBAJava.Tahoma_Regular_font);
        et_phone.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_submit.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_noresult = (NoDataFoundCustomTV) findViewById(R.id.tv_noresult);

        toolbar_title = (HeaderCustomTV) findViewById(R.id.toolbar_title);
        back_arrow = (ImageView) findViewById(R.id.back_arrow);
        toolbar_title.setText("هل نسيت كلمة المرور");
        back_arrow.setVisibility(View.VISIBLE);

        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        progressBar.setVisibility(View.GONE);
        radioPhone = (RadioButton) findViewById(R.id.radio_phone);
        radioEmail = (RadioButton) findViewById(R.id.radio_email);
        et_email.setEnabled(false);

        radioPhone.setOnCheckedChangeListener(new RadioButton.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b){
                    radioEmail.setChecked(false);
                    et_phone.setEnabled(true);
                    et_email.setEnabled(false);
                }
            }
        });

        radioEmail.setOnCheckedChangeListener(new RadioButton.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b){
                    radioPhone.setChecked(false);
                    et_phone.setEnabled(false);
                    et_email.setEnabled(true);
                }
            }
        });
        radioPhone.setChecked(true);
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT) {
            progressBar.getIndeterminateDrawable().setColorFilter(getResources()
                    .getColor(R.color.progress_bar_color_white), PorterDuff.Mode.SRC_IN);
        }
    }

    public void clickListener() {
        rl_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                velidation();
            }
        });

        header_left_rl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                objectBAJava.hideStatusBar();
                finish();
                generic.animEnd();
            }
        });
    }

    public void velidation() {

        if(radioPhone.isChecked()){

            if(!et_phone.getText().toString().isEmpty()){
                velidationForPhone();
            }
        }
        else {

            st_email = et_email.getText().toString();

            if (st_email.trim().equals("")) {
                et_email.requestFocus();
                et_email.setError("البريد الإلكتروني مطلوب");
            } else if (!st_email.contains("@") || !st_email.contains(".")) {
                et_email.requestFocus();
                et_email.setError("البريد الإلكتروني صالح مطلوب");
            } else {
                if (ntobj.isConnectingToInternet()) {
                    objectBAJava.hideKeyboard();
                    callApiFirsttime();

                } else {
                    String Message = PreferenceManager.getDefaultSharedPreferences(ForgetPasswordActivity.this).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
                    generic.showSnackbar(rl_body, Message, Snackbar.LENGTH_LONG, "close", false);
                }
            }
        }
    }

    public void apiforgetPasswords() {
//        reqIsInProgress = true;
        generic.showProgressBar(progressBar);
        Map<String, String> params = generic.setBasicParams();
        params.put("email", st_email);
//        params.put("page_no", String.valueOf(page));
//        params.put("order", "asc");
//        params.put("order_by", "date");
//        params.put("keyword", "");


        OkHttpClient client = generic.setHeaderForReqs().build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(AppWebServices.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();

        ApiService service = retrofit.create(ApiService.class);
        Call<DefaultResult> call = service.forgetpassword(params);
        call.enqueue(new Callback<DefaultResult>() {

            @Override
            public void onResponse(Call<DefaultResult> call, retrofit2.Response<DefaultResult> response) {

                if (response.code() == 200) {

                    Boolean status = response.body().getstatus();
                    String Message = response.body().getMessage();

                    if (status) {

                        generic.hideProgressBar(progressBar);


                        AlertDialog alert = new AlertDialog.Builder(ForgetPasswordActivity.this)
                                .create();
                        alert.setMessage(Message);
                        alert.setButton(DialogInterface.BUTTON_POSITIVE, "موافق", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {

                                dialog.dismiss();
                                Intent intent = new Intent(ForgetPasswordActivity.this, ResetPasswordActivity.class);
                                startActivity(intent);
                                animStart();
                            }
                        });
                        alert.setButton(DialogInterface.BUTTON_NEGATIVE, "الغاء", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {

                                dialog.dismiss();
                                Intent intent = new Intent(ForgetPasswordActivity.this, ResetPasswordActivity.class);
                                startActivity(intent);
                                animStart();
                            }
                        });
                        alert.show();

                    } else {
                        generic.hideProgressBar(progressBar);

//                        tv_noresult.setVisibility(View.VISIBLE);
//                        Snackbar snackbar = Snackbar.make(rl_body, Message, Snackbar.LENGTH_LONG);
//                        snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
//                        snackbar.show();
                    }

                } else {
                    generic.hideProgressBar(progressBar);
                    try {

                        generic.hideProgressBar(progressBar);

                        String userMessage = PreferenceManager.getDefaultSharedPreferences(ForgetPasswordActivity.this).getString("oops", "هناك خطأ ما");
                        JSONObject jObjError = new JSONObject(response.errorBody().string());
                        try {
                            userMessage = jObjError.getString("message");
                        } catch (Exception e) {
                        }

                        String dataArrayMessage = "";
                        try {
                            JSONArray jsonArray = jObjError.getJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                dataArrayMessage = dataArrayMessage + jsonArray.getString(i) + "\n";
                            }

                        } catch (Exception e) {
                        }


                        String maintenanceBtnText = "Try Again";
                        try {
                            maintenanceBtnText = jObjError.optString("btn_text");
                        } catch (Exception e) {
                        }

                        generic.genericCodes(rl_body, response.code(), userMessage, dataArrayMessage, maintenanceBtnText);

                    } catch (Exception e) {

                        generic.hideProgressBar(progressBar);

//                        Snackbar snackbar = Snackbar.make(rl_body, PreferenceManager.getDefaultSharedPreferences(ForgetPasswordActivity.this).getString("oops", "هناك خطأ ما"), Snackbar.LENGTH_LONG);
//                        snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
//                        snackbar.show();

                    }
                }
            }

            @Override
            public void onFailure(Call<DefaultResult> call, Throwable t) {
//                progressBar.setVisibility(View.GONE);
                generic.hideProgressBar(progressBar);

                Snackbar snackbar = Snackbar.make(rl_body, PreferenceManager.getDefaultSharedPreferences(ForgetPasswordActivity.this).getString("oops", "هناك خطأ ما"), Snackbar.LENGTH_LONG);
                snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
                snackbar.show();
            }
        });
    }

    public void velidationForPhone() {

        String st_ph = et_phone.getText().toString();
        if (st_ph.trim().equals("")) {
            et_phone.setError("رقم الهاتف مطلوب");
            et_phone.requestFocus();
        } else {
            if (ntobj.isConnectingToInternet()) {
                hideKeyboard();
                apiCheckPhonenumber();
            } else {
                String Message = PreferenceManager.getDefaultSharedPreferences(ForgetPasswordActivity.this).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
                generic.showSnackbar(rl_body, Message, Snackbar.LENGTH_LONG, "close", false);
            }
        }
    }

    public void apiCheckPhonenumber() {
        generic.showProgressBar(progressBar);
        Map<String, String> params = generic.setBasicParams();
        params.put("phone", et_phone.getText().toString());
        OkHttpClient client = generic.setHeaderForReqs().build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(AppWebServices.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();
        ApiService service = retrofit.create(ApiService.class);
        Call<DefaultResult> call = service.phonenumber(params);
        call.enqueue(new Callback<DefaultResult>() {

            @Override
            public void onResponse(Call<DefaultResult> call, retrofit2.Response<DefaultResult> response) {
                if (response.code() == 200) {

                    Boolean status = response.body().getstatus();
                    String Message = response.body().getMessage();

                    if (status) {
                        generic.hideProgressBar(progressBar);
                        hideKeyboard();
//                        Intent intent = new Intent(SignUpPreActivity.this, SignUpActivity.class);
//                        intent.putExtra("fname", st_fname);
//                        intent.putExtra("sname", st_sname);
//                        intent.putExtra("familyname", st_familyname);
//                        intent.putExtra("iddob", st_dob);
//                        intent.putExtra("ph", st_ph);
//                        intent.putExtra("gender", st_gender);
//                        intent.putExtra("Blood", st_blood);
//                        intent.putExtra("idname", id_name);
//                        intent.putExtra("id_number", civil_number);
//                        intent.putExtra("expiry_date", expiry_date);
//                        intent.putExtra("id_front", docimageencode_FRONT);
//                        intent.putExtra("id_back", docimageencode_BACK);

                        generic.hideProgressBar(progressBar);
                        Snackbar snackbar = Snackbar.make(rl_body, "رقم الهاتف غير موجود!", Snackbar.LENGTH_LONG);
                        snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
                        snackbar.show();


                    } else {
                        callOTPSendSmsAPI();
//                        generic.hideProgressBar(progressBar);
//                        Snackbar snackbar = Snackbar.make(rl_body, Message, Snackbar.LENGTH_LONG);
//                        snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
//                        snackbar.show();
                    }

                } else {
                    generic.hideProgressBar(progressBar);
                    try {

                        generic.hideProgressBar(progressBar);
                        String userMessage = PreferenceManager.getDefaultSharedPreferences(ForgetPasswordActivity.this).getString("oops", "هناك خطأ ما");
                        JSONObject jObjError = new JSONObject(response.errorBody().string());
                        try {
                            userMessage = jObjError.getString("message");
                        } catch (Exception e) {
                        }

                        String dataArrayMessage = "";
                        try {
                            JSONArray jsonArray = jObjError.getJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                dataArrayMessage = dataArrayMessage + jsonArray.getString(i) + "\n";
                            }

                        } catch (Exception e) {
                        }


                        String maintenanceBtnText = "Try Again";
                        try {
                            maintenanceBtnText = jObjError.optString("btn_text");
                        } catch (Exception e) {
                        }

                        generic.genericCodes(rl_body, response.code(), userMessage, dataArrayMessage, maintenanceBtnText);

                    } catch (Exception e) {

                        generic.hideProgressBar(progressBar);
                        Snackbar snackbar = Snackbar.make(rl_body, PreferenceManager.getDefaultSharedPreferences(ForgetPasswordActivity.this).getString("oops", "هناك خطأ ما"), Snackbar.LENGTH_LONG);
                        snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
                        snackbar.show();

                    }
                }
            }

            @Override
            public void onFailure(Call<DefaultResult> call, Throwable t) {
                generic.hideProgressBar(progressBar);
                Snackbar snackbar = Snackbar.make(rl_body, PreferenceManager.getDefaultSharedPreferences(ForgetPasswordActivity.this).getString("oops", "هناك خطأ ما"), Snackbar.LENGTH_LONG);
                snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
                snackbar.show();
            }
        });
    }

    public void callOTPSendSmsAPI() {

        if (ntobj.isConnectingToInternet()) {
//            rl_body.setVisibility(View.GONE);
            generic.showProgressBar(progressBar);
            tv_noresult.setVisibility(View.GONE);
//            Random r = new Random();
//            random_numbers = r.nextInt(8020 - 6215) + 6431;
            try {
                random_numbers = Integer.parseInt(getRandomNumberString());
            } catch (Exception e) {
            }
            System.out.println("here is otp code : " + random_numbers);
            apiOTPSendCode();
        } else {
//            rl_body.setVisibility(View.GONE);
            tv_noresult.setVisibility(View.VISIBLE);
            generic.hideProgressBar(progressBar);
            String Message = PreferenceManager.getDefaultSharedPreferences(ForgetPasswordActivity.this).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
            generic.showSnackbar(rl_body, Message, Snackbar.LENGTH_LONG, "close", false);
        }
    }

    public static String getRandomNumberString() {
        // It will generate 6 digit random Number.
        // from 0 to 999999
        Random rnd = new Random();
        int number = rnd.nextInt(999999);

        // this will convert any number sequence into 6 character.
        return String.format("%06d", number);
    }

    public void apiOTPSendCode() {
        generic.showProgressBar(progressBar);
        Map<String, String> params = generic.setBasicParams();
//        params.put("UserId", "lawati_webser");
//        params.put("Password", "Lawati@789");
        params.put("UserId", "lawatimrsal_ws");
        params.put("Password", "Lawatim@789");
        params.put("MobileNo", et_phone.getText().toString());
        params.put("Message", "رمز إعادة تعيين كلمة المرور لتطبيق لواتي مرسال هو" + random_numbers);

        params.put("Lang", String.valueOf(64));

//        https://www.ismartsms.net/iBulkSMS/HttpWS/SMSDynamicAPI.aspx?UserId=lawati_webser&Password=Lawati@789&MobileNo=96892985363&Message=TestMessage&Lang=0

        OkHttpClient client = generic.setHeaderForReqs().build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(AppWebServices.BASE_URL_FOR_OTP)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();
        ApiService service = retrofit.create(ApiService.class);
        Call<String> call = service.OTP(params);
        call.enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, retrofit2.Response<String> response) {

                generic.hideProgressBar(progressBar);
//                rl_body.setVisibility(View.GONE);
//                tv_noresult.setVisibility(View.GONE);

                int num = Integer.parseInt(response.body());
                if (num == 1) {

                    generic.showSnackbar(progressBar, " لقد تم إرسال الرمز إلى الرقم " + et_phone.getText().toString(), Snackbar.LENGTH_LONG, "close", true);

                    AlertDialog alert = new AlertDialog.Builder(ForgetPasswordActivity.this)
                            .create();
                    alert.setMessage(" لقد تم إرسال الرمز إلى الرقم");
                    alert.setButton(DialogInterface.BUTTON_POSITIVE, "موافق", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {

                            dialog.dismiss();
                            Intent intent = new Intent(ForgetPasswordActivity.this, ResetPasswordByPhoneActivity.class);
                            intent.putExtra("code", String.valueOf(random_numbers));
                            startActivity(intent);
                            animStart();
                            finish();
                        }
                    });
                    alert.setButton(DialogInterface.BUTTON_NEGATIVE, "الغاء", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {

                            dialog.dismiss();
                            Intent intent = new Intent(ForgetPasswordActivity.this, ResetPasswordByPhoneActivity.class);
                            intent.putExtra("code", String.valueOf(random_numbers));
                            startActivity(intent);
                            animStart();
                            finish();
                        }
                    });
                    alert.show();


                } else if (num == 9) {
//                    tv_noresult.setVisibility(View.VISIBLE);
//                    tv_noresult.setText(st_ph + " رقم الجوال غير صالح ");
                    generic.showSnackbar(progressBar, " رقم الجوال غير صالح " + et_phone.getText().toString(), Snackbar.LENGTH_LONG, "close", false);

                } else {

//                    tv_noresult.setVisibility(View.VISIBLE);
//                    tv_noresult.setText("خطأ غير معروف");
                    generic.showSnackbar(progressBar, "خطأ غير معروف ", Snackbar.LENGTH_LONG, "close", false);

                }

//                if (response.code() == 200) {
//
//
//
//                }  else {
//
//                    try {
//
//                        String userMessage = PreferenceManager.getDefaultSharedPreferences(OtpVerificationActivity.this).getString("oops", "هناك خطأ ما");
//                        JSONObject jObjError = new JSONObject(response.errorBody().string());
//                        try {
//                            userMessage = jObjError.getString("message");
//                        } catch (Exception e) {
//                        }
//
//                        String dataArrayMessage = "";
//                        try {
//                            JSONArray jsonArray = jObjError.getJSONArray("LoginResultdata");
//                            for (int i = 0; i < jsonArray.length(); i++) {
//                                dataArrayMessage = dataArrayMessage + jsonArray.getString(i) + "\n";
//                            }
//
//                        } catch (Exception e) {
//                        }
//
//                        String maintenanceBtnText = "Try Again";
//                        try {
//                            maintenanceBtnText = jObjError.optString("btn_text");
//                        } catch (Exception e) {
//                        }
//                        generic.genericCodes(rl_body, response.code(), userMessage, dataArrayMessage, maintenanceBtnText);
//                    } catch (Exception e) {
//
//                        generic.showSnackbar(progressBar, "هناك خطأ ما", Snackbar.LENGTH_LONG, "close", false);
//
//                    }
//                }
            }

            @Override
            public void onFailure(Call<String> call, Throwable t) {
//                tv_noresult.setVisibility(View.VISIBLE);
                generic.hideProgressBar(progressBar);
                generic.showSnackbar(progressBar, "هناك خطأ ما", Snackbar.LENGTH_LONG, "close", false);

            }
        });
    }



    public void callApiFirsttime() {

        if (ntobj.isConnectingToInternet()) {
            objectBAJava.hideKeyboard();
            generic.showProgressBar(progressBar);
            apiforgetPasswords();
        } else {
            String Message = PreferenceManager.getDefaultSharedPreferences(ForgetPasswordActivity.this).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
            generic.showSnackbar(tv_noresult, Message, Snackbar.LENGTH_LONG, "close", false);
            generic.hideProgressBar(progressBar);
        }
    }
}
