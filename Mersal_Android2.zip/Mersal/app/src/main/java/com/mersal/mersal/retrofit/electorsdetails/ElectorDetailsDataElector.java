package com.mersal.mersal.retrofit.electorsdetails;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Muhammad_Umar_Ch on 07/12/2017.
 */

public class ElectorDetailsDataElector {

    @SerializedName("full_name")
    private String full_name;
    @SerializedName("id")
    private String id = "";
    @SerializedName("short_description")
    private String short_description = "";
    @SerializedName("more_detail")
    private String more_detail = "";
    @SerializedName("image_url")
    private String image_url;


    public String getimage_url() {
        if (image_url == null || image_url.equals("")) {
            return "https://";
        }
        return image_url;
    }

    public String getfull_name() {
        if (full_name == null) {
            return "";
        }
        return full_name;
    }

    public String getid() {

        if (id == null) {
            return "";
        }
        return id;
    }

    public String getshort_description() {
        if (short_description == null) {
            return "";
        }
        return short_description;
    }

    public String getmore_detail() {
        if (more_detail == null) {
            return "";
        }
        return more_detail;
    }

}
