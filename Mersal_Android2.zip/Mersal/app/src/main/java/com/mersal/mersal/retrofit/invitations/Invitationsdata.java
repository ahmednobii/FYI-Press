package com.mersal.mersal.retrofit.invitations;

import com.google.gson.annotations.SerializedName;
import com.mersal.mersal.retrofit.electorsdetails.ElectorDetailsDataElector;

import java.util.ArrayList;

/**
 * Created by Muhammad_Umar_Ch on 07/12/2017.
 */

public class Invitationsdata {

    @SerializedName("invitations")
    private ArrayList<InvitationsDataInvitations> invitations;

    public ArrayList<InvitationsDataInvitations> getinvitations() {
        return invitations;
    }

    @SerializedName("services")
    private ArrayList<invitationsServices> services;

    public ArrayList<invitationsServices> getservices() {
        return services;
    }


}
