package com.mersal.mersal.activites.auth;

import android.content.Intent;
import android.graphics.PorterDuff;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.Snackbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mersal.mersal.R;
import com.mersal.mersal.activites.base.BaseActivity;
import com.mersal.mersal.activites.dashboard.DashboardActivity;
import com.mersal.mersal.adapter.FeaturesLvAdapter;
import com.mersal.mersal.customviews.HeaderCustomTV;
import com.mersal.mersal.customviews.NoDataFoundCustomTV;
import com.mersal.mersal.generic.Interfaces.Generic;
import com.mersal.mersal.internetconnections.NetworkConnection;
import com.mersal.mersal.realm.UserInformation;
import com.mersal.mersal.retrofit.baseapi.ApiService;
import com.mersal.mersal.retrofit.baseapi.AppWebServices;
import com.mersal.mersal.retrofit.defualt.DefaultResult;
import com.mersal.mersal.retrofit.services.ServicesResult;
import com.mersal.mersal.retrofit.services.ServicesdataServices;
import com.mersal.mersal.utilties.StaticStrings;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Map;

import io.realm.Realm;
import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static com.mersal.mersal.activites.auth.OtpVerificationActivity.OtpVerificationActivityObject;
import static com.mersal.mersal.activites.auth.SignUpActivity.SignUpActivityObject;
import static com.mersal.mersal.activites.auth.SignUpPreActivity.SignUpPreActivityObject;
import static com.mersal.mersal.activites.auth.SigninActivity.objsigninActivityObject;
import static com.mersal.mersal.activites.auth.SignupIdScanActivity.ObjSignupIdScanActivity;
import static com.mersal.mersal.utilties.StaticStrings.ISFROMFEDITPROFILE;

public class FeaturesActivity extends BaseActivity {

    TextView tv_question, tv_submit;
    RelativeLayout rl_submit, rl_body, header_left_rl;
    ListView lv_propsel;
    ProgressBar progressBar;
    NoDataFoundCustomTV tv_noresult;
    public static FeaturesActivity featuresActivity;
    NetworkConnection ntobj = new NetworkConnection(FeaturesActivity.this);
    Generic generic;
    ImageView back_arrow;
    HeaderCustomTV toolbar_title;
    //    String st_sname = "", st_familyname = "", st_fname = "", st_email = "", st_gender = "", st_dob = "", st_ph = "", st_blood = "", st_code = "";
//    String st_username, st_pwd = "";
    ArrayList<ServicesdataServices> activitiesDataArray = new ArrayList<>();
    FeaturesLvAdapter adapter;
    Boolean isArraySelected = false;
    public static JSONArray mArray = new JSONArray();
    ArrayList<ServicesdataServices> servicesdataServices = new ArrayList<>();
    Realm realm;
    public ArrayList<UserInformation> userProfile = new ArrayList<>();
    public ArrayList<ServicesdataServices> arrayListEditProfileServices = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_features);

        if (FeaturesActivity.this instanceof BaseActivity) {
            generic = (Generic) FeaturesActivity.this;
        }

        generic.hideStatusBarForAuth();
        featuresActivity = this;
        init();
        objectBAJava.hideKeyboard();
//        Bundle extras = getIntent().getExtras();
//        if (extras != null) {
//            st_fname = extras.getString("fname");
//            st_sname = extras.getString("sname");
//            st_familyname = extras.getString("familyname");
//            st_dob = extras.getString("dob");
//            st_ph = extras.getString("ph");
//            st_gender = extras.getString("gender");
//            st_blood = extras.getString("Blood");
//            st_username = extras.getString("username");
//            st_pwd = extras.getString("password");
//            st_code = extras.getString("code");
//            st_email = extras.getString("email");
//        }
        clickListener();
    }

    public void init() {
        StaticStrings.ISFROMFEATURES = true;
        header_left_rl = (RelativeLayout) findViewById(R.id.header_left_rl);
        lv_propsel = (ListView) findViewById(R.id.lv_propsel);
        tv_question = (TextView) findViewById(R.id.tv_question);
        tv_submit = (TextView) findViewById(R.id.tv_submit);
        rl_submit = (RelativeLayout) findViewById(R.id.rl_submit);
        rl_body = (RelativeLayout) findViewById(R.id.rl_body);
        tv_question.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_submit.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_noresult = (NoDataFoundCustomTV) findViewById(R.id.tv_noresult);
        toolbar_title = (HeaderCustomTV) findViewById(R.id.toolbar_title);
        back_arrow = (ImageView) findViewById(R.id.back_arrow);
        toolbar_title.setText("الخدمات");
        back_arrow.setVisibility(View.VISIBLE);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        progressBar.setVisibility(View.GONE);

        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT) {
            progressBar.getIndeterminateDrawable().setColorFilter(getResources()
                    .getColor(R.color.progress_bar_color_white), PorterDuff.Mode.SRC_IN);
        }
//        for (int i = 0; i < 4; i++) {
//            if (i == 0) {
//
//                FeaturesResult objfeaturesresult = new FeaturesResult();
//                objfeaturesresult.setstatus(false);
//                objfeaturesresult.setdetails("تصويت");
//                activitiesDataArray.add(objfeaturesresult);
//            }
//            if (i == 1) {
//
//                FeaturesResult objfeaturesresult = new FeaturesResult();
//                objfeaturesresult.setstatus(false);
//                objfeaturesresult.setdetails("دعوات حفل الزفاف");
//                activitiesDataArray.add(objfeaturesresult);
//            }
//
//            if (i == 2) {
//                FeaturesResult objfeaturesresult = new FeaturesResult();
//                objfeaturesresult.setstatus(false);
//                objfeaturesresult.setdetails("تلقي رسائل إقطاعية");
//                activitiesDataArray.add(objfeaturesresult);
//
//            }
//
//            if (i == 3) {
//
//                FeaturesResult objfeaturesresult = new FeaturesResult();
//                objfeaturesresult.setstatus(false);
//                objfeaturesresult.setdetails("تلقي كل شيء");
//                activitiesDataArray.add(objfeaturesresult);
//            }
//
//        }

        if (ntobj.isConnectingToInternet()) {
            objectBAJava.hideKeyboard();
            generic.showProgressBar(progressBar);
            apiGetServices();

        } else {
            String Message = PreferenceManager.getDefaultSharedPreferences(FeaturesActivity.this).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
            generic.showSnackbar(rl_body, Message, Snackbar.LENGTH_LONG, "close", false);
        }

        Realm.init(this);    //initialize to access database for this activity
        realm = Realm.getDefaultInstance();

        PreferenceManager.getDefaultSharedPreferences(objectBAJava).edit().putBoolean("isDevicetockensend", false).apply();
    }

    public void clickListener() {

        back_arrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                objectBAJava.hideStatusBar();
                finish();
                generic.animEnd();
            }
        });

        rl_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (ntobj.isConnectingToInternet()) {
                    objectBAJava.hideKeyboard();
                    velidation();

                } else {
                    String Message = PreferenceManager.getDefaultSharedPreferences(FeaturesActivity.this).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
                    generic.showSnackbar(rl_body, Message, Snackbar.LENGTH_LONG, "close", false);
                }
            }
        });

    }

    public void velidation() {

        if (activitiesDataArray.size() > 0) {

            for (int i = 0; i < activitiesDataArray.size(); i++) {

                if (activitiesDataArray.get(i).getstatusinapp() || activitiesDataArray.get(i).getstatus().equals("1")) {

                    isArraySelected = true;
                }
            }
            if (isArraySelected) {

                apiSaveServices();

            } else {
                generic.showSnackbar(rl_body, "Select at least one service", Snackbar.LENGTH_LONG, "close", false);
            }
        } else {
            generic.showSnackbar(rl_body, "No data found", Snackbar.LENGTH_LONG, "close", false);
        }


    }

    public void updateArray(boolean status, int positions) {

        activitiesDataArray.get(positions).setstatusinapp(status);
        adapter.notifyDataSetChanged();

    }

    public void apiGetServices() {
        generic.showProgressBar(progressBar);
        Map<String, String> params = generic.setBasicParams();
        params.put("auth_token", generic.getAuthTockenFromDb());
        OkHttpClient client = setHeaderForReqsForSaveServices().build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(AppWebServices.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();
        ApiService service = retrofit.create(ApiService.class);
        Call<ServicesResult> call = service.services(params);
        call.enqueue(new Callback<ServicesResult>() {
            @Override
            public void onResponse(Call<ServicesResult> call, retrofit2.Response<ServicesResult> response) {
                generic.hideProgressBar(progressBar);
                int code = response.code();
                if (response.code() == 200) {
                    Boolean status = response.body().getstatus();
                    String message = response.body().getMessage();
                    if (status) {
                        if (response.body().getdata().getservicesdataServices().size() > 0) {

                            for (int i = 0; i < response.body().getdata().getservicesdataServices().size(); i++) {
                                ServicesdataServices servicesdataServicesobj = new ServicesdataServices();
                                servicesdataServicesobj = response.body().getdata().getservicesdataServices().get(i);
                                servicesdataServicesobj.setstatusinapp(false);
                                activitiesDataArray.add(servicesdataServicesobj);
                            }

                            if (response.body().getdata().getuser_services() != null) {

                                if (response.body().getdata().getuser_services().size() > 0) {

                                    for (int i = 0; i < response.body().getdata().getuser_services().size(); i++) {
                                        ServicesdataServices editProfileServices = new ServicesdataServices();
                                        editProfileServices = response.body().getdata().getuser_services().get(i);
                                        editProfileServices.setstatusinapp(true);
                                        arrayListEditProfileServices.add(editProfileServices);
                                    }
                                }
                            }

                            if (activitiesDataArray.size() > 0) {

                                if (arrayListEditProfileServices.size() > 0) {

                                    for (int i = 0; i < activitiesDataArray.size(); i++) {
                                        {

                                            for (int j = 0; j < arrayListEditProfileServices.size(); j++) {
                                                {
                                                    if (activitiesDataArray.get(i).getid().equals(arrayListEditProfileServices.get(j).getid())) {

                                                        activitiesDataArray.get(i).setstatusinapp(true);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                adapter = new FeaturesLvAdapter(FeaturesActivity.this, activitiesDataArray);
                                lv_propsel.setAdapter(adapter);
                            } else {
                                rl_body.setVisibility(View.GONE);
                                tv_noresult.setVisibility(View.VISIBLE);
                            }

                        } else {
                            rl_body.setVisibility(View.GONE);
                            tv_noresult.setVisibility(View.VISIBLE);
                        }

                    } else {
                        generic.showSnackbar(rl_body, message, Snackbar.LENGTH_LONG, "close", false);

                    }
                } else {
                    try {
                        String userMessage = PreferenceManager.getDefaultSharedPreferences(FeaturesActivity.this).getString("oops", "هناك خطأ ما");
                        JSONObject jObjError = new JSONObject(response.errorBody().string());
                        try {
                            userMessage = jObjError.getString("message");
                        } catch (Exception e) {
                        }

                        String dataArrayMessage = "";
                        try {
                            JSONArray jsonArray = jObjError.getJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                dataArrayMessage = dataArrayMessage + jsonArray.getString(i) + "\n";
                            }
                        } catch (Exception e) {
                        }
                        String maintenanceBtnText = "Try Again";
                        try {
                            maintenanceBtnText = jObjError.optString("btn_text");
                        } catch (Exception e) {
                        }
                        generic.genericCodes(rl_body, response.code(), userMessage, dataArrayMessage, maintenanceBtnText);
                    } catch (Exception e) {
                        generic.showSnackbar(progressBar, "هناك خطأ ما", Snackbar.LENGTH_LONG, "close", false);
                    }
                }
            }

            @Override
            public void onFailure(Call<ServicesResult> call, Throwable t) {
                generic.hideProgressBar(progressBar);
                generic.showSnackbar(progressBar, "هناك خطأ ما", Snackbar.LENGTH_LONG, "close", false);

            }
        });
    }

    public void apiSaveServices() {

        mArray = new JSONArray();
        for (int i = 0; i < activitiesDataArray.size(); i++) {
            if (activitiesDataArray.get(i).getstatusinapp() || activitiesDataArray.get(i).getstatus().equals("1")) {
                mArray.put(activitiesDataArray.get(i).getid());
            }
        }
        generic.showProgressBar(progressBar);
//        Map<String, String> params = generic.setBasicParams();
//        params.put("auth_token", generic.getAuthTockenFromDb());
        OkHttpClient client = setHeaderForReqsForSaveServices().build();
        Gson gson = new GsonBuilder()
                .setLenient()
                .create();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(AppWebServices.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .client(client)
                .build();
        ApiService service = retrofit.create(ApiService.class);
//        Call<ServicesResult> call = service.services();
        Call<DefaultResult> call = service.saveservicesForReg(generic.getAuthTockenFromDb(), mArray);
        System.out.println("manu " + mArray);
        call.enqueue(new Callback<DefaultResult>() {
            @Override
            public void onResponse(Call<DefaultResult> call, retrofit2.Response<DefaultResult> response) {
                generic.hideProgressBar(progressBar);
                int code = response.code();
                if (response.code() == 200) {
                    Boolean status = response.body().getstatus();
                    String message = response.body().getMessage();
                    if (status) {
                        if (ISFROMFEDITPROFILE) {
                            finish();
                            animEnd();
                        } else {
                            PreferenceManager.getDefaultSharedPreferences(FeaturesActivity.this).edit().putBoolean("servicesstatus", true).apply();
                            Intent g = new Intent(FeaturesActivity.this, DashboardActivity.class);
                            startActivity(g);
                            overridePendingTransition(R.anim.start_slide_in_left, R.anim.start_slide_out_left);
                            try {
                                objsigninActivityObject.finish();
                            } catch (Exception e) {
                            }
                            try {
                                ObjSignupIdScanActivity.finish();
                            } catch (Exception e) {
                            }
                            try {
                                SignUpPreActivityObject.finish();
                            } catch (Exception e) {
                            }
                            try {
                                SignUpActivityObject.finish();
                            } catch (Exception e) {
                            }
                            try {
                                OtpVerificationActivityObject.finish();
                            } catch (Exception e) {
                            }
                            finish();
                        }
                    } else {
                        generic.showSnackbar(rl_body, message, Snackbar.LENGTH_LONG, "close", false);
                    }
                } else {
                    try {
                        String userMessage = PreferenceManager.getDefaultSharedPreferences(FeaturesActivity.this).getString("oops", "هناك خطأ ما");
                        JSONObject jObjError = new JSONObject(response.errorBody().string());
                        try {
                            userMessage = jObjError.getString("message");
                        } catch (Exception e) {
                        }

                        String dataArrayMessage = "";
                        try {
                            JSONArray jsonArray = jObjError.getJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                dataArrayMessage = dataArrayMessage + jsonArray.getString(i) + "\n";
                            }
                        } catch (Exception e) {
                        }
                        String maintenanceBtnText = "Try Again";
                        try {
                            maintenanceBtnText = jObjError.optString("btn_text");
                        } catch (Exception e) {
                        }
                        generic.genericCodes(rl_body, response.code(), userMessage, dataArrayMessage, maintenanceBtnText);
                    } catch (Exception e) {
                        generic.showSnackbar(progressBar, "هناك خطأ ما", Snackbar.LENGTH_LONG, "close", false);
                    }
                }
            }

            @Override
            public void onFailure(Call<DefaultResult> call, Throwable t) {
                generic.hideProgressBar(progressBar);
                generic.showSnackbar(progressBar, "هناك خطأ ما", Snackbar.LENGTH_LONG, "close", false);

            }
        });
    }

    //    public void apiSignUp() {
//
//        generic.showProgressBar(progressBar);
////        Map<String, String> params = generic.setBasicParams();
////        System.out.println("its device token from sigin " + generic.getDeviceToken());
////        params.put("username", st_familyname);
////        params.put("first_name", st_fname);
////        params.put("last_name", st_sname);
////        params.put("phone", st_ph);
////        params.put("username", st_username);
////        params.put("password", st_pwd);
////        params.put("confirm_password", st_pwd);
////        params.put("gender", st_gender);
////        params.put("blood_group", st_blood);
////        params.put("services", st_blood);
//
//        mArray = new ArrayList<>();
//        for (int i = 0; i < activitiesDataArray.size(); i++) {
//
//            if (activitiesDataArray.get(i).getstatusinapp()) {
//                mArray.add(activitiesDataArray.get(i).getid());
//            }
//        }
//
//        OkHttpClient client = generic.setHeaderForReqs().build();
//        Retrofit retrofit = new Retrofit.Builder()
//                .baseUrl(AppWebServices.BASE_URL)
//                .addConverterFactory(GsonConverterFactory.create())
//                .client(client)
//                .build();
//        ApiService service = retrofit.create(ApiService.class);
////        Call<DefaultResult> call = service.register(params);
//
//        Call<SignUpResult> call = service.register(st_username, st_fname, st_sname, st_ph, st_pwd,
//                st_pwd, st_gender, st_blood, st_familyname, st_dob, st_email, mArray,
//                StaticStrings.DEVICE_TYPE.toString(), Build.MODEL, Build.VERSION.RELEASE);
//
//        System.out.println("here is something wrong " + mArray);
//
//        call.enqueue(new Callback<SignUpResult>() {
//            @Override
//            public void onResponse(Call<SignUpResult> call, retrofit2.Response<SignUpResult> response) {
//
//                generic.hideProgressBar(progressBar);
//                int code = response.code();
//                if (response.code() == 200) {
//                    Boolean status = response.body().getstatus();
//                    String message = response.body().getMessage();
//
//                    if (status) {
////                        generic.showSnackbar(rl_body, message, Snackbar.LENGTH_LONG, "close", true);
//
//                        try {
//                            SignUpPreActivityObject.finish();
//                        } catch (Exception e) {
//                        }
//                        try {
//                            SignUpActivityObject.finish();
//                        } catch (Exception e) {
//
//                        }
//                        try {
//                            OtpVerificationActivityObject.finish();
//                        } catch (Exception e) {
//
//                        }
//                        userProfile.clear();
//                        SignUpdata data = response.body().getdata();
//                        UserInformation object = new UserInformation();
//                        object.setemail(data.getEmail());
//                        object.setaddress(data.getaddress());
//                        object.setauthtocken(data.getauth_token());
//                        object.setdob(data.getdob());
//                        object.setgender(data.getgender());
//                        object.setpassword(st_pwd);
//                        object.setName(data.getuser_name());
//                        object.setuserid(data.getuser_id());
//                        object.setId(1);
//                        object.setis_vendor(data.getisvendor());
//                        addDataintoUserinfo(object);
//                        userProfile.add(object);
//                        PreferenceManager.getDefaultSharedPreferences(FeaturesActivity.this).edit().putString("username", data.getuser_name()).apply();
//                        PreferenceManager.getDefaultSharedPreferences(FeaturesActivity.this).edit().putString("documentstatus", data.getdocument_status()).apply();
//                        PreferenceManager.getDefaultSharedPreferences(FeaturesActivity.this).edit().putBoolean("firstTimeLogin", true).apply();
//                        Intent g = new Intent(FeaturesActivity.this, DashboardActivity.class);
//                        startActivity(g);
//                        finish();
//                        overridePendingTransition(R.anim.start_slide_in_left, R.anim.start_slide_out_left);
//
//                    } else {
//
//                        generic.showSnackbar(rl_body, message, Snackbar.LENGTH_LONG, "close", false);
//
//                    }
//                } else if (response.code() == 401) {
//                    try {
//                        RealmResults<UserInformation> results = getDataintoUserinfo();
//                        if (results.size() > 0) {
//                            deleteUserinfo();
//                            PreferenceManager.getDefaultSharedPreferences(FeaturesActivity.this).edit().putBoolean("firstTimeLogin", false).apply();
//                        }
//                        String userMessage = PreferenceManager.getDefaultSharedPreferences(FeaturesActivity.this).getString("oops", "هناك خطأ ما");
//                        try {
//
////                            String dataArrayMessage = "";
////                            try {
////                                ArrayList<String> message = response.body().getmessage();
////                                for (int i = 0; i < message.size(); i++) {
////                                    dataArrayMessage = dataArrayMessage + message.get(i) + "\n";
////                                }
////
////                            } catch (Exception e) {
////                            }
//
//                            JSONObject jObjError = new JSONObject(response.errorBody().string());
//                            String errorMessage = jObjError.getString("message");
////                            errorMessage = response.body().getMessage();
//                            if (errorMessage != null && !errorMessage.equals("")) {
//                                userMessage = errorMessage;
//                            }
//                        } catch (Exception e) {
//                        }
//                        String OK = PreferenceManager.getDefaultSharedPreferences(FeaturesActivity.this).getString("ok", "موافق");
//                        AlertDialog alert = new AlertDialog.Builder(FeaturesActivity.this)
//                                .create();
//                        alert.setMessage(userMessage);
//                        alert.setButton(DialogInterface.BUTTON_POSITIVE, OK, new DialogInterface.OnClickListener() {
//                            public void onClick(DialogInterface dialog, int which) {
//
//                                dialog.dismiss();
//
//                            }
//                        });
//                        alert.show();
//
//                    } catch (Exception e) {
//
//                        String userMessage = PreferenceManager.getDefaultSharedPreferences(FeaturesActivity.this).getString("oops", "هناك خطأ ما");
//                        showSnackbar(rl_body, userMessage, Snackbar.LENGTH_LONG, "close", false);
//                    }
//
//                } else {
//
//                    try {
//
//                        String userMessage = PreferenceManager.getDefaultSharedPreferences(FeaturesActivity.this).getString("oops", "هناك خطأ ما");
//                        JSONObject jObjError = new JSONObject(response.errorBody().string());
//                        try {
//                            userMessage = jObjError.getString("message");
//                        } catch (Exception e) {
//                        }
//
//                        String dataArrayMessage = "";
//                        try {
//                            JSONArray jsonArray = jObjError.getJSONArray("data");
//                            for (int i = 0; i < jsonArray.length(); i++) {
//                                dataArrayMessage = dataArrayMessage + jsonArray.getString(i) + "\n";
//                            }
//
//                        } catch (Exception e) {
//                        }
//
//                        String maintenanceBtnText = "Try Again";
//                        try {
//                            maintenanceBtnText = jObjError.optString("btn_text");
//                        } catch (Exception e) {
//                        }
//                        generic.genericCodes(rl_body, response.code(), userMessage, dataArrayMessage, maintenanceBtnText);
//                    } catch (Exception e) {
//
//                        generic.showSnackbar(progressBar, "هناك خطأ ما", Snackbar.LENGTH_LONG, "close", false);
//
//                    }
//
//
//                }
//            }
//
//            @Override
//            public void onFailure(Call<SignUpResult> call, Throwable t) {
//
//                generic.hideProgressBar(progressBar);
//                generic.showSnackbar(progressBar, "هناك خطأ ما", Snackbar.LENGTH_LONG, "close", false);
//
//            }
//        });
//    }

//    public RealmResults<UserInformation> getDataintoUserinfo(String user_id) {
//        realm.beginTransaction();  //open the database
//        RealmResults<UserInformation> results = realm.where(UserInformation.class).equalTo("id", 1).findAllAsync();
//        results.load();
//        realm.commitTransaction();
//        return results;
//    }
//
//    public void deleteUserinfo(String user_id) {
//
//        realm.beginTransaction();  //open the database
//
//        final RealmResults<UserInformation> results = realm.where(UserInformation.class).equalTo("id", 1).findAll();
//        results.deleteAllFromRealm();
//        realm.commitTransaction();
//    }
//
//    public void addDataintoUserinfo(UserInformation obj_) {
//
//        RealmResults<UserInformation> results = getDataintoUserinfo(obj_.getuserid());
//        if (results.size() > 0) {
//            deleteUserinfo("1");
//            addDataintoUserinfo(obj_);
//        } else {
//            realm.beginTransaction();  //open the database
//            //database operation
//            UserInformation obj = realm.createObject(UserInformation.class);
//            obj.setId(obj_.getId());
//            obj.setName(obj_.getName());
//            obj.setemail(obj_.getemail());
//            obj.setpassword(obj_.getpassword());
//            obj.setaddress(obj_.getaddress());
//            obj.setauthtocken(obj_.getauthtocken());
//            obj.setdob(obj_.getdob());
//            obj.setis_vendor(obj_.getis_vendor());
//            obj.setuserid(obj_.getuserid());
//            obj.setgender(obj_.getgender());
//            //inserted all Data to database
//            realm.commitTransaction(); //close the database
//        }
//    }

}
