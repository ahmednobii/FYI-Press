package com.mersal.mersal.retrofit.electors;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

/**
 * Created by Muhammad_Umar_Ch on 07/12/2017.
 */

public class ElectorsdataUser {

    @SerializedName("is_document_uploaded")
    private boolean is_document_uploaded = false;
    @SerializedName("user_id")
    private String user_id = "";
    @SerializedName("is_document_verified")
    private boolean is_document_verified = false;
    @SerializedName("is_already_voted")
    private boolean is_already_voted = false;

    @SerializedName("selected_elector_ids")
    private ArrayList<String> selected_elector_ids;

    public ArrayList<String> getselected_elector_ids() {
        return selected_elector_ids;
    }

    public boolean getis_document_uploaded() {

        return is_document_uploaded;
    }

    public String getuser_id() {

        if (user_id == null) {
            return "";
        }
        return user_id;
    }

    public boolean getis_document_verified() {

        return is_document_verified;
    }

    public boolean getis_already_voted() {

        return is_already_voted;
    }

}
