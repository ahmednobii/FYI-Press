package com.mersal.mersal.fragment;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mersal.mersal.R;
import com.mersal.mersal.activites.auth.FeaturesActivity;
import com.mersal.mersal.activites.auth.SigninActivity;
import com.mersal.mersal.activites.base.BaseActivity;
import com.mersal.mersal.activites.changepassword.ChangePasswordActivity;
import com.mersal.mersal.activites.dashboard.DashboardActivity;
import com.mersal.mersal.activites.editprofile.EditProfileActivity;
import com.mersal.mersal.customviews.NoDataFoundCustomTV;
import com.mersal.mersal.generic.Interfaces.Generic;
import com.mersal.mersal.internetconnections.NetworkConnection;
import com.mersal.mersal.retrofit.baseapi.ApiService;
import com.mersal.mersal.retrofit.baseapi.AppWebServices;
import com.mersal.mersal.retrofit.defualt.DefaultResult;
import com.mersal.mersal.retrofit.editprofile.EditProfileResult;
import com.mersal.mersal.utilties.StaticStrings;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Map;

import io.realm.Realm;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static com.mersal.mersal.activites.auth.OtpVerificationActivity.OtpVerificationActivityObject;
import static com.mersal.mersal.activites.auth.SignUpActivity.SignUpActivityObject;
import static com.mersal.mersal.activites.auth.SignUpPreActivity.SignUpPreActivityObject;
import static com.mersal.mersal.activites.auth.SigninActivity.objsigninActivityObject;
import static com.mersal.mersal.activites.auth.SignupIdScanActivity.ObjSignupIdScanActivity;
import static com.mersal.mersal.activites.base.BaseActivity.objectBAJava;
import static com.mersal.mersal.activites.dashboard.DashboardActivity.dashboardActivityObject;
import static com.mersal.mersal.utilties.StaticStrings.ISFROMFEDITPROFILE;
import static com.mersal.mersal.utilties.StaticStrings.IsFirstTIMEINAPP;


public class ProfileFragment extends Fragment {
    TextView tv_page, tv_submit, tv_name;
    NoDataFoundCustomTV ls_tv_nodatafound;
    //    HeaderCustomTV home_title;
    ProgressBar spinner;
    NetworkConnection ntobj;
    ProfileFragment votingFragment;
    RelativeLayout rl_body, rl_four, rl_seven, rl_six;
    Generic generic;
    //    ImageView back_arrow;
    de.hdodenhof.circleimageview.CircleImageView iv_profile;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_profiles, container, false);

        dashboardActivityObject.hideViewFromElectorFragment();
        dashboardActivityObject.hideheader_left_rlFromElectorFragment();

        votingFragment = this;
        if (getActivity() instanceof BaseActivity) {
            generic = (Generic) getActivity();
        }
        init(rootView);
        clicklisteners();
        generic.hideStatusBar();//initialize to access database for this activity
        return rootView;

    }

    public void init(View rootView_) {

//        home_title = (HeaderCustomTV) getActivity().findViewById(R.id.toolbar_title);
//        home_title.setText("Profile");
        ntobj = new NetworkConnection(getActivity());
        spinner = (ProgressBar) rootView_.findViewById(R.id.progressBar);
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT) {
            spinner.getIndeterminateDrawable().setColorFilter(getResources()
                    .getColor(R.color.progress_bar_color_white), PorterDuff.Mode.SRC_IN);
        }
        ls_tv_nodatafound = (NoDataFoundCustomTV) rootView_.findViewById(R.id.tv_noresult);
        rl_body = (RelativeLayout) rootView_.findViewById(R.id.rl_body);
        ls_tv_nodatafound.setVisibility(View.GONE);
        rl_four = (RelativeLayout) rootView_.findViewById(R.id.rl_four);
        rl_six = (RelativeLayout) rootView_.findViewById(R.id.rl_six);
        rl_seven = (RelativeLayout) rootView_.findViewById(R.id.rl_seven);
        tv_page = (TextView) rootView_.findViewById(R.id.tv_page);
        tv_submit = (TextView) rootView_.findViewById(R.id.tv_submit);
        tv_name = (TextView) rootView_.findViewById(R.id.tv_name);
        tv_name.setTypeface(objectBAJava.roboto_regular);
        tv_page.setTypeface(objectBAJava.roboto_regular);
        String name = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("username", "اسم");
        //  tv_name.setText(name);
        iv_profile = (de.hdodenhof.circleimageview.CircleImageView) rootView_.findViewById(R.id.iv_profile);
        rl_body.setVisibility(View.GONE);
//        back_arrow.setVisibility(View.VISIBLE);
    }



    public void clicklisteners() {

        rl_four.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                StaticStrings.ISFROMFEATURES = false;
                objectBAJava.hideStatusBar();
                Intent mainIntent = new Intent(getActivity(), EditProfileActivity.class);
                startActivity(mainIntent);
                generic.animStart();

            }
        });

        rl_six.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                objectBAJava.hideStatusBar();
                Intent mainIntent = new Intent(getActivity(), ChangePasswordActivity.class);
                startActivity(mainIntent);
                generic.animStart();

            }
        });

        rl_seven.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                logoutconfirm();
            }
        });

    }

    public void logoutconfirm() {

        AlertDialog alert = new AlertDialog.Builder(getActivity())
                .create();
        alert.setMessage("هل تريد بالتأكيد تسجيل الخروج؟");
        alert.setButton(DialogInterface.BUTTON_POSITIVE, "حسنا", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {

                dialog.dismiss();
                logout();

            }
        });
        alert.setButton(DialogInterface.BUTTON_NEGATIVE, "لا", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {

                dialog.dismiss();


            }
        });
        alert.show();
    }

    public void logout() {

        generic.showProgressBar(spinner);
        Map<String, String> params = generic.setBasicParams();
        params.put("auth_token", generic.getAuthTockenFromDb());
        params.put("all_devices", "0");

        OkHttpClient client = generic.setHeaderForReqs().build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(AppWebServices.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();
        ApiService service = retrofit.create(ApiService.class);
        Call<DefaultResult> call = service.logout(params);
        call.enqueue(new Callback<DefaultResult>() {
            @Override
            public void onResponse(Call<DefaultResult> call, retrofit2.Response<DefaultResult> response) {

                generic.hideProgressBar(spinner);

                if (response.code() == 200) {

                    String message = response.body().getMessage();
                    Boolean status = response.body().getstatus();

                    if (status) {

                        PreferenceManager.getDefaultSharedPreferences(getActivity()).edit().putBoolean("firstTimeLogin", false).apply();
                        PreferenceManager.getDefaultSharedPreferences(getActivity()).edit().putBoolean("servicesstatus", false).apply();
                        getActivity().finish();
                        generic.finishAllActivities();
                        Intent g = new Intent(getActivity(), SigninActivity.class);
                        g.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(g);
                        // Clear all notification that received from FCM notifications bcz when app open then all notifications should be gone
//                        NotificationManager nMgr = (NotificationManager) getActivity().getSystemService(Context.NOTIFICATION_SERVICE);
//                        nMgr.cancelAll();
                        getActivity().overridePendingTransition(R.anim.start_slide_in_left, R.anim.start_slide_out_left);
                        generic.deleteUserinfo();

                    } else {

                        generic.showSnackbar(spinner, message, Snackbar.LENGTH_LONG, "close", false);

                    }
                } else {

                    try {

                        String userMessage = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("oops", "هناك خطأ ما");
                        JSONObject jObjError = new JSONObject(response.errorBody().string());
                        try {
                            userMessage = jObjError.getString("message");
                        } catch (Exception e) {
                        }

                        String dataArrayMessage = "";
                        try {
                            JSONArray jsonArray = jObjError.getJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                dataArrayMessage = dataArrayMessage + jsonArray.getString(i) + "\n";
                            }

                        } catch (Exception e) {
                        }

                        String maintenanceBtnText = "Try Again";
                        try {
                            maintenanceBtnText = jObjError.optString("btn_text");
                        } catch (Exception e) {
                        }
                        generic.genericCodes(spinner, response.code(), userMessage, dataArrayMessage, maintenanceBtnText);
                    } catch (Exception e) {

                        generic.showSnackbar(spinner, "هناك خطأ ما", Snackbar.LENGTH_LONG, "close", false);

                    }
                }
            }

            @Override
            public void onFailure(Call<DefaultResult> call, Throwable t) {

                generic.hideProgressBar(spinner);
                generic.showSnackbar(spinner, "هناك خطأ ما", Snackbar.LENGTH_LONG, "close", false);

            }
        });
    }

    public OkHttpClient.Builder setHeaderForReqsForSaveServices() {

        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();
        httpClient.addInterceptor(new Interceptor() {
            @Override
            public okhttp3.Response intercept(Interceptor.Chain chain) throws IOException {
                okhttp3.Request original = chain.request();
                // Request customization: add request headers
                okhttp3.Request.Builder requestBuilder = original.newBuilder()
                        .header("Authorization", StaticStrings.X_KEY.toString())
                        .header("Accept", StaticStrings.Accept.toString()); // <-- this is the important line; // <-- this is the important line
                okhttp3.Request request = requestBuilder.build();
                return chain.proceed(request);
            }
        });

        return httpClient;
    }

    public void apiSaveServices() {

        JSONArray mArray = new JSONArray();
        mArray.put(2);
        mArray.put(9);
        mArray.put(3);


        OkHttpClient client = setHeaderForReqsForSaveServices().build();
        Gson gson = new GsonBuilder()
                .setLenient()
                .create();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(AppWebServices.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .client(client)
                .build();
        ApiService service = retrofit.create(ApiService.class);
//        Call<ServicesResult> call = service.services();
        Call<DefaultResult> call = service.saveservicesForReg(generic.getAuthTockenFromDb(), mArray);
        System.out.println("manu " + mArray);
        call.enqueue(new Callback<DefaultResult>() {
            @Override
            public void onResponse(Call<DefaultResult> call, retrofit2.Response<DefaultResult> response) {

                int code = response.code();
                if (response.code() == 200) {
                    Boolean status = response.body().getstatus();
                    String message = response.body().getMessage();
                    if (status) {

                        }
                    } else {

                    }
            }

            @Override
            public void onFailure(Call<DefaultResult> call, Throwable t) {


            }
        });
    }

    public void apigetProfile() {

        Map<String, String> params = generic.setBasicParams();
        params.put("auth_token", generic.getAuthTockenFromDb());
        OkHttpClient client = generic.setHeaderForReqs().build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(AppWebServices.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();
        ApiService service = retrofit.create(ApiService.class);
        Call<EditProfileResult> call = service.getprofile(params);
        call.enqueue(new Callback<EditProfileResult>() {
            @Override
            public void onResponse(Call<EditProfileResult> call, retrofit2.Response<EditProfileResult> response) {
                generic.hideProgressBar(spinner);

                if (response.code() == 200) {
                    Boolean status = response.body().getstatus();
                    String message = response.body().getMessage();

                    if (status) {

                        if (response.body().getdata().getEditProfileResultdataProfile().getis_user_services()) {
                            dashboardActivityObject.showViewFromElectorFragment();
//                            dashboardActivityObject.showheader_left_rlFromElectorFragment();
                            rl_body.setVisibility(View.VISIBLE);
                            Picasso.get()
                                    .load(response.body().getdata().getEditProfileResultdataProfile().getimage_url())
//                                .resize(100, 100)
//                                .transform(new CropCircleTransformation())
                                    .placeholder(R.drawable.profile_icon)
                                    .error(R.drawable.profile_icon)
                                    .into(iv_profile);
                            tv_name.setText(response.body().getdata().getEditProfileResultdataProfile().getfull_name());
                        } else {
                            dashboardActivityObject.showViewFromElectorFragment();
                            rl_body.setVisibility(View.VISIBLE);
                            Realm.init(getActivity());    //initialize to access database for this activity
                            apiSaveServices();

                            PreferenceManager.getDefaultSharedPreferences(objectBAJava).edit().putBoolean("isDevicetockensend", false).apply();
                            Picasso.get()
                                    .load(response.body().getdata().getEditProfileResultdataProfile().getimage_url())
//                                .resize(100, 100)
//                                .transform(new CropCircleTransformation())
                                    .placeholder(R.drawable.profile_icon)
                                    .error(R.drawable.profile_icon)
                                    .into(iv_profile);
                            tv_name.setText(response.body().getdata().getEditProfileResultdataProfile().getfull_name());
//                            ISFROMFEDITPROFILE = false;
//                            Intent intent = new Intent(getActivity(), FeaturesActivity.class);
//                            startActivity(intent);
//                            generic.animStart();
//                            try {
//                                dashboardActivityObject.finish();
//
//                            } catch (Exception e) {
//
//
//                            }
                        }

//                        Glide.with(getActivity())
//                                .load(response.body().getdata().getEditProfileResultdataProfile().getimage_url())
//                                .signature(new StringSignature(String.valueOf(System.currentTimeMillis())))
//                                .diskCacheStrategy(DiskCacheStrategy.NONE)
//                                .skipMemoryCache(true)
//                                .error(R.drawable.profile_icon)
//                                .transform(new CircleTransform(getActivity()))
//                                .into(iv_profile);

//                                .placeholder(R.drawable.profile_icon)

                    } else {

                        generic.showSnackbar(rl_body, message, Snackbar.LENGTH_LONG, "close", false);

                    }
                } else if (response.code() == 401) {
                    try {
                        String userMessage = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("oops", "هناك خطأ ما");
                        try {
                            JSONObject jObjError = new JSONObject(response.errorBody().string());
                            String errorMessage = jObjError.getString("message");
                            errorMessage = response.body().getMessage();
                            if (errorMessage != null && !errorMessage.equals("")) {
                                userMessage = errorMessage;
                            }
                        } catch (Exception e) {
                        }
                        String OK = "موافق";
                        AlertDialog alert = new AlertDialog.Builder(getActivity())
                                .create();
                        alert.setMessage(userMessage);
                        alert.setButton(DialogInterface.BUTTON_POSITIVE, OK, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {

                                dialog.dismiss();

                            }
                        });
                        alert.show();

                    } catch (Exception e) {

                        String userMessage = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("oops", "هناك خطأ ما");
                    }

                } else {

                    try {

                        String userMessage = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("oops", "هناك خطأ ما");
                        JSONObject jObjError = new JSONObject(response.errorBody().string());
                        try {
                            userMessage = jObjError.getString("message");
                        } catch (Exception e) {
                        }

                        String dataArrayMessage = "";
                        try {
                            JSONArray jsonArray = jObjError.getJSONArray("LoginResultdata");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                dataArrayMessage = dataArrayMessage + jsonArray.getString(i) + "\n";
                            }

                        } catch (Exception e) {
                        }

                        String maintenanceBtnText = "Try Again";
                        try {
                            maintenanceBtnText = jObjError.optString("btn_text");
                        } catch (Exception e) {
                        }
                        generic.genericCodes(rl_body, response.code(), userMessage, dataArrayMessage, maintenanceBtnText);
                    } catch (Exception e) {


                    }

                }
            }

            @Override
            public void onFailure(Call<EditProfileResult> call, Throwable t) {
                generic.hideProgressBar(spinner);
                generic.showSnackbar(rl_body, "هناك خطأ ما", Snackbar.LENGTH_LONG, "close", false);
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        if (ntobj.isConnectingToInternet()) {
            generic.showProgressBar(spinner);
            apigetProfile();
        } else {
            generic.hideProgressBar(spinner);
            String Message = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
            generic.showSnackbar(rl_body, Message, Snackbar.LENGTH_LONG, "close", false);
        }
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        IsFirstTIMEINAPP = false;
        boolean isDeviceTockenSend = PreferenceManager.getDefaultSharedPreferences(objectBAJava).getBoolean("isDevicetockensend", false);
        System.out.println("Check device tocken start pf " + isDeviceTockenSend);
        if (!isDeviceTockenSend) {
            if (ntobj.isConnectingToInternet()) {
                objectBAJava.hideKeyboard();
                apiCallDeviceTocken();
            } else {
                String Message = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
//                generic.showSnackbar(rl_body, Message, Snackbar.LENGTH_LONG, "close", false);
            }
        }
    }

    public void apiCallDeviceTocken() {
        Map<String, String> params = generic.setBasicParams();
        params.put("auth_token", generic.getAuthTockenFromDb());
        params.put("device_token", generic.getDeviceToken());
        OkHttpClient client = generic.setHeaderForReqs().build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(AppWebServices.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();

        ApiService service = retrofit.create(ApiService.class);
        Call<DefaultResult> call = service.update_device(params);
        call.enqueue(new Callback<DefaultResult>() {

            @Override
            public void onResponse(Call<DefaultResult> call, retrofit2.Response<DefaultResult> response) {
                if (response.code() == 200) {

                    Boolean status = response.body().getstatus();
                    String Message = response.body().getMessage();

                    if (status) {
                        PreferenceManager.getDefaultSharedPreferences(objectBAJava).edit().putBoolean("isDevicetockensend", true).apply();
                        System.out.println("Check device tocken start pf in api true");

//                        generic.hideProgressBar(spinner);
//                        generic.hideProgressBar(spinner1);
//                        ll_two.setVisibility(View.VISIBLE);
//                        listView.setVisibility(View.VISIBLE);
//                        tv_noresult.setVisibility(View.GONE);
//                        tv_question.setText(response.body().getdata().getelection().gettitle());
//                        election_id = response.body().getdata().getelection().getid();
//
//                        if (response.body().getdata().getelectors().size() > 0) {
//                            for (int i = 0; i < response.body().getdata().getelectors().size(); i++) {
//                                activitiesData.add(response.body().getdata().getelectors().get(i));
//                            }
//                        }
//
//                        if (response.body().getdata().getuser().getselected_elector_ids() != null) {
//                            if (response.body().getdata().getuser().getselected_elector_ids().size() > 0) {
//                                for (int i = 0; i < response.body().getdata().getuser().getselected_elector_ids().size(); i++) {
//
//                                    activitiesVoterData.add(response.body().getdata().getuser().getselected_elector_ids().get(i));
//                                }
//                            }
//                        }
//
//                        if (activitiesVoterData.size() > 0) {
//                            for (int i = 0; i < activitiesData.size(); i++) {
//
//                                for (int j = 0; j < activitiesVoterData.size(); j++) {
//
//                                    if (activitiesVoterData.get(j).equals(activitiesData.get(i).getid())) {
//                                        activitiesData.get(i).setisvoted(true);
//                                    }
//                                }
//                            }
//                        }
//                        if (response.body().getdata().getuser().getis_document_uploaded()) {
//                            if (response.body().getdata().getuser().getis_document_verified()) {
//                                if (!response.body().getdata().getuser().getis_already_voted()) {
//                                    if (response.body().getdata().getelection().getno_of_electors_select().equals("0")) {
//
//                                        ll_two.setVisibility(View.GONE);
//                                        tv_noresult.setVisibility(View.VISIBLE);
//                                        tv_noresult.setText("لا توجد انتخابات متاحة");
//
//                                    } else {
//
//                                        selectedlimit = Integer.parseInt(response.body().getdata().getelection().getno_of_electors_select());
//                                        boolean isselect = response.body().getdata().getuser().getis_already_voted();
//                                        if (activitiesData.size() == 0) {
//
//                                            ll_two.setVisibility(View.GONE);
//                                            generic.hideProgressBar(spinner);
//                                            spinner1.setVisibility(View.GONE);
//                                            tv_noresult.setVisibility(View.VISIBLE);
//                                            listView.setVisibility(View.GONE);
//                                            rl_submit.setVisibility(View.GONE);
//
//                                        } else {
//                                            adapter = new ElectorsLvAdapter(getActivity(), activitiesData, objElectorsFragment, isselect);
//                                            listView.setAdapter(adapter);
//                                            rl_submit.setVisibility(View.VISIBLE);
//                                            ll_two.setVisibility(View.VISIBLE);
//                                            listView.setVisibility(View.VISIBLE);
//                                            generic.hideProgressBar(spinner);
//                                            tv_noresult.setVisibility(View.GONE);
//                                        }
//                                    }
//
//                                } else // already cast vote
//                                {
//                                    // hide button and disable selection
//                                    boolean isselect = response.body().getdata().getuser().getis_already_voted();
//
//                                    if (activitiesData.size() == 0) {
//                                        generic.hideProgressBar(spinner);
//                                        spinner1.setVisibility(View.GONE);
//                                        tv_noresult.setVisibility(View.VISIBLE);
//                                        listView.setVisibility(View.GONE);
//                                        rl_submit.setVisibility(View.GONE);
//
//                                    } else {
//                                        ll_two.setVisibility(View.VISIBLE);
//                                        listView.setVisibility(View.VISIBLE);
//                                        generic.hideProgressBar(spinner);
//                                        tv_noresult.setVisibility(View.GONE);
//                                        rl_submit.setVisibility(View.GONE);
//                                        adapter = new ElectorsLvAdapter(getActivity(), activitiesData, objElectorsFragment, isselect);
//                                        listView.setAdapter(adapter);
//                                    }
//                                }
//                            } else // under review
//                            {
//                                ll_two.setVisibility(View.GONE);
//                                listView.setVisibility(View.GONE);
//                                tv_noresult.setVisibility(View.VISIBLE);
//                                tv_noresult.setText("المستند قيد المراجعة");
//                            }
//                        } else // upload document
//                        {
//                            Intent intent = new Intent(getActivity(), RegisterVoteActivity.class);
//                            startActivity(intent);
//                            getActivity().overridePendingTransition(R.anim.start_slide_in_left, R.anim.start_slide_out_left);
//                        }
//                        Snackbar snackbar = Snackbar.make(ll_two, Message, Snackbar.LENGTH_LONG);
//                        snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
//                        snackbar.show();

                    } else {
//                        generic.hideProgressBar(spinner);
//                        if (activitiesData.size() == 0) {
//                            tv_noresult.setVisibility(View.VISIBLE);
//                            listView.setVisibility(View.GONE);
//                        }

//                        Snackbar snackbar = Snackbar.make(ll_two, Message, Snackbar.LENGTH_LONG);
//                        snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
//                        snackbar.show();
                        System.out.println("Check device tocken start pf in api false");

                    }

//                } else {
//                    generic.hideProgressBar(spinner);
//                    try {
//
//                        if (activitiesData.size() == 0) {
//                            tv_noresult.setVisibility(View.VISIBLE);
//                            listView.setVisibility(View.GONE);
//                        }
//
////                        spinner.setVisibility(View.GONE);
//                        generic.hideProgressBar(spinner);
//                        spinner1.setVisibility(View.GONE);
//
//                        String userMessage = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("oops", "هناك خطأ ما");
//                        JSONObject jObjError = new JSONObject(response.errorBody().string());
//                        try {
//                            userMessage = jObjError.getString("message");
//                        } catch (Exception e) {
//                        }
//
//                        String dataArrayMessage = "";
//                        try {
//                            JSONArray jsonArray = jObjError.getJSONArray("data");
//                            for (int i = 0; i < jsonArray.length(); i++) {
//                                dataArrayMessage = dataArrayMessage + jsonArray.getString(i) + "\n";
//                            }
//
//                        } catch (Exception e) {
//                        }
//
//
//                        String maintenanceBtnText = "Try Again";
//                        try {
//                            maintenanceBtnText = jObjError.optString("btn_text");
//                        } catch (Exception e) {
//                        }
//
//                        generic.genericCodes(ll_two, response.code(), userMessage, dataArrayMessage, maintenanceBtnText);
//
//                    } catch (Exception e) {
//
////                        spinner.setVisibility(View.GONE);
//                        generic.hideProgressBar(spinner);
//                        spinner1.setVisibility(View.GONE);
//                        if (activitiesData.size() == 0) {
//                            tv_noresult.setVisibility(View.VISIBLE);
//                            listView.setVisibility(View.GONE);
//                        }
//
//                        Snackbar snackbar = Snackbar.make(ll_two, PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("oops", "هناك خطأ ما"), Snackbar.LENGTH_LONG);
//                        snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
//                        snackbar.show();
//
//                    }
//                }
                }
            }

            @Override
            public void onFailure(Call<DefaultResult> call, Throwable t) {

                System.out.println("Check device tocken start pf in api exception");

////                spinner.setVisibility(View.GONE);
//                generic.hideProgressBar(spinner);
//                spinner1.setVisibility(View.GONE);
//                reqIsInProgress = false;
//
//                Snackbar snackbar = Snackbar.make(ll_two, PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("oops", "هناك خطأ ما"), Snackbar.LENGTH_LONG);
//                snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
//                snackbar.show();
//
//                if (activitiesData.size() == 0) {
//                    tv_noresult.setVisibility(View.VISIBLE);
//                    listView.setVisibility(View.GONE);
//                }
            }
        });
    }


}