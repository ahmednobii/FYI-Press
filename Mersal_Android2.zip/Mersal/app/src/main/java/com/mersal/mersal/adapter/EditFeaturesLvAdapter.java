package com.mersal.mersal.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.mersal.mersal.R;
import com.mersal.mersal.activites.auth.FeaturesActivity;
import com.mersal.mersal.activites.editprofile.EditFeaturesActivity;
import com.mersal.mersal.retrofit.editprofile.EditProfileServices;
import com.mersal.mersal.retrofit.services.ServicesdataServices;

import java.util.ArrayList;

import static com.mersal.mersal.activites.base.BaseActivity.objectBAJava;


public class EditFeaturesLvAdapter extends ArrayAdapter<String> {
    private final Context context;
    ArrayList<EditProfileServices> activitiesDataArray = new ArrayList<>();
    LayoutInflater inflater = null;

    public EditFeaturesLvAdapter(Context context, ArrayList<EditProfileServices> activitiesDataArray) {
        super(context, R.layout.lv_feature_item);
        this.context = context;
        this.activitiesDataArray = activitiesDataArray;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return activitiesDataArray.size();
    }

    private class ViewHolder {
        TextView tv_uname;
        CheckBox cb_check;
        RelativeLayout rl_body, rl_check, rl_two;
    }
    @Override
    public View getView(final int position, View convertView, final ViewGroup parent) {

        final ViewHolder holder;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.lv_feature_item, parent, false);
            holder = new ViewHolder();
            holder.tv_uname = (TextView) convertView.findViewById(R.id.tv_uname);
            holder.rl_two = (RelativeLayout) convertView.findViewById(R.id.rl_two);
            holder.cb_check = (CheckBox) convertView.findViewById(R.id.cb_check);
            holder.rl_check = (RelativeLayout) convertView.findViewById(R.id.rl_check);
            holder.rl_body = (RelativeLayout) convertView.findViewById(R.id.rl_body);

            convertView.setTag(holder);

        } else
            holder = (ViewHolder) convertView.getTag();
        holder.tv_uname.setTypeface(objectBAJava.roboto_regular);
//        holder.tv_udetails.setTypeface(objectBAJava.roboto_regular);


        holder.tv_uname.setText(activitiesDataArray.get(position).gettitle());

        if (activitiesDataArray.get(position).getstatus()) {

            holder.cb_check.setChecked(true);

        } else {

            holder.cb_check.setChecked(false);
        }

//
//        Glide.with(context)
//                .load(R.drawable.profile_icon)
//                .placeholder(R.drawable.profile_icon)
//                .error(R.drawable.profile_icon)
//                .into(holder.iv_profile);

//        fragment.Pagination(activitiesDataArray, position);

        holder.cb_check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (activitiesDataArray.get(position).getstatus()) {

                    ((EditFeaturesActivity) context).updateArray(false, position);
                } else {
                    ((EditFeaturesActivity) context).updateArray(true, position);

                }

            }
        });


        return convertView;
    }

}