package com.mersal.mersal.retrofit.services;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

/**
 * Created by Muhammad_Umar_Ch on 07/12/2017.
 */

public class Servicesdata {

    @SerializedName("services")
    private ArrayList<ServicesdataServices> servicesdataServices;

    public ArrayList<ServicesdataServices> getservicesdataServices() {

        return servicesdataServices;
    }

    @SerializedName("user_services")
    private ArrayList<ServicesdataServices> user_services;

    public ArrayList<ServicesdataServices> getuser_services() {

        return user_services;
    }

}
