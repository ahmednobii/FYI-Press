package com.mersal.mersal.activites.base;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import com.mersal.mersal.R;
import com.mersal.mersal.activites.auth.SigninActivity;
import com.mersal.mersal.generic.Interfaces.Generic;
import com.mersal.mersal.realm.UserInformation;
import com.mersal.mersal.utilties.StaticStrings;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import io.realm.Realm;
import io.realm.RealmResults;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;

import static com.mersal.mersal.activites.auth.FeaturesActivity.featuresActivity;
import static com.mersal.mersal.activites.auth.OtpVerificationActivity.OtpVerificationActivityObject;
import static com.mersal.mersal.activites.auth.SignUpActivity.SignUpActivityObject;
import static com.mersal.mersal.activites.auth.SignUpPreActivity.SignUpPreActivityObject;
import static com.mersal.mersal.activites.auth.SigninActivity.objsigninActivityObject;
import static com.mersal.mersal.activites.auth.SignupIdScanActivity.ObjSignupIdScanActivity;
import static com.mersal.mersal.activites.changepassword.ChangePasswordActivity.objChangePasswordActivity;
import static com.mersal.mersal.activites.dashboard.DashboardActivity.dashboardActivityObject;
import static com.mersal.mersal.activites.editprofile.EditFeaturesActivity.editFeaturesActivity;
import static com.mersal.mersal.activites.editprofile.EditProfileActivity.objEditProfileActivity;
import static com.mersal.mersal.activites.elections.ElectoionsDetailsActivity.objElectoionsDetailsActivity;
import static com.mersal.mersal.activites.electors.ElectorsDetailsActivity.objElectorsDetailsActivity;
import static com.mersal.mersal.activites.forgetpassword.ForgetPasswordActivity.objForgetPasswordActivity;
import static com.mersal.mersal.activites.registerdocuments.RegisterVoteActivity.OtpRegisterVoteActivity;
import static com.mersal.mersal.activites.resetpassword.ResetPasswordActivity.objResetPasswordActivity;
import static com.mersal.mersal.activites.showworkpicture.ShowWorkPictureActivity.objShowWorkPictureActivity;

public class BaseActivity extends AppCompatActivity implements Generic {

    public int snakbarDuration = 10000;
    public static Typeface myriad_pro, myriad_pro_bold, Tahoma_Regular_font, ASardarHoor, TAHOMA_0, TAHOMAB0, TAHOMABD, myriad_pro_semi_bold, roboto_bold, roboto_italic, roboto_light, roboto_medium, roboto_regular;
    public static BaseActivity objectBAJava;
    public Realm realm;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initializeData();
        hideKeyboard();
    }

    public void initializeData() {

        objectBAJava = this;
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
            Window window = this.getWindow();
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(ContextCompat.getColor(this, R.color.header_color));
        }
        myriad_pro = Typeface.createFromAsset(getAssets(), "fonts/myriad-pro.ttf");
        myriad_pro_bold = Typeface.createFromAsset(getAssets(), "fonts/myriad-pro-bold.ttf");
        myriad_pro_semi_bold = Typeface.createFromAsset(getAssets(), "fonts/myriad-pro-semibold.ttf");
        roboto_bold = Typeface.createFromAsset(getAssets(), "fonts/Roboto-Bold.ttf");
        roboto_italic = Typeface.createFromAsset(getAssets(), "fonts/Roboto-Italic.ttf");
        roboto_light = Typeface.createFromAsset(getAssets(), "fonts/Roboto-Light.ttf");
        roboto_medium = Typeface.createFromAsset(getAssets(), "fonts/Roboto-Medium.ttf");
        roboto_regular = Typeface.createFromAsset(getAssets(), "fonts/Roboto-Regular.ttf");

        Tahoma_Regular_font = Typeface.createFromAsset(getAssets(), "fonts/tahoma/Tahoma_Regular_font.ttf");
        TAHOMA_0 = Typeface.createFromAsset(getAssets(), "fonts/tahoma/TAHOMA_0.TTF");
        TAHOMABD = Typeface.createFromAsset(getAssets(), "fonts/tahoma/TAHOMABD.TTF");
        TAHOMAB0 = Typeface.createFromAsset(getAssets(), "fonts/tahoma/TAHOMAB0.TTF");
        ASardarHoor = Typeface.createFromAsset(getAssets(), "fonts/tahoma/ASardarHoor.otf");


    }

    public void FinishActivity() {
        // Call in all activities where its needed
        // Do not remove this method
    }

    @Override
    public void hideStatusBar() {
//        if (Build.VERSION.SDK_INT >= 16) {
//            getWindow().setFlags(AccessibilityNodeInfoCompat.ACTION_NEXT_HTML_ELEMENT, AccessibilityNodeInfoCompat.ACTION_NEXT_HTML_ELEMENT);
//            getWindow().getDecorView().setSystemUiVisibility(3328);
//        } else {
//            requestWindowFeature(Window.FEATURE_NO_TITLE);
//            this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
//        }
    }

    @Override
    public void hideStatusBarForAuth() {
//        if (Build.VERSION.SDK_INT >= 16) {
//            getWindow().setFlags(AccessibilityNodeInfoCompat.ACTION_NEXT_HTML_ELEMENT, AccessibilityNodeInfoCompat.ACTION_NEXT_HTML_ELEMENT);
//            getWindow().getDecorView().setSystemUiVisibility(3328);
//        } else {
//            requestWindowFeature(Window.FEATURE_NO_TITLE);
//            this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
//        }
    }

    @Override
    public void genericCodes(View view, int code, String errorMessage, String dataArrayMessage, String btnText) {
        switch (code) {
            case 401:
                try {

                    RealmResults<UserInformation> results = getDataintoUserinfo();
                    if (results.size() > 0) {
                        deleteUserinfo();
                        PreferenceManager.getDefaultSharedPreferences(BaseActivity.this).edit().putBoolean("firstTimeLogin", false).apply();
                        PreferenceManager.getDefaultSharedPreferences(BaseActivity.this).edit().putBoolean("servicesstatus", false).apply();
                    }

                    String userMessage = PreferenceManager.getDefaultSharedPreferences(BaseActivity.this).getString("oops", "هناك خطأ ما");
                    if (errorMessage != null && !errorMessage.equals("")) {
                        userMessage = errorMessage;
                    }

                    String OK = PreferenceManager.getDefaultSharedPreferences(BaseActivity.this).getString("ok", "موافق");
                    AlertDialog alert = new AlertDialog.Builder(BaseActivity.this)
                            .create();
                    alert.setMessage(userMessage);
                    alert.setButton(DialogInterface.BUTTON_POSITIVE, OK, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {

                            dialog.dismiss();
                            finishAllActivities();
                            Intent intent = new Intent(BaseActivity.this, SigninActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                            overridePendingTransition(R.anim.start_slide_in_left, R.anim.start_slide_out_left);

                        }
                    });
                    alert.show();

                } catch (Exception e) {

                    String userMessage = PreferenceManager.getDefaultSharedPreferences(BaseActivity.this).getString("oops", "هناك خطأ ما");
                    showSnackbar(view, userMessage, Snackbar.LENGTH_LONG, "close", false);
                }

                break;
            case 422:

                try {

                    String error_message = PreferenceManager.getDefaultSharedPreferences(BaseActivity.this).getString("oops", "هناك خطأ ما");
                    if (dataArrayMessage != null && !dataArrayMessage.equals("")) {
                        error_message = dataArrayMessage;
                    }
                    String OK = PreferenceManager.getDefaultSharedPreferences(BaseActivity.this).getString("ok", "موافق");
                    AlertDialog alert = new AlertDialog.Builder(BaseActivity.this)
                            .create();
                    alert.setMessage(error_message);
                    alert.setButton(DialogInterface.BUTTON_POSITIVE, OK, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
                    alert.show();
                    //   showSnackbar(view, error_message, Snackbar.LENGTH_LONG, "close", false);


                } catch (Exception e) {

                    String userMessage = PreferenceManager.getDefaultSharedPreferences(BaseActivity.this).getString("oops", "هناك خطأ ما");
                    showSnackbar(view, userMessage, Snackbar.LENGTH_LONG, "close", false);
                }


                break;
            case 500:

                try {

                    String userMessage = PreferenceManager.getDefaultSharedPreferences(BaseActivity.this).getString("oops", "هناك خطأ ما");
                    if (errorMessage != null && !errorMessage.equals("")) {
                        userMessage = errorMessage;
                    }

                    showSnackbar(view, userMessage, Snackbar.LENGTH_LONG, "close", false);

                } catch (Exception e) {

                    String userMessage = PreferenceManager.getDefaultSharedPreferences(BaseActivity.this).getString("oops", "هناك خطأ ما");
                    showSnackbar(view, userMessage, Snackbar.LENGTH_LONG, "close", false);
                }
                break;

            case 503:

                try {

                    String userMessage = PreferenceManager.getDefaultSharedPreferences(BaseActivity.this).getString("oops", "هناك خطأ ما");
                    if (errorMessage != null && !errorMessage.equals("")) {
                        userMessage = errorMessage;
                    }

                    String btnTextValue = "Try Again";
                    if (btnText != null && !btnText.equals("")) {
                        btnTextValue = btnText;
                    }

                    StaticStrings.maintenanceMessage = userMessage;
                    StaticStrings.maintenanceBtn = btnTextValue;
//                    Intent intent = new Intent(BaseActivity.this, MaintanenceActivity.class);
//                    startActivity(intent);
//                    overridePendingTransition(R.anim.start_slide_in_left, R.anim.start_slide_out_left);

                } catch (Exception e) {

                    StaticStrings.maintenanceMessage = PreferenceManager.getDefaultSharedPreferences(BaseActivity.this).getString("oops", "هناك خطأ ما");
                    StaticStrings.maintenanceBtn = "Try Again";
//                    Intent intent = new Intent(BaseActivity.this, MaintanenceActivity.class);
//                    startActivity(intent);
//                    overridePendingTransition(R.anim.start_slide_in_left, R.anim.start_slide_out_left);

                }
                break;

            default:
                try {

                    String userMessage = PreferenceManager.getDefaultSharedPreferences(BaseActivity.this).getString("oops", "هناك خطأ ما");
                    if (errorMessage != null && !errorMessage.equals("")) {
                        userMessage = errorMessage;
                    }

                    showSnackbar(view, userMessage, Snackbar.LENGTH_LONG, "close", false);


                } catch (Exception e) {

                    String userMessage = PreferenceManager.getDefaultSharedPreferences(BaseActivity.this).getString("oops", "هناك خطأ ما");
                    showSnackbar(view, userMessage, Snackbar.LENGTH_LONG, "close", false);
                }
        }

    }

    @Override
    public SpannableString underLineText(String value) {
        SpannableString content = new SpannableString(value);
        content.setSpan(new UnderlineSpan(), 0, content.length(), 0);
        return content;
    }

    public void hideKeyboard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    @Override
    public void finishActivity() {
        hideKeyboard();
        finish();
        overridePendingTransition(R.anim.finish_left_to_right, R.anim.finish_right_to_left);
    }

    @Override
    public void showSnackbar(View view, String message, int duration, final String action, boolean status) {
        final Snackbar snackbar = Snackbar.make(view, message, snakbarDuration);

        if (status)
            snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_green));
        else
            snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));

        snackbar.setActionTextColor(getResources().getColor(R.color.white));
        snackbar.setAction("X", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (action.equals("close"))
                    snackbar.dismiss();
            }
        });

        snackbar.show();
    }

    @Override
    public void showToast(View view, String message, int duration, Context context) {

        Toast.makeText(context, message, duration).show();
    }

    @Override
    public void showProgressBar(View view) {

        view.setVisibility(View.VISIBLE);

        hideKeyboard();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
    }

    @Override
    public void hideProgressBar(View view) {
        view.setVisibility(View.GONE);
        hideKeyboard();
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
    }

    public void fLAGNOTTOUCHABLE() {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
    }

    public void fLAGTOUCHABLE() {
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
    }

    @Override
    public void finishAllActivities() {

        try {
            objResetPasswordActivity.finish();
        } catch (Exception e) {
        }
        try {
            objChangePasswordActivity.finish();
        } catch (Exception e) {
        }
        try {
            SignUpActivityObject.finish();
        } catch (Exception e) {
        }

        try {
            ObjSignupIdScanActivity.finish();
        } catch (Exception e) {

        }
        try {
            OtpVerificationActivityObject.finish();
        } catch (Exception e) {

        }

        try {
            objElectoionsDetailsActivity.finish();
        } catch (Exception e) {

        }
        try {
            objElectorsDetailsActivity.finish();
        } catch (Exception e) {

        }
        try {
            objEditProfileActivity.finish();
        } catch (Exception e) {

        }
        try {
            featuresActivity.finish();
        } catch (Exception e) {

        }

        try {
            editFeaturesActivity.finish();
        } catch (Exception e) {

        }
        try {
            objForgetPasswordActivity.finish();
        } catch (Exception e) {

        }

        try {
            objsigninActivityObject.finish();
        } catch (Exception e) {

        }
        try {
            SignUpPreActivityObject.finish();
        } catch (Exception e) {

        }
        try {
            OtpRegisterVoteActivity.finish();
        } catch (Exception e) {

        }
        try {
            dashboardActivityObject.finish();
        } catch (Exception e) {

        }
        try {
            objShowWorkPictureActivity.finish();
        } catch (Exception e) {
        }
    }

    @Override
    public Map setBasicParams() {
        Map<String, String> params = new HashMap<>();

//        //   params.put("current_language", getCurrentLang());
//        params.put("device_token", getDeviceToken());
        params.put("device_type", StaticStrings.DEVICE_TYPE.toString());
//        params.put("user_agent", Build.MODEL);
////        params.put("platform", Build.VERSION.RELEASE);
//        params.put("platform", "app");
//
//        System.out.println("THis Device Token " + StaticStrings.DEVICE_TYPE.toString());

        return params;
    }

    @Override
    public void onPause() {
        super.onPause();
        hideKeyboard();
    }

    @Override
    public OkHttpClient.Builder setHeaderForReqs() {

        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();
        httpClient.addInterceptor(new Interceptor() {
            @Override
            public okhttp3.Response intercept(Interceptor.Chain chain) throws IOException {
                okhttp3.Request original = chain.request();

                // Request customization: add request headers
                okhttp3.Request.Builder requestBuilder = original.newBuilder()
                        .header("X-API-KEY", StaticStrings.X_KEY.toString())
                        .header("Accept", StaticStrings.Accept.toString()) // <-- this is the important line
                        .header("Content-Type", StaticStrings.ContentType.toString()); // <-- this is the important line

                okhttp3.Request request = requestBuilder.build();
                return chain.proceed(request);
            }
        });

        return httpClient;
    }

    @Override
    public OkHttpClient.Builder setHeaderForReqsForServices() {

        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();
        httpClient.addInterceptor(new Interceptor() {
            @Override
            public okhttp3.Response intercept(Interceptor.Chain chain) throws IOException {
                okhttp3.Request original = chain.request();
                // Request customization: add request headers
                okhttp3.Request.Builder requestBuilder = original.newBuilder()
                        .header("X-API-KEY", StaticStrings.X_KEY.toString())
                        .header("Accept", StaticStrings.Accept.toString()); // <-- this is the important line; // <-- this is the important line

                okhttp3.Request request = requestBuilder.build();
                return chain.proceed(request);
            }
        });

        return httpClient;
    }

    @Override
    public OkHttpClient.Builder setHeaderForReqsForSaveServices() {

        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();
        httpClient.addInterceptor(new Interceptor() {
            @Override
            public okhttp3.Response intercept(Interceptor.Chain chain) throws IOException {
                okhttp3.Request original = chain.request();
                // Request customization: add request headers
                okhttp3.Request.Builder requestBuilder = original.newBuilder()
                        .header("Authorization", StaticStrings.X_KEY.toString())
                        .header("Accept", StaticStrings.Accept.toString()); // <-- this is the important line; // <-- this is the important line
                okhttp3.Request request = requestBuilder.build();
                return chain.proceed(request);
            }
        });

        return httpClient;
    }

    @Override
    public void showAlertDiloge(String userMessage, Context context) {


        AlertDialog alert = new AlertDialog.Builder(context)
                .create();
        alert.setMessage(userMessage);
        alert.setButton(DialogInterface.BUTTON_POSITIVE, "موافق", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {

                dialog.dismiss();

            }
        });
        alert.show();
    }

    @Override
    public void finishCurrentActivity(Activity activity) {
        hideKeyboard();
        activity.finish();
        overridePendingTransition(R.anim.finish_left_to_right, R.anim.finish_right_to_left);
    }

    public void openNextActivity(Activity activity) {
        hideKeyboard();

        Intent g = new Intent(BaseActivity.this, BaseActivity.class);
        startActivity(g);
        overridePendingTransition(R.anim.start_slide_in_left, R.anim.start_slide_out_left);
        finish();
    }

    @Override
    public void animStart() {
        overridePendingTransition(R.anim.start_slide_in_left, R.anim.start_slide_out_left);
    }

    @Override
    public void animEnd() {
        overridePendingTransition(R.anim.finish_left_to_right, R.anim.finish_right_to_left);
    }

    @Override
    public void hideProgressBarInChat(View view) {
        view.setVisibility(View.GONE);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
    }


    @Override
    public void deleteUserinfo() {
        Realm.init(this);    //initialize to access database for this activity
        realm = Realm.getDefaultInstance();
        realm.beginTransaction();  //open the database
        final RealmResults<UserInformation> results = realm.where(UserInformation.class).equalTo("id", 1).findAll();
        results.deleteAllFromRealm();
        realm.commitTransaction();
    }


    @Override
    public RealmResults<UserInformation> getDataintoUserinfo() {
        Realm.init(this);    //initialize to access database for this activity
        realm = Realm.getDefaultInstance();
        realm.beginTransaction();  //open the database
        RealmResults<UserInformation> results = realm.where(UserInformation.class).equalTo("id", 1).findAllAsync();
        //fetching the EditProfileData
        results.load();
        realm.commitTransaction();
        return results;

    }

    @Override
    public String getAuthTockenFromDb() {
        boolean isfirstTimeLogin = PreferenceManager.getDefaultSharedPreferences(BaseActivity.this).getBoolean("firstTimeLogin", false);
        String authTocken = "";
        if (isfirstTimeLogin) {
            RealmResults<UserInformation> results = getDataintoUserinfo();
            authTocken = results.get(0).getauthtocken().toString();
            return authTocken;

        } else {
            return authTocken;
        }
    }

    @Override
    public String getDeviceToken() {
        String deviceToken = "";
        deviceToken = PreferenceManager.getDefaultSharedPreferences(BaseActivity.this).getString("device_token", "");
        System.out.println("its device token from base activty " + deviceToken);
        return deviceToken;
    }

}
