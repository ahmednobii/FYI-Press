package com.mersal.mersal.retrofit.invitations;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

/**
 * Created by Muhammad_Umar_Ch on 07/12/2017.
 */

public class InvitationsDataInvitations {

    @SerializedName("title")
    private String title;
    @SerializedName("expiry_date")
    private String expiry_date = "";
    @SerializedName("expiry_time")
    private String expiry_time = "";
    @SerializedName("service_id")
    private String service_id = "";
    @SerializedName("gallery")
    private InvitationsDataInvitationsGallery gallery;

    public InvitationsDataInvitationsGallery getgallery() {
        return gallery;
    }

    public String gettitle() {
        if (title == null) {
            return "";
        }
        return title;
    }

    public String getexpiry_date() {

        if (expiry_date == null) {
            return "";
        }
        return expiry_date;
    }

    public String getexpiry_time() {
        if (expiry_time == null) {
            return "";
        }
        return expiry_time;
    }

    public String getservice_id() {
        if (service_id == null) {
            return "";
        }
        return service_id;
    }

}
