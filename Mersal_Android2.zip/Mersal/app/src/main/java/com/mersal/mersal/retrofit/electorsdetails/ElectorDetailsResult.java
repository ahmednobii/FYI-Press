package com.mersal.mersal.retrofit.electorsdetails;

import com.google.gson.annotations.SerializedName;
import com.mersal.mersal.retrofit.electors.Electorsdata;


public class ElectorDetailsResult {
    @SerializedName("status")
    private Boolean status = false;

    @SerializedName("message")
    private String message = "";

    @SerializedName("data")
    private ElectorsDetaildata data;

    public Boolean getstatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public ElectorsDetaildata getdata() {
        return data;
    }


}