package com.mersal.mersal.retrofit.notifications;

import com.google.gson.annotations.SerializedName;
import com.mersal.mersal.retrofit.invitations.InvitationsDataInvitationsGallery;

/**
 * Created by Muhammad_Umar_Ch on 07/12/2017.
 */

public class NotificationsDatanotifications {

    @SerializedName("title")
    private String title;
    @SerializedName("text")
    private String text = "";
    @SerializedName("status")
    private String status = "";
    @SerializedName("date")
    private String date = "";
    @SerializedName("time")
    private String time;
    @SerializedName("service_id")
    private String service_id;

    public String getservice_id() {
        return service_id;
    }

    public String gettime() {
        return time;
    }

    public String gettitle() {
        if (title == null) {
            return "";
        }
        return title;
    }

    public String gettext() {

        if (text == null) {
            return "";
        }
        return text;
    }

    public String getstatus() {
        if (status == null) {
            return "";
        }
        return status;
    }

    public String getdate() {
        if (date == null) {
            return "";
        }
        return date;
    }

}
