package com.mersal.mersal.retrofit.electors;

import com.google.gson.annotations.SerializedName;
import com.mersal.mersal.retrofit.votinglist.Votingdata;


public class ElectorsResult {
    @SerializedName("status")
    private Boolean status = false;

    @SerializedName("message")
    private String message = "";

    @SerializedName("data")
    private Electorsdata data;

    public Boolean getstatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public Electorsdata getdata() {
        return data;
    }


}