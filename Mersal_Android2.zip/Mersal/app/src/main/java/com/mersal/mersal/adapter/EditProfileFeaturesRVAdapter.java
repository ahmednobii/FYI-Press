package com.mersal.mersal.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.mersal.mersal.R;
import com.mersal.mersal.retrofit.editprofile.EditProfileServices;

import java.util.ArrayList;

public class EditProfileFeaturesRVAdapter extends RecyclerView.Adapter<EditProfileFeaturesRVAdapter.MyView> {

    private ArrayList<EditProfileServices> list;
    View itemView;
    Context context;

    public class MyView extends RecyclerView.ViewHolder {
        public CheckBox cb_check;
        public TextView tv_uname;
        RelativeLayout rl_body;
        RelativeLayout rl_check;

        public MyView(View view) {
            super(view);

            cb_check = (CheckBox) view.findViewById(R.id.cb_check);
            tv_uname = (TextView) view.findViewById(R.id.tv_uname);
            rl_body = (RelativeLayout) view.findViewById(R.id.rl_body);
            rl_check = (RelativeLayout) view.findViewById(R.id.rl_check);

        }
    }

    public EditProfileFeaturesRVAdapter(ArrayList<EditProfileServices> horizontalList, Context context) {
        this.list = horizontalList;
        this.context = context;
    }

    @Override
    public MyView onCreateViewHolder(ViewGroup parent, int viewType) {

        itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.gd_item_editprofilefeatures, parent, false);

        return new MyView(itemView);
    }

    @Override
    public void onBindViewHolder(final MyView holder, final int position) {

        holder.tv_uname.setText(list.get(position).gettitle());

        if (list.get(position).getstatus()) {

            holder.cb_check.setChecked(true);

        } else {
            holder.cb_check.setChecked(false);
        }

        holder.rl_check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                holder.cb_check.setChecked(true);

            }
        });
        holder.rl_body.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        holder.cb_check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                holder.cb_check.setChecked(true);

            }
        });
    }

    @Override
    public int getItemCount() {

//        return list.size();

        if (list != null) {
            return list.size();
        } else {
            return 0;
        }
    }
}


