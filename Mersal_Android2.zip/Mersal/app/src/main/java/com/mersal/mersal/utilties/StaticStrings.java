package com.mersal.mersal.utilties;


/*
 * Created by Muhammad_Umar_Ch on 22/11/2017.
 */

public class StaticStrings {

  public static final String DEVICE_TYPE = "android";
  public static final String X_KEY = "0wkckss8c88gcoos0g4c4c80ggoo840gsos4gcsk";
  public static final String Accept = "application/json";
  public static final String ContentType = "application/x-www-form-urlencoded";
  //public static Boolean check_sideMenu = false;
//  public static int menu_opt = 0;
//  public static BaseInviteFragment loadedInviteFrndFragment = null;
//  public static BaseMembersFragment loadedMembersFragment = null;
////  public static BaseMyPackagesFragment loadedMyPkgsFragment = null;
//  public static BaseMainFragment loadedCurrentFragment = null;

  public static String maintenanceMessage = "App is currently under maintenance";
  public static String maintenanceBtn = "Try Again";
  public static String TYPE = "message";
  public static String fbAppsecretkey = "47695ba0e70d9c335b6faf6305fe6a98";
  public static Boolean ISFROMFEATURES = false;
  public static Boolean ISFROMFEDITPROFILE = false;
  public static Boolean ISFROMREGISTERID = false;
  public static Boolean IsFirstTIMEINAPP = false;
}


//fb App id
//2491958497588768

//client app id
//cfd8319b4892e1e037c0f327f3d7c706

//<!--keyhash-->
//<!--2jmj7l5rSw0yVb/vlWAYkK/YBwk=-->

//  Account Kit App Secret
//6aa08557f0595f59507c8b41fa946996

//  Account Kit Client Token
//9ab5bd73bfcc2cecd819e312a27ccb29
