package com.mersal.mersal.activites.auth;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.graphics.PorterDuff;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.Snackbar;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AlertDialog;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.facebook.accountkit.AccessToken;
import com.facebook.accountkit.AccountKit;
import com.google.firebase.messaging.FirebaseMessaging;
import com.mersal.mersal.R;
import com.mersal.mersal.activites.base.BaseActivity;
import com.mersal.mersal.activites.dashboard.DashboardActivity;
import com.mersal.mersal.activites.forgetpassword.ForgetPasswordActivity;
import com.mersal.mersal.generic.Interfaces.Generic;
import com.mersal.mersal.customviews.NoDataFoundCustomTV;
import com.mersal.mersal.internetconnections.NetworkConnection;
import com.mersal.mersal.realm.UserInformation;
import com.mersal.mersal.retrofit.Login.LoginResult;
import com.mersal.mersal.retrofit.Login.LoginResultdata;
import com.mersal.mersal.retrofit.baseapi.ApiService;
import com.mersal.mersal.retrofit.baseapi.AppWebServices;
import com.mersal.mersal.utilties.Configuration;

import org.json.JSONArray;
import org.json.JSONObject;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Map;
import io.realm.Realm;
import io.realm.RealmResults;
import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static com.mersal.mersal.utilties.StaticStrings.TYPE;

public class SigninActivity extends BaseActivity {

    TextView tv_uname, tv_pwd, tv_lbl, tv_submit, tv_lbl_rgr, tv_lbl_dnt;
    RelativeLayout rl_submit, rl_body;
    String st_email, st_pwd = "";
    EditText et_email, et_pwd;
    ProgressBar progressBar;
    NoDataFoundCustomTV tv_noresult;
    public static SigninActivity objsigninActivityObject;
    NetworkConnection ntobj = new NetworkConnection(SigninActivity.this);
    Generic generic;
    Realm realm;
    ImageView imgShowPassword;
    public ArrayList<UserInformation> userProfile = new ArrayList<>();
    private BroadcastReceiver mRegistrationBroadcastReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        if (SigninActivity.this instanceof BaseActivity) {
            generic = (Generic) SigninActivity.this;
        }
        generic.hideStatusBarForAuth();
        objsigninActivityObject = this;

        boolean isfirstTimeLogin = PreferenceManager.getDefaultSharedPreferences(SigninActivity.this).getBoolean("firstTimeLogin", false);
        boolean isservicesstatus = PreferenceManager.getDefaultSharedPreferences(SigninActivity.this).getBoolean("servicesstatus", false);

        if (isfirstTimeLogin) {

//            if (isservicesstatus) {

            Bundle extras = getIntent().getExtras();
            String title, message, type;
            if (extras != null) {
                title = extras.getString("title");
                message = extras.getString("message");
                type = extras.getString("type");
                Intent intent = new Intent(SigninActivity.this, DashboardActivity.class);
                intent.putExtra("title", title);
                intent.putExtra("message", message);
                intent.putExtra("type", type);

                startActivity(intent);

            }
            else {

                Intent intent = new Intent(SigninActivity.this, DashboardActivity.class);
                startActivity(intent);
            }
                overridePendingTransition(R.anim.start_slide_in_up, R.anim.start_slide_out_up);
                finish();
//            }else{
//                ISFROMFEDITPROFILE = false;
//                Intent intent = new Intent(SigninActivity.this, FeaturesActivity.class);
//                startActivity(intent);
//                overridePendingTransition(R.anim.start_slide_in_up, R.anim.start_slide_out_up);
//                finish();
//            }
        } else {
            init();
            clickListener();
        }



        objectBAJava.hideKeyboard();
        PreferenceManager.getDefaultSharedPreferences(objectBAJava).edit().putBoolean("isDevicetockensend", false).apply();
    }

    public void init() {
        printKeyHash();
        et_email = (EditText) findViewById(R.id.et_email);
        et_pwd = (EditText) findViewById(R.id.et_pwd);
        tv_uname = (TextView) findViewById(R.id.tv_uname);
        tv_pwd = (TextView) findViewById(R.id.tv_pwd);
        tv_submit = (TextView) findViewById(R.id.tv_submit);
        tv_lbl = (TextView) findViewById(R.id.tv_lbl);
        tv_lbl_rgr = (TextView) findViewById(R.id.tv_lbl_rgr);
        tv_lbl_dnt = (TextView) findViewById(R.id.tv_lbl_dnt);
        rl_submit = (RelativeLayout) findViewById(R.id.rl_submit);
        rl_body = (RelativeLayout) findViewById(R.id.rl_body);
        et_email.setTypeface(objectBAJava.Tahoma_Regular_font);
        et_email.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_uname.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_pwd.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_lbl.setTypeface(objectBAJava.ASardarHoor);
        tv_submit.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_lbl_dnt.setTypeface(objectBAJava.Tahoma_Regular_font);
        imgShowPassword = findViewById(R.id.show_pass_btn);
        tv_lbl_rgr.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_noresult = (NoDataFoundCustomTV) findViewById(R.id.tv_noresult);
        Realm.init(this);    //initialize to access database for this activity
        realm = Realm.getDefaultInstance();
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        progressBar.setVisibility(View.GONE);

        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT) {
            progressBar.getIndeterminateDrawable().setColorFilter(getResources()
                    .getColor(R.color.progress_bar_color_white), PorterDuff.Mode.SRC_IN);
        }
    }

    public void clickListener() {
        rl_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                velidation();
                objectBAJava.hideStatusBar();

//                Intent mainIntent = new Intent(SigninActivity.this, SignUpPreActivity.class);
//                startActivity(mainIntent);
//                overridePendingTransition(R.anim.start_slide_in_left, R.anim.start_slide_out_left);
//                objectBAJava.hideStatusBar();
            }
        });

        tv_lbl_rgr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mainIntent = new Intent(SigninActivity.this, TermsActivity.class);
                startActivity(mainIntent);
                overridePendingTransition(R.anim.start_slide_in_left, R.anim.start_slide_out_left);
                objectBAJava.hideStatusBar();
            }
        });
        tv_lbl_dnt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mainIntent = new Intent(SigninActivity.this, ForgetPasswordActivity.class);
                startActivity(mainIntent);
                overridePendingTransition(R.anim.start_slide_in_left, R.anim.start_slide_out_left);
                objectBAJava.hideStatusBar();
            }
        });

        imgShowPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if( et_pwd.getTransformationMethod().equals(PasswordTransformationMethod.getInstance())){
                    et_pwd.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    imgShowPassword.setImageResource(R.drawable.password_show);
                }
                else {
                    et_pwd.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    imgShowPassword.setImageResource(R.drawable.password_hide);
                }
            }
        });
    }

    public boolean containAlphanumeric(final String str) {
        byte counter = 0;
        boolean checkdigit = false, checkchar = false;
        for (int i = 0; i < str.length() && counter < 2; i++) {
            // If we find a non-digit character we return false.
            if (!checkdigit && Character.isDigit(str.charAt(i))) {
                checkdigit = true;
                counter++;
            }
            String a = String.valueOf(str.charAt(i));
            if (!checkchar && a.matches("[a-zA-Z]*")) {
                checkchar = true;
                counter++;
            }
        }
        if (checkdigit && checkchar) {
            return true;
        }
        return false;
    }

    public void velidation() {
        st_email = et_email.getText().toString();
        st_pwd = et_pwd.getText().toString();

        if (st_email.trim().equals("")) {
            et_email.requestFocus();
            et_email.setError("مطلوب الهاتف المحمول");
//        } else if (!st_email.contains("@") || !st_email.contains(".")) {
//            et_email.requestFocus();
//            et_email.setError("Valid email is Required");
//        }
        } else if (st_pwd.trim().equals("")) {
            et_pwd.requestFocus();
            et_pwd.setError("كلمه المرور مطلوب");
        }
        else if(!containAlphanumeric(st_pwd.trim())){
            et_pwd.requestFocus();
            et_pwd.setError("كلمة المرور يجب أن تتكون من حروف و أرقام");
        }
        else {
            if (ntobj.isConnectingToInternet()) {
                objectBAJava.hideKeyboard();
                apiLogin();


            } else {
                String Message = PreferenceManager.getDefaultSharedPreferences(SigninActivity.this).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
                generic.showSnackbar(rl_body, Message, Snackbar.LENGTH_LONG, "close", false);
            }
        }
    }

    public void apiLogin() {

        generic.showProgressBar(progressBar);
        Map<String, String> params = generic.setBasicParams();
        params.put("email", st_email);
        params.put("password", st_pwd);

        OkHttpClient client = generic.setHeaderForReqs().build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(AppWebServices.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();
        ApiService service = retrofit.create(ApiService.class);
        Call<LoginResult> call = service.login(params);
        call.enqueue(new Callback<LoginResult>() {
            @Override
            public void onResponse(Call<LoginResult> call, retrofit2.Response<LoginResult> response) {

                generic.hideProgressBar(progressBar);

                if (response.code() == 200) {
                    Boolean status = response.body().getstatus();

                    String message = response.body().getMessage();

                    if (status) {
                        userProfile.clear();
                        LoginResultdata data = response.body().getdata();
                        UserInformation object = new UserInformation();
                        object.setemail(data.getEmail());
                        object.setaddress(data.getaddress());
                        object.setauthtocken(data.getauth_token());
                        object.setdob(data.getdob());
                        object.setgender(data.getgender());
                        object.setpassword(st_pwd);
                        object.setName(data.getuser_name());
                        object.setuserid(data.getuser_id());
                        object.setId(1);
                        object.setis_vendor(data.getisvendor());
                        addDataintoUserinfo(object);
                        userProfile.add(object);
                        PreferenceManager.getDefaultSharedPreferences(SigninActivity.this).edit().putBoolean("servicesstatus", data.getadd_services()).apply();
                        PreferenceManager.getDefaultSharedPreferences(SigninActivity.this).edit().putString("username", data.getuser_name()).apply();
                        PreferenceManager.getDefaultSharedPreferences(SigninActivity.this).edit().putString("documentstatus", data.getdocument_status()).apply();
                        PreferenceManager.getDefaultSharedPreferences(SigninActivity.this).edit().putBoolean("firstTimeLogin", true).apply();

//                        if (data.getadd_services()){
                            Intent g = new Intent(SigninActivity.this, DashboardActivity.class);
                            startActivity(g);
                            finish();
                            overridePendingTransition(R.anim.start_slide_in_left, R.anim.start_slide_out_left);
//                        }else {
//                            ISFROMFEDITPROFILE = false;
//                            Intent g = new Intent(SigninActivity.this, FeaturesActivity.class);
//                            startActivity(g);
//                            finish();
//                            overridePendingTransition(R.anim.start_slide_in_left, R.anim.start_slide_out_left);
//                        }
                    } else {
                        generic.showSnackbar(rl_body, message, Snackbar.LENGTH_LONG, "close", false);
                    }
                } else if (response.code() == 401) {
                    try {
                        RealmResults<UserInformation> results = getDataintoUserinfo();
                        if (results.size() > 0) {
                            deleteUserinfo();
                            PreferenceManager.getDefaultSharedPreferences(SigninActivity.this).edit().putBoolean("firstTimeLogin", false).apply();
                        }
                        String userMessage = PreferenceManager.getDefaultSharedPreferences(SigninActivity.this).getString("oops", "رقم الهاتف أو كلمة المرور خاطئة");
                        try {

//                            String dataArrayMessage = "";
//                            try {
//                                ArrayList<String> message = response.body().getmessage();
//                                for (int i = 0; i < message.size(); i++) {
//                                    dataArrayMessage = dataArrayMessage + message.get(i) + "\n";
//                                }
//
//                            } catch (Exception e) {
//                            }

                            JSONObject jObjError = new JSONObject(response.errorBody().string());
                            String errorMessage = jObjError.getString("message");
//                            errorMessage = response.body().getMessage();
                            if (errorMessage != null && !errorMessage.equals("")) {
                                userMessage = errorMessage;
                            }
                        } catch (Exception e) {
                        }
                        String OK = PreferenceManager.getDefaultSharedPreferences(SigninActivity.this).getString("ok", "موافق");
                        AlertDialog alert = new AlertDialog.Builder(SigninActivity.this)
                                .create();
                        alert.setMessage(userMessage);
                        alert.setButton(DialogInterface.BUTTON_POSITIVE, OK, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {

                                dialog.dismiss();

                            }
                        });
                        alert.show();

                    } catch (Exception e) {

                        String userMessage = PreferenceManager.getDefaultSharedPreferences(SigninActivity.this).getString("oops", "رقم الهاتف او كلمة المرور خاطئة");
                        showSnackbar(rl_body, userMessage, Snackbar.LENGTH_LONG, "close", false);
                    }

                } else {

                    try {

                        String userMessage = PreferenceManager.getDefaultSharedPreferences(SigninActivity.this).getString("oops", "رقم الهاتف او كلمة المرور خاطئة");
                        JSONObject jObjError = new JSONObject(response.errorBody().string());
                        try {
                            userMessage = jObjError.getString("message");
                        } catch (Exception e) {
                        }

                        String dataArrayMessage = "";
                        try {
                            JSONArray jsonArray = jObjError.getJSONArray("LoginResultdata");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                dataArrayMessage = dataArrayMessage + jsonArray.getString(i) + "\n";
                            }

                        } catch (Exception e) {
                        }

                        String maintenanceBtnText = "Try Again";
                        try {
                            maintenanceBtnText = jObjError.optString("btn_text");
                        } catch (Exception e) {
                        }
                        generic.genericCodes(rl_body, response.code(), userMessage, dataArrayMessage, maintenanceBtnText);
                    } catch (Exception e) {

                        generic.showSnackbar(progressBar, "رقم الهاتف او كلمة المرور خاطئة", Snackbar.LENGTH_LONG, "close", false);

                    }
                }
            }

            @Override
            public void onFailure(Call<LoginResult> call, Throwable t) {

                generic.hideProgressBar(progressBar);
                generic.showSnackbar(progressBar, "هناك خطأ ما", Snackbar.LENGTH_LONG, "close", false);

            }
        });
    }

    public RealmResults<UserInformation> getDataintoUserinfo(String user_id) {
        realm.beginTransaction();  //open the database
        RealmResults<UserInformation> results = realm.where(UserInformation.class).equalTo("id", 1).findAllAsync();
        results.load();
        realm.commitTransaction();
        return results;
    }

    public void deleteUserinfo(String user_id) {

        realm.beginTransaction();  //open the database

        final RealmResults<UserInformation> results = realm.where(UserInformation.class).equalTo("id", 1).findAll();
        results.deleteAllFromRealm();
        realm.commitTransaction();
    }

    public void addDataintoUserinfo(UserInformation obj_) {

        RealmResults<UserInformation> results = getDataintoUserinfo(obj_.getuserid());
        if (results.size() > 0) {
            deleteUserinfo("1");
            addDataintoUserinfo(obj_);
        } else {
            realm.beginTransaction();  //open the database
            //database operation
            UserInformation obj = realm.createObject(UserInformation.class);
            obj.setId(obj_.getId());
            obj.setName(obj_.getName());
            obj.setemail(obj_.getemail());
            obj.setpassword(obj_.getpassword());
            obj.setaddress(obj_.getaddress());
            obj.setauthtocken(obj_.getauthtocken());
            obj.setdob(obj_.getdob());
            obj.setis_vendor(obj_.getis_vendor());
            obj.setuserid(obj_.getuserid());
            obj.setgender(obj_.getgender());
            //inserted all Data to database
            realm.commitTransaction(); //close the database
        }
    }

    private void printKeyHash() {

        try {
            PackageInfo info = getPackageManager().getPackageInfo("com.mersal.mersal", PackageManager.GET_SIGNATURES);

            for (Signature signature : info.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                Log.d("KEYHASH", Base64.encodeToString(md.digest(), Base64.DEFAULT));
            }
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
    }

    public void getAceessacebook() {

        AccessToken accessToken = AccountKit.getCurrentAccessToken();

        if (accessToken != null) {
            //Handle Returning User
        } else {
            //Handle new or logged out user
        }
    }




}
