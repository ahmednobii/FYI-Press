package com.mersal.mersal.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.mersal.mersal.R;
import com.mersal.mersal.fragment.ElectorsFragment;
import com.mersal.mersal.retrofit.electors.Electorsdataelectors;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;
import jp.wasabeef.picasso.transformations.CropCircleTransformation;

import static com.mersal.mersal.activites.base.BaseActivity.objectBAJava;


public class ElectorsLvAdapter extends ArrayAdapter<String> {
    private final Context context;
    ArrayList<Electorsdataelectors> activitiesDataArray = new ArrayList<>();
    LayoutInflater inflater = null;
    ElectorsFragment fragment;
    boolean isselection = false;

    public ElectorsLvAdapter(Context context, ArrayList<Electorsdataelectors> activitiesDataArray, ElectorsFragment fragment_, boolean isselection_) {
        super(context, R.layout.lv_voting_item);
        this.context = context;
        this.fragment = fragment_;
        this.isselection = isselection_;
        this.activitiesDataArray = activitiesDataArray;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return activitiesDataArray.size();
    }

    private class ViewHolder {
        TextView tv_uname, tv_udetails, tv_fulldetails;
        CircleImageView iv_tick;
        ImageView iv_profile;
        RelativeLayout rl_body, rl_profile, rl_body_blur;
    }

    @Override
    public View getView(final int position, View convertView, final ViewGroup parent) {

        final ViewHolder holder;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.lv_voting_item, parent, false);
            holder = new ViewHolder();
            holder.tv_uname = (TextView) convertView.findViewById(R.id.tv_uname);
            holder.rl_profile = (RelativeLayout) convertView.findViewById(R.id.rl_profile);
            holder.tv_udetails = (TextView) convertView.findViewById(R.id.tv_udetails);
            holder.iv_profile = (ImageView) convertView.findViewById(R.id.iv_profile);
            holder.iv_tick = (CircleImageView) convertView.findViewById(R.id.iv_tick);
            holder.rl_body = (RelativeLayout) convertView.findViewById(R.id.rl_body);
            holder.rl_body_blur = (RelativeLayout) convertView.findViewById(R.id.rl_body_blur);
            holder.tv_fulldetails = (TextView) convertView.findViewById(R.id.tv_fulldetails);


            convertView.setTag(holder);

        } else
            holder = (ViewHolder) convertView.getTag();
//        holder.tv_fulldetails.setPaintFlags(holder.tv_fulldetails.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        holder.tv_fulldetails.setTypeface(objectBAJava.Tahoma_Regular_font);
//        holder.tv_uname.setTypeface(objectBAJava.roboto_regular);
//        holder.tv_udetails.setTypeface(objectBAJava.roboto_regular);
//        holder.tv_uname.setTypeface(objectBAJava.roboto_bold);
        holder.tv_uname.setText(activitiesDataArray.get(position).getelector_name());
        holder.tv_udetails.setText(activitiesDataArray.get(position).getelector_description());

        holder.tv_fulldetails.setText(objectBAJava.underLineText("التفاصيل"));


        if (isselection) {
            if (activitiesDataArray.get(position).getisvoted()) {
                holder.rl_body_blur.setVisibility(View.GONE);
            } else {
                holder.rl_body_blur.setVisibility(View.VISIBLE);
            }
        }
        if (activitiesDataArray.get(position).getisselect()) {
            holder.iv_tick.setVisibility(View.VISIBLE);
        } else {
            holder.iv_tick.setVisibility(View.GONE);
        }

//        Glide.with(context)
//                .load(activitiesDataArray.get(position).getelector_image())
//                .override(600, 200) // resizes the image to these dimensions (in pixel). resize does not respect aspect ratio
//                .placeholder(R.drawable.profile_icon)
//                .error(R.drawable.profile_icon)
//                .into(holder.iv_profile);

        Picasso.get()
                .load(activitiesDataArray.get(position).getelector_image())
                .resize(100, 100)
                .transform(new CropCircleTransformation())
                .placeholder(R.drawable.profile_icon)
                .error(R.drawable.profile_icon)
                .into(holder.iv_profile);


//        fragment.Pagination(activitiesDataArray, position);

        holder.tv_fulldetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                fragment.goOnActivity(activitiesDataArray.get(position).getelector_id());
            }
        });

//        holder.rl_body_blur.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                fragment.goOnActivity(activitiesDataArray.get(position).getelector_id());
//            }
//        });

        holder.iv_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!isselection) {

                    if (!activitiesDataArray.get(position).getisvoted()) {
                        fragment.updateSelection(position);
                    }
                }
            }
        });

        return convertView;
    }

}



