package com.mersal.mersal.retrofit.otp;

import com.google.gson.annotations.SerializedName;
import com.mersal.mersal.retrofit.electors.Electorsdataelectors;

import java.util.ArrayList;

/**
 * Created by Muhammad_Umar_Ch on 07/12/2017.
 */

public class Otpdata {

    @SerializedName("code")
    private String code;

    public String getcode() {

        if (code == null) {
            return code = "";
        }
        return code;
    }


}
