package com.mersal.mersal.fcm;


import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.SystemClock;
import android.preference.PreferenceManager;
import android.support.annotation.RequiresApi;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.mersal.mersal.R;
import com.mersal.mersal.activites.dashboard.DashboardActivity;
import org.json.JSONObject;
import java.util.Random;
import io.realm.Realm;

import static com.mersal.mersal.activites.base.BaseActivity.objectBAJava;

public class MyFirebaseMessagingService extends FirebaseMessagingService {
    private static final String TAG = "FCM Service";
    public String typeVlaue = "";
    public Realm realm;
    String job_id = "", job_bid_id = "";
    String recipient_id_, sender_avatar_, sender_id_, sender_name_, type, title, message;
    NotificationManager notificationManager;

//    @Override
//    public void onDestroy() {
//        super.onDestroy();
//        //sendBroadcast(new Intent("YouWillNeverKillMe"));
//    }
//
//    @Override
//    public void onTaskRemoved(Intent rootIntent) {
//
//        System.out.println("its me here in this receiver1 ");
//        //create an intent that you want to start again.
//        Intent intent = new Intent(getApplicationContext(), MyFirebaseMessagingService.class);
//        PendingIntent pendingIntent = PendingIntent.getService(this, 1, intent, PendingIntent.FLAG_ONE_SHOT);
//        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
//        alarmManager.set(AlarmManager.RTC_WAKEUP, SystemClock.elapsedRealtime() + 5000, pendingIntent);
//        super.onTaskRemoved(rootIntent);
//    }

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        System.out.println("here is firebase");

        if (remoteMessage == null)
            return;

        if (remoteMessage.getNotification() != null) {
            Log.e(TAG, "Notification Body: " + remoteMessage.getNotification().getBody());
        }


        if (remoteMessage.getData().size() > 0) {
            Log.e(TAG, "Data: " + remoteMessage.getData().toString());
            System.out.println("its notifications message " + remoteMessage.getData() + " / " + remoteMessage.getData().toString());

            try {
                JSONObject json = new JSONObject(remoteMessage.getData());
                title = json.getString("title");
                message = json.getString("message");
                type = json.getString("type");
                System.out.println("Here is type of notif from fb " + type);
//                String data = json.getString("data");
//                try {
//                    JSONObject obj = new JSONObject(data);
//                    job_id = obj.getString("job_id");
//
//                    if (!type.equals("chat"))
//                        job_bid_id = obj.getString("job_bid_id");
//
//                    if (type.equals("chat")) {
//
//                        recipient_id_ = obj.getString("sender_id");
//                        sender_avatar_ = obj.getString("sender_avatar");
//                        sender_id_ = obj.getString("recipient_id");
//                        sender_name_ = obj.getString("sender_name");
//                    }
//
//                } catch (Exception t) {
//                    System.out.println("its notifications message issue " + t);
//                }

//                sendNotification(type, title, message);
                sendNotification(type, title, message);

            } catch (Exception e) {
                System.out.println("Value of crash " + e);
            }
        }
    }


    private void sendNotification(String type, String messageTitle, String messageBody) {

        Random random = new Random();
        int randomNo = random.nextInt(1000 + 1);

//        objectBAJava.finishAllActivities();
        Intent intent = null;
//        if (getDataintoUserinfoinfc().size() > 0) {
        Log.e("log", type);

        intent = new Intent(MyFirebaseMessagingService.this, DashboardActivity.class);
      //  intent = new Intent();
        intent.putExtra("title", title);
        intent.putExtra("message", message);
        intent.putExtra("type", type);
        intent.putExtra("isnotify", "yes");

        PendingIntent pendingIntent = PendingIntent.getActivity(this, randomNo, intent,
                PendingIntent.FLAG_ONE_SHOT);
        Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

        notificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        //Setting up Notification channels for android O and above
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            setupChannels();
        }
//
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this, getString(R.string.default_notification_channel_id))
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(messageTitle)
                .setContentText(messageBody)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setDefaults(NotificationCompat.DEFAULT_VIBRATE)
                .setStyle(new NotificationCompat.BigTextStyle()
                        .bigText(messageBody))
                .setSound(defaultSoundUri)
                .setContentIntent(pendingIntent)
                .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher))
                .setAutoCancel(true);

        NotificationManager notificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        notificationManager.notify(randomNo /* ID of notification */, notificationBuilder.build());
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void setupChannels() {
        CharSequence adminChannelName = "adminChannelName";
        String adminChannelDescription = "adminChannelDescription";

        NotificationChannel adminChannel;
        adminChannel = new NotificationChannel(getString(R.string.default_notification_channel_id), adminChannelName, NotificationManager.IMPORTANCE_DEFAULT);
        adminChannel.setDescription(adminChannelDescription);
        adminChannel.enableLights(true);
        adminChannel.setLightColor(Color.RED);
        adminChannel.enableVibration(true);
        if (notificationManager != null) {
            notificationManager.createNotificationChannel(adminChannel);
        }
    }


//    private void sendNotificationOreo(String type, String messageTitle, String messageBody) {
//        Random random = new Random();
//        int randomNo = random.nextInt(1000 + 1);
//        System.out.println("here is firebase Chanel");
//
////        objectBAJava.finishAllActivities();
//        Intent intent = null;
////        if (getDataintoUserinfoinfc().size() > 0) {
//        String channelId = getString(R.string.default_notification_channel_id);
//        intent = new Intent(MyFirebaseMessagingService.this, DashboardActivity.class);
//        intent.putExtra("title", title);
//        intent.putExtra("message", message);
//        intent.putExtra("type", type);
//        intent.putExtra("isnotify", "yes");
//
//        PendingIntent pendingIntent = PendingIntent.getActivity(this, randomNo, intent,
//                PendingIntent.FLAG_ONE_SHOT);
//        Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
//        NotificationCompat.Builder notificationBuilder =
//                new NotificationCompat.Builder(this, channelId)
//                        .setSmallIcon(R.mipmap.ic_launcher)
//                        .setContentTitle(messageTitle)
//                        .setContentText(messageBody)
//                        .setPriority(NotificationCompat.PRIORITY_HIGH)
//                        .setDefaults(NotificationCompat.DEFAULT_VIBRATE)
//                        .setStyle(new NotificationCompat.BigTextStyle()
//                                .bigText(messageBody))
//                        .setSound(defaultSoundUri)
//                        .setContentIntent(pendingIntent)
//                        .setAutoCancel(true);
//
//        NotificationManager notificationManager =
//                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
//
//        // Since android Oreo notification channel is needed.
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//            NotificationChannel channel = new NotificationChannel(channelId,
//                    "Channel human readable title",
//                    NotificationManager.IMPORTANCE_DEFAULT);
//            notificationManager.createNotificationChannel(channel);
//        }
//
//        notificationManager.notify(0 /* ID of notification */, notificationBuilder.build());
//    }


//    private void sendNotification(String type, String messageTitle, String messageBody) {
//
//        Random random = new Random();
//        int randomNo = random.nextInt(1000 + 1);
//
////        objectBAJava.finishAllActivities();
//        Intent intent = null;
////        if (getDataintoUserinfoinfc().size() > 0) {
//
//        intent = new Intent(MyFirebaseMessagingService.this, DashboardActivity.class);
//        intent.putExtra("title", title);
//        intent.putExtra("message", message);
//        intent.putExtra("type", type);
//        intent.putExtra("isnotify", "yes");
//
//        PendingIntent pendingIntent = PendingIntent.getActivity(this, randomNo, intent,
//                PendingIntent.FLAG_ONE_SHOT);
//        Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
//        NotificationCompat.Builder notificationBuilder =
//                new NotificationCompat.Builder(this)
//                        .setSmallIcon(R.mipmap.ic_launcher)
//                        .setContentTitle(messageTitle)
//                        .setContentText(messageBody)
//                        .setPriority(NotificationCompat.PRIORITY_HIGH)
//                        .setDefaults(NotificationCompat.DEFAULT_VIBRATE)
//                        .setStyle(new NotificationCompat.BigTextStyle()
//                                .bigText(messageBody))
//                        .setSound(defaultSoundUri)
//                        .setContentIntent(pendingIntent)
//                        .setAutoCancel(true);
//        NotificationManager notificationManager =
//                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
//        notificationManager.notify(randomNo, notificationBuilder.build());
//
//    }
}