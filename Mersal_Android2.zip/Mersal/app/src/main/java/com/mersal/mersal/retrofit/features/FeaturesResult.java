
package com.mersal.mersal.retrofit.features;


import com.google.gson.annotations.SerializedName;
import com.mersal.mersal.retrofit.Login.LoginResultdata;

public class FeaturesResult {


    private String details = "";


    public String getdetails() {
        return details;
    }

    private Boolean status = false;

    public Boolean getstatus() {
        return status;
    }

    public void setstatus(boolean status_) {

        status = status_;
    }


    public void setdetails(String details_) {
        details = details_;
    }

}