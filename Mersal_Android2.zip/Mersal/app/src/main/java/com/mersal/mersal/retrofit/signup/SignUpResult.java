package com.mersal.mersal.retrofit.signup;

import com.google.gson.annotations.SerializedName;
import com.mersal.mersal.retrofit.Login.LoginResultdata;


public class SignUpResult {
    @SerializedName("status")
    private Boolean status = false;

    @SerializedName("message")
    private String message = "";

    @SerializedName("data")
    private SignUpdata signUpdata;

    public SignUpdata getdata() {
        return signUpdata;
    }

    public Boolean getstatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

}

