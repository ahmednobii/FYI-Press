package com.mersal.mersal.retrofit.electorsdetails;

import com.google.gson.annotations.SerializedName;
import com.mersal.mersal.retrofit.electors.Electorsdataelectors;

import java.util.ArrayList;

/**
 * Created by Muhammad_Umar_Ch on 07/12/2017.
 */

public class ElectorsDetaildata {

    @SerializedName("elector")
    private ElectorDetailsDataElector electors;

    public ElectorDetailsDataElector getelectors() {
        return electors;
    }


}
