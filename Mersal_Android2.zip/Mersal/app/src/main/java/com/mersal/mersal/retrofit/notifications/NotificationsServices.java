package com.mersal.mersal.retrofit.notifications;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Muhammad_Umar_Ch on 07/12/2017.
 */

public class NotificationsServices {

    @SerializedName("id")
    private String id;

    @SerializedName("title")
    private String title;

    public String gettitle() {

        if (title == null) {
            return title = "";
        }
        return title;
    }

    public String getid() {

        if (id == null) {
            return id = "";
        }
        return id;
    }

    private Boolean status = false;

    public Boolean getstatus() {
        return status;
    }

    public void setstatus(boolean status_) {

        status = status_;
    }


}
