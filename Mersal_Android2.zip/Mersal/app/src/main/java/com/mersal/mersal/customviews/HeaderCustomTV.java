package com.mersal.mersal.customviews;

import android.content.Context;
import android.util.AttributeSet;

import com.mersal.mersal.R;

import static com.mersal.mersal.activites.base.BaseActivity.objectBAJava;


public class HeaderCustomTV extends android.support.v7.widget.AppCompatTextView {

    public HeaderCustomTV(Context context) {
        super(context);
    }

    public HeaderCustomTV(Context context, AttributeSet attrs) {
        super(context, attrs);

        this.setTypeface(objectBAJava.Tahoma_Regular_font);
        this.setTextColor(getResources().getColor(R.color.header_text_color_white));
//        this.setTextSize(getResources().getDimension(R.dimen.header_text_size));
    }

}