package com.mersal.mersal.retrofit.general;

import com.google.gson.annotations.SerializedName;
import com.mersal.mersal.retrofit.votinglist.VotingElections;

import java.util.ArrayList;

/**
 * Created by Muhammad_Umar_Ch on 07/12/2017.
 */

public class Citiesdata {


    @SerializedName("page")
    private int page;
    @SerializedName("per_page")
    private String per_page = "";
    @SerializedName("total_records")
    private String total_records = "";
    @SerializedName("filtered_records")
    private String filtered_records = "";

    @SerializedName("elections")
    private VotingElections elections;

    public int getpage() {

        return page;
    }

    public String getper_page() {

        if (per_page == null) {
            return "";
        }
        return per_page;
    }

    public String gettotal_records() {
        if (total_records == null) {
            return "";
        }
        return total_records;
    }

    public String getfiltered_records() {
        if (filtered_records == null) {
            return "";
        }
        return filtered_records;
    }

    public VotingElections getelections() {
        return elections;
    }


}
