package com.mersal.mersal.activites.auth;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.mersal.mersal.R;
import com.mersal.mersal.activites.base.BaseActivity;
import com.mersal.mersal.customviews.HeaderCustomTV;
import com.mersal.mersal.generic.Interfaces.Generic;

public class TermsActivity extends BaseActivity {

    HeaderCustomTV toolbar_title;
    CheckBox checkbox;
    boolean isChecked = false;
    Generic generic;
    RelativeLayout rl_body;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_terms_condition);
        if (TermsActivity.this instanceof BaseActivity) {
            generic = (Generic) TermsActivity.this;
        }
        init();
    }

    public void init() {
        RelativeLayout header_left_rl = (RelativeLayout) findViewById(R.id.header_left_rl);
        RelativeLayout rl_submit = (RelativeLayout) findViewById(R.id.rl_submit);
        ImageView back_arrow = (ImageView) findViewById(R.id.back_arrow);
        back_arrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                objectBAJava.hideStatusBar();
                finish();
                generic.animEnd();

            }
        });

        rl_body = findViewById(R.id.rl_body);
        rl_submit.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                if(isChecked) {
                    Intent mainIntent = new Intent(TermsActivity.this, SignupIdScanActivity.class);
                    startActivity(mainIntent);
                    overridePendingTransition(R.anim.start_slide_in_left, R.anim.start_slide_out_left);
                    objectBAJava.hideStatusBar();
                    finish();
                    generic.animEnd();
                }
                else{
                    generic.showSnackbar(rl_body, " ..الرجاء الموافقة على الشروط و الأحكام", Snackbar.LENGTH_LONG, "close", false);
                }
            }
        });

        TextView tv_allow = findViewById(R.id.tv_allow);
        tv_allow.setTypeface(objectBAJava.Tahoma_Regular_font);
        TextView tv_submit = findViewById(R.id.tv_submit);
        tv_submit.setTypeface(objectBAJava.Tahoma_Regular_font);
        checkbox = (CheckBox)findViewById(R.id.checkbox);
        checkbox.setOnCheckedChangeListener(new CheckBox.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                isChecked = checkbox.isChecked();
            }
        });
        toolbar_title = (HeaderCustomTV) findViewById(R.id.toolbar_title);
        toolbar_title.setText("الشروط و الأحكام ");
    }

}
