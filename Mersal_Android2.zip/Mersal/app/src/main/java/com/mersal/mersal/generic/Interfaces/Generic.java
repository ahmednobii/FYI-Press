package com.mersal.mersal.generic.Interfaces;

import android.app.Activity;
import android.content.Context;
import android.text.SpannableString;
import android.view.View;


import com.mersal.mersal.realm.UserInformation;

import java.util.HashMap;
import java.util.Map;

import io.realm.RealmResults;
import okhttp3.OkHttpClient;

/**
 * Created by MacBook on 09/03/2018.
 */
public interface Generic {

    void hideProgressBarInChat(View view);

    void showProgressBar(View view);

    String getDeviceToken();

    void hideProgressBar(View view);

    SpannableString underLineText(String value);

    void showSnackbar(View view, String message, int duration, String action, boolean status);

    void showAlertDiloge(String userMessage, Context context);

    void showToast(View view, String message, int duration, Context context);

    void finishActivity();

    OkHttpClient.Builder setHeaderForReqsForSaveServices();

    void finishAllActivities();

    void hideStatusBar();

    void hideStatusBarForAuth();

    RealmResults<UserInformation> getDataintoUserinfo();

    Map setBasicParams();

    OkHttpClient.Builder setHeaderForReqs();

    OkHttpClient.Builder setHeaderForReqsForServices();

    void genericCodes(View view, int code, String errorMessage, String dataArrayMessage, String btnText);

    void finishCurrentActivity(Activity activity);

    void animStart();

    void animEnd();

    String getAuthTockenFromDb();

    void deleteUserinfo();
}