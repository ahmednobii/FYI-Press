package com.mersal.mersal.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.mersal.mersal.R;
import com.mersal.mersal.retrofit.editprofile.EditProfileServices;

import java.util.ArrayList;


public class EditProfileFeaturesGridAdapter extends BaseAdapter {

    private ArrayList<EditProfileServices> list;
    Context context;
    private static LayoutInflater inflater = null;

    public EditProfileFeaturesGridAdapter(ArrayList<EditProfileServices> horizontalList, Context context) {
        this.list = horizontalList;
        this.context = context;
        this.inflater = (LayoutInflater) context.
                getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        if (list != null) {
            return list.size();
        } else {
            return 0;
        }
    }

    @Override
    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return position;
    }

    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return position;
    }

    public class Holder {
        public CheckBox cb_check;
        public TextView tv_uname;
        RelativeLayout rl_body;
        RelativeLayout rl_check;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        // TODO Auto-generated method stub
        Holder holder = new Holder();
        View view;

        view = inflater.inflate(R.layout.gd_item_editprofilefeatures, null);
        holder.cb_check = (CheckBox) view.findViewById(R.id.cb_check);
        holder.tv_uname = (TextView) view.findViewById(R.id.tv_uname);
        holder.rl_body = (RelativeLayout) view.findViewById(R.id.rl_body);
        holder.rl_check = (RelativeLayout) view.findViewById(R.id.rl_check);


        holder.tv_uname.setText(list.get(position).gettitle());

        if (list.get(position).getstatus()) {

            holder.cb_check.setChecked(true);

        } else {

            holder.cb_check.setChecked(false);
        }

        holder.rl_check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


            }
        });
        holder.rl_body.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        view.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

//                Intent g = new Intent(context, ThankYouActivity.class);
//                context.startActivity(g);

//                Toast.makeText(context, "You Clicked " + result[position], Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }

}