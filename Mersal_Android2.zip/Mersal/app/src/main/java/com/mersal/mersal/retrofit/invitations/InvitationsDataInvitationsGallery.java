package com.mersal.mersal.retrofit.invitations;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Muhammad_Umar_Ch on 07/12/2017.
 */

public class InvitationsDataInvitationsGallery {

    @SerializedName("image_path")
    private String image_path;
    @SerializedName("image_text")
    private String image_text = "";
//    @SerializedName("left")
//    private double left ;
//    @SerializedName("top")
//    private double top ;

    public String getimage_path() {
        if (image_path == null || image_path.equals("")) {
            return "https://";
        }
        return image_path;
    }

    public String getimage_text() {

        if (image_text == null) {
            return "";
        }
        return image_text;
    }

//    public double getleft() {
//        return left;
//    }
//
//    public double gettop() {
//        return top;
//    }

}
