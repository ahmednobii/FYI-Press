package com.mersal.mersal.retrofit.electors;

import com.google.gson.annotations.SerializedName;
import com.mersal.mersal.retrofit.votinglist.VotingElections;

import java.util.ArrayList;

/**
 * Created by Muhammad_Umar_Ch on 07/12/2017.
 */

public class Electorsdata {

    @SerializedName("electors")
    private ArrayList<Electorsdataelectors> electors;

    public ArrayList<Electorsdataelectors> getelectors() {
        return electors;
    }

    @SerializedName("election")
    private Electorsdataelection election;

    public Electorsdataelection getelection() {
        return election;
    }

    @SerializedName("user")
    private ElectorsdataUser user;

    public ElectorsdataUser getuser() {
        return user;
    }

    @SerializedName("document_status")
    private String document_status;

    public String getdocument_status() {

        if (document_status == null) {

            return document_status = "";
        }
        return document_status;
    }

    @SerializedName("user_status")
    private String user_status;

    public String getuser_status() {

        if (user_status == null) {

            return user_status = "";
        }
        return user_status;
    }
}
