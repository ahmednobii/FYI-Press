package com.mersal.mersal.retrofit.votinglist;

import com.google.gson.annotations.SerializedName;
import com.mersal.mersal.retrofit.general.Citiesdata;

import java.util.ArrayList;


public class VotingResult {
    @SerializedName("status")
    private Boolean status = false;

    @SerializedName("message")
    private String message = "";

    @SerializedName("data")
    private Votingdata data;

    public Boolean getstatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public Votingdata getdata() {
        return data;
    }


}