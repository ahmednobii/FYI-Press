package com.mersal.mersal.retrofit.otp;

import com.google.gson.annotations.SerializedName;
import com.mersal.mersal.retrofit.electors.Electorsdata;


public class OtpResult {
    @SerializedName("status")
    private Boolean status = false;

    @SerializedName("message")
    private String message = "";

    @SerializedName("data")
    private Otpdata data;

    public Boolean getstatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public Otpdata getdata() {
        return data;
    }


}