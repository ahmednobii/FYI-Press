package com.mersal.mersal.retrofit.electors;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Muhammad_Umar_Ch on 07/12/2017.
 */

public class Electorsdataelectors {

    @SerializedName("election_id")
    private String election_id;
    @SerializedName("id")
    private String id = "";
    @SerializedName("elector_id")
    private String elector_id = "";
    @SerializedName("elector_name")
    private String elector_name = "";
    @SerializedName("elector_description")
    private String elector_description;
    @SerializedName("elector_detail")
    private String elector_detail;
    @SerializedName("elector_image")
    private String elector_image;

    public boolean isselect = false;

    public boolean getisselect() {

        return isselect;
    }

    public void setisselect(boolean value) {

        isselect = value;
    }

    public boolean isvoted = false;

    public boolean getisvoted() {

        return isvoted;
    }

    public void setisvoted(boolean value) {

        isvoted = value;
    }

    public String getelector_detail() {
        if (elector_detail == null) {
            return "";
        }
        return elector_detail;
    }

    public String getelector_image() {
        if (elector_image == null || elector_image.equals("")) {
            return "https://";
        }
        return elector_image;
    }

    public String getelection_id() {
        if (election_id == null) {
            return "";
        }
        return election_id;
    }

    public String getid() {

        if (id == null) {
            return "";
        }
        return id;
    }

    public String getelector_id() {
        if (elector_id == null) {
            return "";
        }
        return elector_id;
    }

    public String getelector_name() {
        if (elector_name == null) {
            return "";
        }
        return elector_name;
    }

    public String getelector_description() {
        if (elector_description == null) {
            return "";
        }
        return elector_description;
    }

}
