package com.mersal.mersal.activites.auth;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.text.InputFilter;
import android.text.Spanned;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.mersal.mersal.R;
import com.mersal.mersal.activites.base.BaseActivity;
import com.mersal.mersal.activites.dashboard.DashboardActivity;
import com.mersal.mersal.customviews.HeaderCustomTV;
import com.mersal.mersal.customviews.NoDataFoundCustomTV;
import com.mersal.mersal.generic.Interfaces.Generic;
import com.mersal.mersal.internetconnections.NetworkConnection;
import com.mersal.mersal.realm.UserInformation;
import com.mersal.mersal.retrofit.baseapi.ApiService;
import com.mersal.mersal.retrofit.baseapi.AppWebServices;
import com.mersal.mersal.retrofit.defualt.DefaultResult;
import com.mersal.mersal.retrofit.signup.SignUpResult;
import com.mersal.mersal.retrofit.signup.SignUpdata;
import com.mersal.mersal.utilties.StaticStrings;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Map;
import java.util.Random;

import io.realm.Realm;
import io.realm.RealmResults;
import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static com.mersal.mersal.activites.auth.SignUpActivity.SignUpActivityObject;
import static com.mersal.mersal.activites.auth.SignUpPreActivity.SignUpPreActivityObject;
import static com.mersal.mersal.activites.auth.SigninActivity.objsigninActivityObject;
import static com.mersal.mersal.activites.auth.SignupIdScanActivity.ObjSignupIdScanActivity;
import static com.mersal.mersal.activites.auth.SignupIdScanActivity.docimageencode_BACK_ForSignup;
import static com.mersal.mersal.activites.auth.SignupIdScanActivity.docimageencode_FRONT_ForSignup;
import static com.mersal.mersal.utilties.StaticStrings.ISFROMFEDITPROFILE;

public class OtpVerificationActivity extends BaseActivity {

    TextView tv_uname, tv_sendotp, tv_submit, tv_ph;
    RelativeLayout rl_submit, rl_forotp, rl_body, header_left_rl, rl_sendotp;
    String st_otp;
    EditText et_email, et_ph;
    ProgressBar progressBar;
    String st_sname = "", st_familyname = "", st_fname = "", st_gender = "", st_dob = "", st_ph = "", st_blood = "", st_email = "";
    NoDataFoundCustomTV tv_noresult;
    public static OtpVerificationActivity OtpVerificationActivityObject;
    NetworkConnection ntobj = new NetworkConnection(OtpVerificationActivity.this);
    Generic generic;
    ImageView back_arrow;
    HeaderCustomTV toolbar_title;
    String st_username, st_pwd = "";
    public static int APP_REQUEST_CODE = 99;
    String id_name = "", civil_number = "", expiry_date = "";
    static int random_numbers = 0;
    int otpnumber = 0;
    public ArrayList<UserInformation> userProfile = new ArrayList<>();
    private String blockCharacterSet = ".';][}{*&^%$#@!~#^|$%&*!;,N-_()<> ";
    Realm realm;
    String st_phone;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp_verification);
        if (OtpVerificationActivity.this instanceof BaseActivity) {
            generic = (Generic) OtpVerificationActivity.this;
        }

        generic.hideStatusBarForAuth();
        OtpVerificationActivityObject = this;
        Bundle extras = getIntent().getExtras();
        if (extras != null) {

            st_phone = extras.getString("phone");
            st_fname = extras.getString("fname");
            st_dob = extras.getString("iddob");
            st_gender = extras.getString("gender");
            st_blood = extras.getString("Blood");
            st_username = extras.getString("username");
            st_pwd = extras.getString("password");
            st_email = extras.getString("email");
            id_name = extras.getString("idname");
            civil_number = extras.getString("id_number");
            expiry_date = extras.getString("expiry_date");

            //            st_sname = extras.getString("sname");
//            st_familyname = extras.getString("familyname");
            //            st_ph = extras.getString("ph");
        }
        init();
        clickListener();
        st_ph = st_phone;
       // generic.showSnackbar(rl_body, st_ph, Snackbar.LENGTH_LONG, "close", false);
        apiCheckPhonenumber();
//        callOTPSendSmsAPI();
        objectBAJava.hideKeyboard();
    }

    public void init() {
        header_left_rl = (RelativeLayout) findViewById(R.id.header_left_rl);
        rl_sendotp = (RelativeLayout) findViewById(R.id.rl_sendotp);
        tv_uname = (TextView) findViewById(R.id.tv_uname);
        tv_sendotp = (TextView) findViewById(R.id.tv_sendotp);
        tv_submit = (TextView) findViewById(R.id.tv_submit);
        tv_ph = (TextView) findViewById(R.id.tv_ph);
        rl_submit = (RelativeLayout) findViewById(R.id.rl_submit);
        rl_body = (RelativeLayout) findViewById(R.id.rl_body);
        rl_forotp = (RelativeLayout) findViewById(R.id.rl_forotp);
        et_email = (EditText) findViewById(R.id.et_email);
        et_ph = (EditText) findViewById(R.id.et_ph);
        et_ph.setTypeface(objectBAJava.Tahoma_Regular_font);
        et_email.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_uname.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_sendotp.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_submit.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_ph.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_noresult = (NoDataFoundCustomTV) findViewById(R.id.tv_noresult);
        toolbar_title = (HeaderCustomTV) findViewById(R.id.toolbar_title);
        back_arrow = (ImageView) findViewById(R.id.back_arrow);
        toolbar_title.setText("OTP تأكيد رمز");
        back_arrow.setVisibility(View.VISIBLE);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        progressBar.setVisibility(View.GONE);
        rl_forotp.setVisibility(View.GONE);
        et_ph.setFilters(new InputFilter[]{filter});
        et_email.setFilters(new InputFilter[]{filter});
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT) {
            progressBar.getIndeterminateDrawable().setColorFilter(getResources()
                    .getColor(R.color.progress_bar_color_white), PorterDuff.Mode.SRC_IN);
        }
        Realm.init(this);    //initialize to access database for this activity
        realm = Realm.getDefaultInstance();
        et_ph.setText(st_phone);
//        et_email.setText(st_code);


    }

    public void clickListener() {
        rl_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                hideKeyboard();
                velidationforOtp();

            }
        });
        rl_sendotp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                velidationForPhone();
            }
        });

        back_arrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                hideKeyboard();
                finish();
                generic.animEnd();

            }
        });
    }

    public void velidationForPhone() {

        st_ph = et_ph.getText().toString();
        if (st_ph.trim().equals("")) {
            et_ph.setError("رقم الهاتف مطلوب");
            et_ph.requestFocus();
        } else {
            if (ntobj.isConnectingToInternet()) {
                hideKeyboard();
                apiCheckPhonenumber();
            } else {
                String Message = PreferenceManager.getDefaultSharedPreferences(OtpVerificationActivity.this).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
                generic.showSnackbar(rl_body, Message, Snackbar.LENGTH_LONG, "close", false);
            }
        }
    }

    public void velidationforOtp() {
        st_otp = et_email.getText().toString();
        if (!st_otp.trim().equals("")) {
            try {
                otpnumber = Integer.parseInt(st_otp);
            } catch (Exception e) {
                //  generic.showSnackbar(rl_body, e.toString(), Snackbar.LENGTH_LONG, "close", false);
            }
        }
        if (st_otp.trim().equals("")) {
            et_email.requestFocus();
            et_email.setError(" مطلوب OTP رمز");
        } else if (random_numbers != otpnumber) {

            et_email.requestFocus();
            et_email.setError("مطلوب رمز Otp الصحيح");

        } else {
            if (ntobj.isConnectingToInternet()) {

                apiSignUp();

            } else {
                String Message = PreferenceManager.getDefaultSharedPreferences(OtpVerificationActivity.this).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
                generic.showSnackbar(rl_body, Message, Snackbar.LENGTH_LONG, "close", false);
            }
        }
    }

    public void apiOTPSendCode() {
        generic.showProgressBar(progressBar);
        Map<String, String> params = generic.setBasicParams();
//        params.put("UserId", "lawati_webser");
//        params.put("Password", "Lawati@789");
        params.put("UserId", "lawatimrsal_ws");
        params.put("Password", "Lawatim@789");
        params.put("MobileNo", st_ph);
        params.put("Message", " رمز التحقق الخاص بك لتطبيق لواتي مرسال هو " + random_numbers);
        params.put("Lang", String.valueOf(64));

//        https://www.ismartsms.net/iBulkSMS/HttpWS/SMSDynamicAPI.aspx?UserId=lawati_webser&Password=Lawati@789&MobileNo=96892985363&Message=TestMessage&Lang=0

        OkHttpClient client = generic.setHeaderForReqs().build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(AppWebServices.BASE_URL_FOR_OTP)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();
        ApiService service = retrofit.create(ApiService.class);
        Call<String> call = service.OTP(params);
        call.enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, retrofit2.Response<String> response) {

                generic.hideProgressBar(progressBar);
//                rl_body.setVisibility(View.GONE);
//                tv_noresult.setVisibility(View.GONE);

                int num = Integer.parseInt(response.body());
                if (num == 1) {
                    tv_sendotp.setText("إعادة إرسال الرمز");
                    rl_body.setVisibility(View.VISIBLE);
                    rl_forotp.setVisibility(View.VISIBLE);
                    generic.showSnackbar(progressBar, " لقد تم إرسال الرمز إلى الرقم " + st_ph, Snackbar.LENGTH_LONG, "close", true);

                } else if (num == 9) {
//                    tv_noresult.setVisibility(View.VISIBLE);
//                    tv_noresult.setText(st_ph + " رقم الجوال غير صالح ");
                    generic.showSnackbar(progressBar, " رقم الجوال غير صالح " + st_ph, Snackbar.LENGTH_LONG, "close", false);

                } else {

//                    tv_noresult.setVisibility(View.VISIBLE);
//                    tv_noresult.setText("خطأ غير معروف");
                    generic.showSnackbar(progressBar, "خطأ غير معروف ", Snackbar.LENGTH_LONG, "close", false);

                }

//                if (response.code() == 200) {
//
//
//
//                }  else {
//
//                    try {
//
//                        String userMessage = PreferenceManager.getDefaultSharedPreferences(OtpVerificationActivity.this).getString("oops", "هناك خطأ ما");
//                        JSONObject jObjError = new JSONObject(response.errorBody().string());
//                        try {
//                            userMessage = jObjError.getString("message");
//                        } catch (Exception e) {
//                        }
//
//                        String dataArrayMessage = "";
//                        try {
//                            JSONArray jsonArray = jObjError.getJSONArray("LoginResultdata");
//                            for (int i = 0; i < jsonArray.length(); i++) {
//                                dataArrayMessage = dataArrayMessage + jsonArray.getString(i) + "\n";
//                            }
//
//                        } catch (Exception e) {
//                        }
//
//                        String maintenanceBtnText = "Try Again";
//                        try {
//                            maintenanceBtnText = jObjError.optString("btn_text");
//                        } catch (Exception e) {
//                        }
//                        generic.genericCodes(rl_body, response.code(), userMessage, dataArrayMessage, maintenanceBtnText);
//                    } catch (Exception e) {
//
//                        generic.showSnackbar(progressBar, "هناك خطأ ما", Snackbar.LENGTH_LONG, "close", false);
//
//                    }
//                }
            }

            @Override
            public void onFailure(Call<String> call, Throwable t) {
//                tv_noresult.setVisibility(View.VISIBLE);
                generic.hideProgressBar(progressBar);
                generic.showSnackbar(progressBar, "هناك خطأ ما", Snackbar.LENGTH_LONG, "close", false);

            }
        });
    }

    public void callOTPSendSmsAPI() {

        if (ntobj.isConnectingToInternet()) {
//            rl_body.setVisibility(View.GONE);
            generic.showProgressBar(progressBar);
            tv_noresult.setVisibility(View.GONE);
//            Random r = new Random();
//            random_numbers = r.nextInt(8020 - 6215) + 6431;
            try {
                random_numbers = Integer.parseInt(getRandomNumberString());
            } catch (Exception e) {
            }
            System.out.println("here is otp code : " + random_numbers);
            apiOTPSendCode();
        } else {
//            rl_body.setVisibility(View.GONE);
            tv_noresult.setVisibility(View.VISIBLE);
            generic.hideProgressBar(progressBar);
            String Message = PreferenceManager.getDefaultSharedPreferences(OtpVerificationActivity.this).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
            generic.showSnackbar(rl_body, Message, Snackbar.LENGTH_LONG, "close", false);
        }
    }

    public void apiSignUp() {
        generic.showProgressBar(progressBar);
        OkHttpClient client = generic.setHeaderForReqs().build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(AppWebServices.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();
        ApiService service = retrofit.create(ApiService.class);
//        Call<DefaultResult> call = service.register(params);
        Call<SignUpResult> call = service.registernew(st_username, st_fname, st_ph, st_pwd,
                st_pwd, st_gender, st_blood, st_dob, st_email, docimageencode_FRONT_ForSignup,
                "jpg", docimageencode_BACK_ForSignup, "jpg", id_name, expiry_date, civil_number,
                StaticStrings.DEVICE_TYPE.toString(), Build.MODEL, Build.VERSION.RELEASE);

        call.enqueue(new Callback<SignUpResult>() {
            @Override
            public void onResponse(Call<SignUpResult> call, retrofit2.Response<SignUpResult> response) {

                generic.hideProgressBar(progressBar);
                int code = response.code();
                if (response.code() == 200) {
                    Boolean status = response.body().getstatus();
                    String message = response.body().getMessage();

                    if (status) {
//                        generic.showSnackbar(rl_body, message, Snackbar.LENGTH_LONG, "close", true);
                        userProfile.clear();
                        SignUpdata data = response.body().getdata();
                        UserInformation object = new UserInformation();
                        object.setemail(data.getEmail());
                        object.setaddress(data.getaddress());
                        object.setauthtocken(data.getauth_token());
                        object.setdob(data.getdob());
                        object.setgender(data.getgender());
                        object.setpassword(st_pwd);
                        object.setName(data.getuser_name());
                        object.setuserid(data.getuser_id());
                        object.setId(1);
                        object.setis_vendor(data.getisvendor());
                        addDataintoUserinfo(object);
                        userProfile.add(object);
                        PreferenceManager.getDefaultSharedPreferences(OtpVerificationActivity.this).edit().putBoolean("servicesstatus", data.getadd_services()).apply();
                        PreferenceManager.getDefaultSharedPreferences(OtpVerificationActivity.this).edit().putString("username", data.getuser_name()).apply();
                        PreferenceManager.getDefaultSharedPreferences(OtpVerificationActivity.this).edit().putString("documentstatus", data.getdocument_status()).apply();
                        PreferenceManager.getDefaultSharedPreferences(OtpVerificationActivity.this).edit().putBoolean("firstTimeLogin", true).apply();
//                        if (data.getadd_services()) {
                            Intent g = new Intent(OtpVerificationActivity.this, DashboardActivity.class);
                            startActivity(g);

                            overridePendingTransition(R.anim.start_slide_in_left, R.anim.start_slide_out_left);
                            try {
                                objsigninActivityObject.finish();
                            } catch (Exception e) {
                            }
                            try {
                                ObjSignupIdScanActivity.finish();
                            } catch (Exception e) {
                            }
                            try {
                                SignUpPreActivityObject.finish();
                            } catch (Exception e) {
                            }
                            try {
                                SignUpActivityObject.finish();
                            } catch (Exception e) {
                            }
                            try {
                                OtpVerificationActivityObject.finish();
                            } catch (Exception e) {
                            }
//                        } else {
//                            ISFROMFEDITPROFILE = false;
////                            Intent g = new Intent(OtpVerificationActivity.this, FeaturesActivity.class);
//                            Intent g = new Intent(OtpVerificationActivity.this, DashboardActivity.class);
//                            startActivity(g);
//                            overridePendingTransition(R.anim.start_slide_in_left, R.anim.start_slide_out_left);
//                            try {
//                                objsigninActivityObject.finish();
//                            } catch (Exception e) {
//                            }
//                            try {
//                                ObjSignupIdScanActivity.finish();
//                            } catch (Exception e) {
//                            }
//                            try {
//                                SignUpPreActivityObject.finish();
//                            } catch (Exception e) {
//                            }
//                            try {
//                                SignUpActivityObject.finish();
//                            } catch (Exception e) {
//                            }
//                            try {
//                                OtpVerificationActivityObject.finish();
//                            } catch (Exception e) {
//                            }
//                        }

                    } else {

                        generic.showSnackbar(rl_body, message, Snackbar.LENGTH_LONG, "close", false);

                    }
                } else if (response.code() == 401) {
                    try {
                        RealmResults<UserInformation> results = getDataintoUserinfo();
                        if (results.size() > 0) {
                            deleteUserinfo();
                            PreferenceManager.getDefaultSharedPreferences(OtpVerificationActivity.this).edit().putBoolean("firstTimeLogin", false).apply();
                        }
                        String userMessage = PreferenceManager.getDefaultSharedPreferences(OtpVerificationActivity.this).getString("oops", "هناك خطأ ما");
                        try {

//                            String dataArrayMessage = "";
//                            try {
//                                ArrayList<String> message = response.body().getmessage();
//                                for (int i = 0; i < message.size(); i++) {
//                                    dataArrayMessage = dataArrayMessage + message.get(i) + "\n";
//                                }
//
//                            } catch (Exception e) {
//                            }

                            JSONObject jObjError = new JSONObject(response.errorBody().string());
                            String errorMessage = jObjError.getString("message");
//                            errorMessage = response.body().getMessage();
                            if (errorMessage != null && !errorMessage.equals("")) {
                                userMessage = errorMessage;
                            }
                        } catch (Exception e) {
                        }
                        String OK = PreferenceManager.getDefaultSharedPreferences(OtpVerificationActivity.this).getString("ok", "موافق");
                        AlertDialog alert = new AlertDialog.Builder(OtpVerificationActivity.this)
                                .create();
                        alert.setMessage(userMessage);
                        alert.setButton(DialogInterface.BUTTON_POSITIVE, OK, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {

                                dialog.dismiss();

                            }
                        });
                        alert.show();

                    } catch (Exception e) {

                        String userMessage = PreferenceManager.getDefaultSharedPreferences(OtpVerificationActivity.this).getString("oops", "هناك خطأ ما");
                        showSnackbar(rl_body, userMessage, Snackbar.LENGTH_LONG, "close", false);
                    }

                } else {

                    try {

                        String userMessage = PreferenceManager.getDefaultSharedPreferences(OtpVerificationActivity.this).getString("oops", "هناك خطأ ما");
                        JSONObject jObjError = new JSONObject(response.errorBody().string());
                        try {
                            userMessage = jObjError.getString("message");
                        } catch (Exception e) {
                        }

                        String dataArrayMessage = "";
                        try {
                            JSONArray jsonArray = jObjError.getJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                dataArrayMessage = dataArrayMessage + jsonArray.getString(i) + "\n";
                            }

                        } catch (Exception e) {
                        }

                        String maintenanceBtnText = "Try Again";
                        try {
                            maintenanceBtnText = jObjError.optString("btn_text");
                        } catch (Exception e) {
                        }
                        generic.genericCodes(rl_body, response.code(), userMessage, dataArrayMessage, maintenanceBtnText);
                    } catch (Exception e) {

                        generic.showSnackbar(progressBar, "هناك خطأ ما", Snackbar.LENGTH_LONG, "close", false);

                    }


                }
            }

            @Override
            public void onFailure(Call<SignUpResult> call, Throwable t) {

                generic.hideProgressBar(progressBar);
                generic.showSnackbar(progressBar, "هناك خطأ ما", Snackbar.LENGTH_LONG, "close", false);

            }
        });
    }

    public RealmResults<UserInformation> getDataintoUserinfo(String user_id) {
        realm.beginTransaction();  //open the database
        RealmResults<UserInformation> results = realm.where(UserInformation.class).equalTo("id", 1).findAllAsync();
        results.load();
        realm.commitTransaction();
        return results;
    }

    public void deleteUserinfo(String user_id) {

        realm.beginTransaction();  //open the database

        final RealmResults<UserInformation> results = realm.where(UserInformation.class).equalTo("id", 1).findAll();
        results.deleteAllFromRealm();
        realm.commitTransaction();
    }

    public void addDataintoUserinfo(UserInformation obj_) {

        RealmResults<UserInformation> results = getDataintoUserinfo(obj_.getuserid());
        if (results.size() > 0) {
            deleteUserinfo("1");
            addDataintoUserinfo(obj_);
        } else {
            realm.beginTransaction();  //open the database
            //database operation
            UserInformation obj = realm.createObject(UserInformation.class);
            obj.setId(obj_.getId());
            obj.setName(obj_.getName());
            obj.setemail(obj_.getemail());
            obj.setpassword(obj_.getpassword());
            obj.setaddress(obj_.getaddress());
            obj.setauthtocken(obj_.getauthtocken());
            obj.setdob(obj_.getdob());
            obj.setis_vendor(obj_.getis_vendor());
            obj.setuserid(obj_.getuserid());
            obj.setgender(obj_.getgender());
            //inserted all Data to database
            realm.commitTransaction(); //close the database
        }
    }

    public void apiCheckPhonenumber() {
        generic.showProgressBar(progressBar);
        Map<String, String> params = generic.setBasicParams();
        params.put("phone", st_ph);
        OkHttpClient client = generic.setHeaderForReqs().build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(AppWebServices.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();
        ApiService service = retrofit.create(ApiService.class);
        Call<DefaultResult> call = service.phonenumber(params);
        call.enqueue(new Callback<DefaultResult>() {

            @Override
            public void onResponse(Call<DefaultResult> call, retrofit2.Response<DefaultResult> response) {
                if (response.code() == 200) {

                    Boolean status = response.body().getstatus();
                    String Message = response.body().getMessage();

                    if (status) {
                        generic.hideProgressBar(progressBar);
                        hideKeyboard();
//                        Intent intent = new Intent(SignUpPreActivity.this, SignUpActivity.class);
//                        intent.putExtra("fname", st_fname);
//                        intent.putExtra("sname", st_sname);
//                        intent.putExtra("familyname", st_familyname);
//                        intent.putExtra("iddob", st_dob);
//                        intent.putExtra("ph", st_ph);
//                        intent.putExtra("gender", st_gender);
//                        intent.putExtra("Blood", st_blood);
//                        intent.putExtra("idname", id_name);
//                        intent.putExtra("id_number", civil_number);
//                        intent.putExtra("expiry_date", expiry_date);
//                        intent.putExtra("id_front", docimageencode_FRONT);
//                        intent.putExtra("id_back", docimageencode_BACK);

                        callOTPSendSmsAPI();


                    } else {
                        generic.hideProgressBar(progressBar);
                        Snackbar snackbar = Snackbar.make(rl_body, Message, Snackbar.LENGTH_LONG);
                        snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
                        snackbar.show();
                    }

                } else {
                    generic.hideProgressBar(progressBar);
                    try {

                        generic.hideProgressBar(progressBar);
                        String userMessage = PreferenceManager.getDefaultSharedPreferences(OtpVerificationActivity.this).getString("oops", "هناك خطأ ما");
                        JSONObject jObjError = new JSONObject(response.errorBody().string());
                        try {
                            userMessage = jObjError.getString("message");
                        } catch (Exception e) {
                        }

                        String dataArrayMessage = "";
                        try {
                            JSONArray jsonArray = jObjError.getJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                dataArrayMessage = dataArrayMessage + jsonArray.getString(i) + "\n";
                            }

                        } catch (Exception e) {
                        }


                        String maintenanceBtnText = "Try Again";
                        try {
                            maintenanceBtnText = jObjError.optString("btn_text");
                        } catch (Exception e) {
                        }

                        generic.genericCodes(rl_body, response.code(), userMessage, dataArrayMessage, maintenanceBtnText);

                    } catch (Exception e) {

                        generic.hideProgressBar(progressBar);
                        Snackbar snackbar = Snackbar.make(rl_body, PreferenceManager.getDefaultSharedPreferences(OtpVerificationActivity.this).getString("oops", "هناك خطأ ما"), Snackbar.LENGTH_LONG);
                        snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
                        snackbar.show();

                    }
                }
            }

            @Override
            public void onFailure(Call<DefaultResult> call, Throwable t) {
                generic.hideProgressBar(progressBar);
                Snackbar snackbar = Snackbar.make(rl_body, PreferenceManager.getDefaultSharedPreferences(OtpVerificationActivity.this).getString("oops", "هناك خطأ ما"), Snackbar.LENGTH_LONG);
                snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
                snackbar.show();
            }
        });
    }

    private InputFilter filter = new InputFilter() {

        @Override
        public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {

            if (source != null && blockCharacterSet.contains(("" + source))) {
                return "";
            }
            return null;
        }
    };

    public static String getRandomNumberString() {
        // It will generate 6 digit random Number.
        // from 0 to 999999
        Random rnd = new Random();
        int number = rnd.nextInt(999999);

        // this will convert any number sequence into 6 character.
        return String.format("%06d", number);
    }

//    public void phoneLogin(final View view) {
//        final Intent intent = new Intent(OtpVerificationActivity.this, AccountKitActivity.class);
//        AccountKitConfiguration.AccountKitConfigurationBuilder configurationBuilder =
//                new AccountKitConfiguration.AccountKitConfigurationBuilder(
//                        LoginType.PHONE,
//                        AccountKitActivity.ResponseType.CODE); // or .ResponseType.TOKEN
//        // ... perform additional configuration ...
//        intent.putExtra(
//                AccountKitActivity.ACCOUNT_KIT_ACTIVITY_CONFIGURATION,
//                configurationBuilder.build());
//        startActivityForResult(intent, APP_REQUEST_CODE);
//    }
//
//    @Override
//    protected void onActivityResult(
//            final int requestCode,
//            final int resultCode,
//            final Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//        if (requestCode == APP_REQUEST_CODE) { // confirm that this response matches your request
//            AccountKitLoginResult loginResult = data.getParcelableExtra(AccountKitLoginResult.RESULT_KEY);
//            String toastMessage;
//            if (loginResult.getError() != null) {
//                toastMessage = loginResult.getError().getErrorType().getMessage();
////                showErrorActivity(loginResult.getError());
//            } else if (loginResult.wasCancelled()) {
//                toastMessage = "Login Cancelled";
//            } else {
//                if (loginResult.getAccessToken() != null) {
//                    toastMessage = "Success:" + loginResult.getAccessToken().getAccountId();
//                } else {
//                    toastMessage = String.format(
//                            "Success:%s...",
//                            loginResult.getAuthorizationCode().substring(0, 10));
//                }
//
//                // If you have an authorization code, retrieve it from
//                // loginResult.getAuthorizationCode()
//                // and pass it to your server and exchange it for an access token.
//
//                // Success! Start your next activity...
////                goToMyLoggedInActivity();
//            }
//
//            // Surface the result to your user in an appropriate way.
//            Toast.makeText(
//                    this,
//                    toastMessage,
//                    Toast.LENGTH_LONG)
//                    .show();
//        }
//
////        AccountKit.logOut();
//    }
//
//    public void getAceessacebook() {
//
//        AccessToken accessToken = AccountKit.getCurrentAccessToken();
//
//        if (accessToken != null) {
//            //Handle Returning User
//        } else {
//            //Handle new or logged out user
//        }
//    }

}
