package com.mersal.mersal.activites.editprofile;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.provider.Settings;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.mersal.mersal.R;
import com.mersal.mersal.activites.auth.FeaturesActivity;
import com.mersal.mersal.activites.base.BaseActivity;
import com.mersal.mersal.adapter.EditProfileFeaturesGridAdapter;
import com.mersal.mersal.adapter.EditProfileFeaturesRVAdapter;
import com.mersal.mersal.customviews.HeaderCustomTV;
import com.mersal.mersal.customviews.NoDataFoundCustomTV;
import com.mersal.mersal.generic.Interfaces.Generic;
import com.mersal.mersal.internetconnections.NetworkConnection;
import com.mersal.mersal.realm.UserInformation;
import com.mersal.mersal.retrofit.baseapi.ApiService;
import com.mersal.mersal.retrofit.baseapi.AppWebServices;
import com.mersal.mersal.retrofit.defualt.DefaultResult;
import com.mersal.mersal.retrofit.editprofile.EditProfileResult;
import com.mersal.mersal.retrofit.editprofile.EditProfileServices;
import com.mersal.mersal.utilties.ExpandableHeightGridView;
import com.mersal.mersal.utilties.StaticStrings;
import com.squareup.picasso.MemoryPolicy;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Map;

import io.realm.Realm;
import io.realm.RealmResults;
import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static com.mersal.mersal.utilties.RealPathUtil.realPathUtil;
import static com.mersal.mersal.utilties.StaticStrings.ISFROMFEDITPROFILE;

public class EditProfileActivity extends BaseActivity {

    TextView tv_blood, tv_features_edit, tv_submit, tv_dob, tv_gender;
    CheckBox cb_check_one, cb_check_four, cb_check_two, cb_check_three;
    TextView tv_fname_title, tv_one, tv_ph_title, tv_three_three, tv_two, tv_four, tv_dob_title, tv_features_title, tv_bt_title, tv_name, tv_sname_title, tv_fmname_title, tv_email_title;
    RelativeLayout rl_submit, r1_two_gender_tv, r1_two_blood_tv, rl_body, header_left_rl;
    String st_email = "", st_sname = "", st_familyname = "", st_fname = "", st_gender = "", st_dob = "", st_ph = "", st_blood = "", st_imageurl = "";
    EditText et_name, et_sname, et_fname, et_ph, et_email;
    ProgressBar progressBar;
    String st_code = "", st_pwd = "", st_username = "";
    NoDataFoundCustomTV tv_noresult;
    RelativeLayout rl_slct_four, rl_slct_one, rl_slct_three, rl_slct_two;
    public static EditProfileActivity objEditProfileActivity;
    Generic generic;
    de.hdodenhof.circleimageview.CircleImageView iv_profile_up;
    ImageView back_arrow;
    HeaderCustomTV toolbar_title;
    Calendar myCalendar;
    NetworkConnection ntobj = new NetworkConnection(EditProfileActivity.this);
    Realm realm;
    public ArrayList<UserInformation> userProfile = new ArrayList<>();
    EditProfileFeaturesRVAdapter adapter;
    RecyclerView.LayoutManager rv_FeaturesRVAdaptermanager;
    RecyclerView rv_services;
    LinearLayoutManager objHorizontalLayout;
    View objChildView;
    int rv_featuresItemPosition;
    public ArrayList<EditProfileServices> arrayListEditProfileServices = new ArrayList<>();
    public static ArrayList<EditProfileServices> arrayListEditProfileServicesAll = new ArrayList<>();
    ExpandableHeightGridView gridview;
    public static ArrayList<String> mArray = new ArrayList<>();
    private static final int CAMERA_REQUEST = 1888;
    Bitmap companyavatar_FRONT;
    String docimageencode_FRONT = "", avatar_FRONT = "";
    String from;
    private static final int RESULT_LOAD_IMG = 200;
    Uri imageUri, imageUriBack;
    File file, fileBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profiles);


        if (EditProfileActivity.this instanceof BaseActivity) {
            generic = (Generic) EditProfileActivity.this;
        }
        generic.hideStatusBarForAuth();
        objEditProfileActivity = this;
        init();
        clickListener();
        callApiFirstTime();
        objectBAJava.hideKeyboard();
    }

    public void init() {
        gridview = (ExpandableHeightGridView) findViewById(R.id.gd_services);
        gridview.setExpanded(true);
        rv_services = (RecyclerView) findViewById(R.id.rv_services);
        cb_check_one = (CheckBox) findViewById(R.id.cb_check_one);
        cb_check_one = (CheckBox) findViewById(R.id.cb_check_one);
        cb_check_two = (CheckBox) findViewById(R.id.cb_check_two);
        cb_check_three = (CheckBox) findViewById(R.id.cb_check_three);
        cb_check_four = (CheckBox) findViewById(R.id.cb_check_four);
        tv_one = (TextView) findViewById(R.id.tv_one);
        tv_two = (TextView) findViewById(R.id.tv_two);
        tv_features_edit = (TextView) findViewById(R.id.tv_features_edit);
        tv_three_three = (TextView) findViewById(R.id.tv_three_three);
        tv_four = (TextView) findViewById(R.id.tv_four);
        tv_fname_title = (TextView) findViewById(R.id.tv_fname_title);
        tv_name = (TextView) findViewById(R.id.tv_name);
        tv_sname_title = (TextView) findViewById(R.id.tv_sname_title);
        tv_fmname_title = (TextView) findViewById(R.id.tv_fmname_title);
        tv_dob_title = (TextView) findViewById(R.id.tv_dob_title);
        tv_ph_title = (TextView) findViewById(R.id.tv_ph_title);
        tv_bt_title = (TextView) findViewById(R.id.tv_bt_title);
        tv_features_title = (TextView) findViewById(R.id.tv_features_title);
        tv_submit = (TextView) findViewById(R.id.tv_submit);
        tv_email_title = findViewById(R.id.tv_email_title);
        et_sname = (EditText) findViewById(R.id.et_sname);
        et_email=(EditText)findViewById(R.id.et_email);
        et_fname = (EditText) findViewById(R.id.et_fname);
//        tv_gender = (TextView) findViewById(R.id.tv_gender);
        tv_dob = (TextView) findViewById(R.id.tv_dob);
        et_ph = (EditText) findViewById(R.id.et_ph);
        tv_blood = (TextView) findViewById(R.id.tv_blood);
        toolbar_title = (HeaderCustomTV) findViewById(R.id.toolbar_title);
        back_arrow = (ImageView) findViewById(R.id.back_arrow);
        et_name = (EditText) findViewById(R.id.et_name);
        iv_profile_up = (de.hdodenhof.circleimageview.CircleImageView) findViewById(R.id.iv_profile_up);
        tv_submit = (TextView) findViewById(R.id.tv_submit);
        rl_submit = (RelativeLayout) findViewById(R.id.rl_submit);
        header_left_rl = (RelativeLayout) findViewById(R.id.header_left_rl);
        rl_body = (RelativeLayout) findViewById(R.id.rl_body);
        et_name.setTypeface(objectBAJava.roboto_regular);
        tv_submit.setTypeface(objectBAJava.roboto_regular);
        tv_noresult = (NoDataFoundCustomTV) findViewById(R.id.tv_noresult);
        r1_two_gender_tv = (RelativeLayout) findViewById(R.id.r1_two_gender_tv);
        r1_two_blood_tv = (RelativeLayout) findViewById(R.id.r1_two_blood_tv);
        toolbar_title.setText("تعديل الحساب الشخصي");
        back_arrow.setVisibility(View.VISIBLE);
        myCalendar = Calendar.getInstance();
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        progressBar.setVisibility(View.GONE);
        rl_slct_one = (RelativeLayout) findViewById(R.id.rl_slct_one);
        rl_slct_two = (RelativeLayout) findViewById(R.id.rl_slct_two);
        rl_slct_four = (RelativeLayout) findViewById(R.id.rl_slct_four);
        rl_slct_three = (RelativeLayout) findViewById(R.id.rl_slct_three);
        et_sname.setTypeface(objectBAJava.Tahoma_Regular_font);
        et_name.setTypeface(objectBAJava.Tahoma_Regular_font);

        et_email.setTypeface(objectBAJava.Tahoma_Regular_font);
//        tv_gender.setTypeface(objectBAJava.Tahoma_Regular_font);
        et_fname.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_dob.setTypeface(objectBAJava.Tahoma_Regular_font);
        et_ph.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_email_title.setTypeface(objectBAJava.Tahoma_Regular_font);
        et_ph.setFocusable(false);
        tv_blood.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_submit.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_fname_title.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_name.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_fmname_title.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_sname_title.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_dob_title.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_ph_title.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_features_edit.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_bt_title.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_features_title.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_one.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_two.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_three_three.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_fname_title.setTypeface(objectBAJava.Tahoma_Regular_font);

        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT) {
            progressBar.getIndeterminateDrawable().setColorFilter(getResources()
                    .getColor(R.color.progress_bar_color_white), PorterDuff.Mode.SRC_IN);
        }
        Realm.init(this);    //initialize to access database for this activity
        realm = Realm.getDefaultInstance();
        tv_dob.setClickable(false);
    }

    public void clickListener() {
//        tv_dob.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                objectBAJava.hideKeyboard();
//                DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
//
//                    @Override
//                    public void onDateSet(DatePicker view, int year, int monthOfYear,
//                                          int dayOfMonth) {
//                        // TODO Auto-generated method stub
//                        myCalendar.set(Calendar.YEAR, year);
//                        myCalendar.set(Calendar.MONTH, monthOfYear);
//                        myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
//
//                        Calendar cal = Calendar.getInstance();
//                        cal.set(year, monthOfYear, dayOfMonth);
//                        Date current = cal.getTime();
//                        int diff1 = new Date().compareTo(current);
//
//
//                        if (diff1 <= 0) {
//                            generic.showSnackbar(rl_body, "لا يمكنك اختيار التاريخ الحالي ، يجب أن يكون أقدم", Snackbar.LENGTH_LONG, "close", false);
//                            return;
//                        } else {
//                            String myFormat = "yyyy-MM-dd"; //In which you need put here
//                            SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
//                            tv_dob.setText(sdf.format(myCalendar.getTime()));
//                        }
//                    }
//
//                };
//                new DatePickerDialog(EditProfileActivity.this, date, myCalendar.get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
//                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
//            }
//        });

//        tv_gender.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                objectBAJava.hideKeyboard();
//                selectgender();
//            }
//        });

        tv_blood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                objectBAJava.hideKeyboard();
                selectBloodGroup();
            }
        });


        rl_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                velidation();
            }
        });

        header_left_rl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Intent mainIntent = new Intent(SigninActivity.this, EmailVerificationActivity.class);
//                startActivity(mainIntent);
//                overridePendingTransition(R.anim.start_slide_in_left, R.anim.start_slide_out_left);
//                objectBAJava.hideStatusBar();

                objectBAJava.hideStatusBar();
                finish();
                generic.animEnd();
            }
        });

        iv_profile_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                objectBAJava.hideKeyboard();
                android.app.AlertDialog alert = new android.app.AlertDialog.Builder(EditProfileActivity.this)
                        .create();
                alert.setMessage("أختر صورة للملف الشخصي");
                alert.setButton(DialogInterface.BUTTON_POSITIVE, "التقاط صورة", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();

                        if (AskForPermissions()) {

//                            Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
//                            startActivityForResult(cameraIntent, CAMERA_REQUEST);

                            takePic();
                        }

                    }
                });
                alert.setButton(DialogInterface.BUTTON_NEGATIVE, "معرض الصور", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();

                        if (AskForPermissions()) {
                            from = "Gallery";
                            Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
                            photoPickerIntent.setType("image/*");
                            startActivityForResult(photoPickerIntent, RESULT_LOAD_IMG);
                        }

                    }
                });
                alert.setButton(DialogInterface.BUTTON_NEUTRAL, "لا", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();


                    }
                });
                alert.show();

            }

        });


        tv_features_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                objectBAJava.hideStatusBar();
                ISFROMFEDITPROFILE = true;
                Intent intent = new Intent(EditProfileActivity.this, FeaturesActivity.class);
//                intent.putExtra("fname", st_fname);
//                intent.putExtra("sname", st_sname);
//                intent.putExtra("familyname", st_familyname);
//                intent.putExtra("dob", st_dob);
//                intent.putExtra("ph", st_ph);
//                intent.putExtra("gender", st_gender);
//                intent.putExtra("Blood", st_blood);
//                intent.putExtra("image", st_imageurl);
                startActivity(intent);
                generic.animStart();

            }
        });
    }

    public void selectgender() {

        final CharSequence[] gender = {"الذكر", "إناثا"};
        final android.app.AlertDialog.Builder alert = new android.app.AlertDialog.Builder(EditProfileActivity.this);
        alert.setTitle("الجنس");
        final String[] gen = new String[2];
        alert.setSingleChoiceItems(gender, -1, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (gender[which] == "الذكر") {
                    gen[0] = "1";
                    tv_gender.setText("الذكر");
                    dialog.dismiss();
                } else if (gender[which] == "إناثا") {
                    gen[0] = "2";
                    tv_gender.setText("إناثا");
                    dialog.dismiss();
                } else if (gender[which] == "Other") {
                    gen[0] = "2";
                    tv_gender.setText("other");
                    dialog.dismiss();
                }
            }
        });
        alert.show();
    }

    public void selectBloodGroup() {

        final CharSequence[] gender = {"A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-", "لا أعلم"};
        final android.app.AlertDialog.Builder alert = new android.app.AlertDialog.Builder(EditProfileActivity.this);
        alert.setTitle("اختر فصيلة الدم");
        final String[] gen = new String[8];
        alert.setSingleChoiceItems(gender, -1, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (gender[which] == "A+") {
                    gen[0] = "1";
                    tv_blood.setText("A+");
                    dialog.dismiss();
                } else if (gender[which] == "A-") {
                    gen[0] = "2";
                    tv_blood.setText("A-");
                    dialog.dismiss();
                } else if (gender[which] == "B+") {
                    gen[0] = "2";
                    tv_blood.setText("B+");
                    dialog.dismiss();
                } else if (gender[which] == "B-") {
                    gen[0] = "2";
                    tv_blood.setText("B-");
                    dialog.dismiss();
                } else if (gender[which] == "AB+") {
                    gen[0] = "2";
                    tv_blood.setText("AB+");
                    dialog.dismiss();
                } else if (gender[which] == "AB-") {
                    gen[0] = "2";
                    tv_blood.setText("AB-");
                    dialog.dismiss();
                } else if (gender[which] == "O+") {
                    gen[0] = "2";
                    tv_blood.setText("O+");
                    dialog.dismiss();
                } else if (gender[which] == "O-") {
                    gen[0] = "2";
                    tv_blood.setText("O-");
                    dialog.dismiss();
                }
                else if(gender[which] == "لا أعلم"){
                    gen[0] = "2";
                    tv_blood.setText("  لا أعلم");
                    dialog.dismiss();

                }
            }
        });
        alert.show();
    }

    public void apigetProfile() {

        generic.showProgressBar(progressBar);
        Map<String, String> params = generic.setBasicParams();
        params.put("auth_token", generic.getAuthTockenFromDb());
        OkHttpClient client = generic.setHeaderForReqs().build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(AppWebServices.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();
        ApiService service = retrofit.create(ApiService.class);
        Call<EditProfileResult> call = service.getprofile(params);
        call.enqueue(new Callback<EditProfileResult>() {
            @Override
            public void onResponse(Call<EditProfileResult> call, retrofit2.Response<EditProfileResult> response) {

                generic.hideProgressBar(progressBar);

                if (response.code() == 200) {
                    Boolean status = response.body().getstatus();

                    String message = response.body().getMessage();

                    if (status) {

                        if (response.body().getdata().getEditProfileResultdataProfile().getservicesdataServices().size() > 0) {

                            for (int i = 0; i < response.body().getdata().getEditProfileResultdataProfile().getservicesdataServices().size(); i++) {
                                EditProfileServices editProfileServices = new EditProfileServices();
                                editProfileServices = response.body().getdata().getEditProfileResultdataProfile().getservicesdataServices().get(i);
                                editProfileServices.setstatus(true);
                                arrayListEditProfileServices.add(editProfileServices);
                            }
                        }
                        if (arrayListEditProfileServices.size() > 0) {
//                            objCinemaRecyclerviewintial(arrayListEditProfileServices);
                            gridview.setAdapter(new EditProfileFeaturesGridAdapter(arrayListEditProfileServices, EditProfileActivity.this));
                        }
                        tv_blood.setText(response.body().getdata().getEditProfileResultdataProfile().getblood_group());
                        tv_dob.setText(response.body().getdata().getEditProfileResultdataProfile().getdob());
//                        tv_gender.setText(response.body().getdata().getEditProfileResultdataProfile().getgender());
                        et_name.setText(response.body().getdata().getEditProfileResultdataProfile().getfull_name());
                        et_sname.setText(response.body().getdata().getEditProfileResultdataProfile().getlast_name());
                        et_fname.setText(response.body().getdata().getEditProfileResultdataProfile().getfamily_name());
                        et_ph.setText(response.body().getdata().getEditProfileResultdataProfile().getphoneNumber());
                        et_email.setText(response.body().getdata().getEditProfileResultdataProfile().getEmail());
                        st_fname = response.body().getdata().getEditProfileResultdataProfile().getfull_name();
                        st_sname = response.body().getdata().getEditProfileResultdataProfile().getlast_name();
                        st_familyname = response.body().getdata().getEditProfileResultdataProfile().getfamily_name();
                        st_dob = response.body().getdata().getEditProfileResultdataProfile().getdob();
                        st_ph = response.body().getdata().getEditProfileResultdataProfile().getphoneNumber();
                        st_gender = response.body().getdata().getEditProfileResultdataProfile().getgender();
                        st_blood = response.body().getdata().getEditProfileResultdataProfile().getblood_group();

//                        Glide.with(EditProfileActivity.this)
//                                .load(response.body().getdata().getEditProfileResultdataProfile().getimage_url())
//                                .override(600, 200) // resizes the image to these dimensions (in pixel). resize does not respect aspect ratio
//                                .signature(new StringSignature(String.valueOf(System.currentTimeMillis())))
//                                .diskCacheStrategy(DiskCacheStrategy.NONE)
//                                .skipMemoryCache(true)
//                                .error(R.drawable.profile_icon)
//                                .transform(new CircleTransform(EditProfileActivity.this))
//                                .into(iv_profile_up);
                        Picasso.get()
                                .load(response.body().getdata().getEditProfileResultdataProfile().getimage_url())
//                                .resize(100, 100)
//                                .transform(new CropCircleTransformation())
                                .placeholder(R.drawable.profile_icon)
                                .error(R.drawable.profile_icon)
                                .memoryPolicy(MemoryPolicy.NO_CACHE, MemoryPolicy.NO_STORE)
                                .into(iv_profile_up);


//                                .placeholder(R.drawable.profile_icon)

                        st_imageurl = response.body().getdata().getEditProfileResultdataProfile().getimage_url();

                        if (response.body().getdata().getservicesdataServices().size() > 0) {

                            for (int i = 0; i < response.body().getdata().getservicesdataServices().size(); i++) {
                                EditProfileServices editProfileServices = new EditProfileServices();
                                editProfileServices = response.body().getdata().getservicesdataServices().get(i);
                                editProfileServices.setstatus(false);
                                arrayListEditProfileServicesAll.add(editProfileServices);
                            }
                        }

                        for (int i = 0; i < arrayListEditProfileServicesAll.size(); i++) {

                            for (int j = 0; j < arrayListEditProfileServices.size(); j++) {
                                if (arrayListEditProfileServicesAll.get(i).getid().equals(arrayListEditProfileServices.get(j).getid())) {
                                    arrayListEditProfileServicesAll.get(i).setstatus(true);
                                }
                            }
                        }

                    } else {

                        generic.showSnackbar(rl_body, message, Snackbar.LENGTH_LONG, "close", false);

                    }
                } else if (response.code() == 401) {
                    try {
                        RealmResults<UserInformation> results = getDataintoUserinfo();
                        if (results.size() > 0) {
                            deleteUserinfo();
                            PreferenceManager.getDefaultSharedPreferences(EditProfileActivity.this).edit().putBoolean("firstTimeLogin", false).apply();
                        }
                        String userMessage = PreferenceManager.getDefaultSharedPreferences(EditProfileActivity.this).getString("oops", "هناك خطأ ما");
                        try {

//                            String dataArrayMessage = "";
//                            try {
//                                ArrayList<String> message = response.body().getmessage();
//                                for (int i = 0; i < message.size(); i++) {
//                                    dataArrayMessage = dataArrayMessage + message.get(i) + "\n";
//                                }
//
//                            } catch (Exception e) {
//                            }
                            JSONObject jObjError = new JSONObject(response.errorBody().string());
                            String errorMessage = jObjError.getString("message");
                            errorMessage = response.body().getMessage();
                            if (errorMessage != null && !errorMessage.equals("")) {
                                userMessage = errorMessage;
                            }
                        } catch (Exception e) {
                        }
                        String OK = PreferenceManager.getDefaultSharedPreferences(EditProfileActivity.this).getString("ok", "موافق");
                        AlertDialog alert = new AlertDialog.Builder(EditProfileActivity.this)
                                .create();
                        alert.setMessage(userMessage);
                        alert.setButton(DialogInterface.BUTTON_POSITIVE, OK, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {

                                dialog.dismiss();

                            }
                        });
                        alert.show();

                    } catch (Exception e) {

                        String userMessage = PreferenceManager.getDefaultSharedPreferences(EditProfileActivity.this).getString("oops", "هناك خطأ ما");
                        showSnackbar(rl_body, userMessage, Snackbar.LENGTH_LONG, "close", false);
                    }

                } else {

                    try {

                        String userMessage = PreferenceManager.getDefaultSharedPreferences(EditProfileActivity.this).getString("oops", "هناك خطأ ما");
                        JSONObject jObjError = new JSONObject(response.errorBody().string());
                        try {
                            userMessage = jObjError.getString("message");
                        } catch (Exception e) {
                        }

                        String dataArrayMessage = "";
                        try {
                            JSONArray jsonArray = jObjError.getJSONArray("LoginResultdata");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                dataArrayMessage = dataArrayMessage + jsonArray.getString(i) + "\n";
                            }

                        } catch (Exception e) {
                        }

                        String maintenanceBtnText = "Try Again";
                        try {
                            maintenanceBtnText = jObjError.optString("btn_text");
                        } catch (Exception e) {
                        }
                        generic.genericCodes(rl_body, response.code(), userMessage, dataArrayMessage, maintenanceBtnText);
                    } catch (Exception e) {

                        generic.showSnackbar(progressBar, "هناك خطأ ما", Snackbar.LENGTH_LONG, "close", false);

                    }

                }
            }

            @Override
            public void onFailure(Call<EditProfileResult> call, Throwable t) {

                generic.hideProgressBar(progressBar);
                generic.showSnackbar(progressBar, "هناك خطأ ما", Snackbar.LENGTH_LONG, "close", false);

            }
        });
    }

    public void velidation() {
        st_fname = et_name.getText().toString();
        st_sname = et_sname.getText().toString();
        st_familyname = et_fname.getText().toString();
        st_dob = tv_dob.getText().toString();
        st_ph = et_ph.getText().toString();
        st_email = et_email.getText().toString();
//        st_gender = tv_gender.getText().toString();
        st_blood = tv_blood.getText().toString();

        if (st_fname.trim().equals("")) {
            et_name.requestFocus();
            et_name.setError("الإسم الكامل مطلوب");
        }
//        else if (st_sname.trim().equals("")) {
//            et_sname.setError("إسم الأب مطلوب");
//            et_sname.requestFocus();
//        } else if (st_familyname.trim().equals("")) {
//            et_fname.setError("القبيلة/العائلة مطلوب");
//            et_fname.requestFocus();
//        }
//        else if (st_gender.trim().equals("Gender")) {
//            generic.showSnackbar(tv_gender, "Gender is required", Snackbar.LENGTH_LONG, "close", false);
//        }
        else if (st_dob.trim().equals("")) {
            generic.showSnackbar(tv_dob, "تاريخ الميلاد مطلوب", Snackbar.LENGTH_LONG, "close", false);
        } else if (st_ph.trim().equals("")) {
            et_ph.setError("رقم الهاتف مطلوب");
            et_ph.requestFocus();
        } else if (st_blood.trim().equals("")) {
            generic.showSnackbar(tv_blood, "نوع فصيلة الدم مطلوبة", Snackbar.LENGTH_LONG, "close", false);
        } else {
            if (ntobj.isConnectingToInternet()) {
                objectBAJava.hideKeyboard();
                apiUpdate();
            } else {
                String Message = PreferenceManager.getDefaultSharedPreferences(EditProfileActivity.this).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
                generic.showSnackbar(rl_body, Message, Snackbar.LENGTH_LONG, "close", false);
            }
        }
    }

    public void apiUpdate() {

        mArray = new ArrayList<>();
        for (int i = 0; i < arrayListEditProfileServices.size(); i++) {

            if (arrayListEditProfileServices.get(i).getstatus()) {
                mArray.add(arrayListEditProfileServices.get(i).getid());
            }
        }
        generic.showProgressBar(progressBar);
        OkHttpClient client = generic.setHeaderForReqs().build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(AppWebServices.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();
        ApiService service = retrofit.create(ApiService.class);
        Call<DefaultResult> call;
//        Call<LoginResult> call = service.login(params);

        if (docimageencode_FRONT.equals("")) {
//            docimageencode_FRONT = st_imageurl;
            call = service.saveprofileFeatures(generic.getAuthTockenFromDb(), st_fname,st_email, st_ph, st_blood, st_dob,
                    StaticStrings.DEVICE_TYPE.toString(), Build.MODEL, Build.VERSION.RELEASE);

        } else {
            docimageencode_FRONT = "data:image/jpeg;base64," + docimageencode_FRONT;
            call = service.saveprofile(generic.getAuthTockenFromDb(), st_fname,st_email, st_ph, st_blood,
                    st_dob, docimageencode_FRONT, "jpg",
                    StaticStrings.DEVICE_TYPE.toString(), Build.MODEL, Build.VERSION.RELEASE);
        }
        call.enqueue(new Callback<DefaultResult>() {
            @Override
            public void onResponse(Call<DefaultResult> call, retrofit2.Response<DefaultResult> response) {

                generic.hideProgressBar(progressBar);

                if (response.code() == 200) {
                    Boolean status = response.body().getstatus();

                    String message = response.body().getMessage();

                    if (status) {
                        finish();
                        generic.animEnd();

                    } else {

                        generic.showSnackbar(rl_body, message, Snackbar.LENGTH_LONG, "close", false);

                    }
                } else if (response.code() == 401) {
                    try {
                        RealmResults<UserInformation> results = getDataintoUserinfo();
                        if (results.size() > 0) {
                            deleteUserinfo();
                            PreferenceManager.getDefaultSharedPreferences(EditProfileActivity.this).edit().putBoolean("firstTimeLogin", false).apply();
                        }
                        String userMessage = PreferenceManager.getDefaultSharedPreferences(EditProfileActivity.this).getString("oops", "هناك خطأ ما");
                        try {

//                            String dataArrayMessage = "";
//                            try {
//                                ArrayList<String> message = response.body().getmessage();
//                                for (int i = 0; i < message.size(); i++) {
//                                    dataArrayMessage = dataArrayMessage + message.get(i) + "\n";
//                                }
//
//                            } catch (Exception e) {
//                            }

                            JSONObject jObjError = new JSONObject(response.errorBody().string());
                            String errorMessage = jObjError.getString("message");
                            errorMessage = response.body().getMessage();
                            if (errorMessage != null && !errorMessage.equals("")) {
                                userMessage = errorMessage;
                            }
                        } catch (Exception e) {
                        }
                        String OK = PreferenceManager.getDefaultSharedPreferences(EditProfileActivity.this).getString("ok", "موافق");
                        AlertDialog alert = new AlertDialog.Builder(EditProfileActivity.this)
                                .create();
                        alert.setMessage(userMessage);
                        alert.setButton(DialogInterface.BUTTON_POSITIVE, OK, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {

                                dialog.dismiss();

                            }
                        });
                        alert.show();

                    } catch (Exception e) {

                        String userMessage = PreferenceManager.getDefaultSharedPreferences(EditProfileActivity.this).getString("oops", "هناك خطأ ما");
                        showSnackbar(rl_body, userMessage, Snackbar.LENGTH_LONG, "close", false);
                    }

                } else {

                    try {

                        String userMessage = PreferenceManager.getDefaultSharedPreferences(EditProfileActivity.this).getString("oops", "هناك خطأ ما");
                        JSONObject jObjError = new JSONObject(response.errorBody().string());
                        try {
                            userMessage = jObjError.getString("message");
                        } catch (Exception e) {
                        }

                        String dataArrayMessage = "";
                        try {
                            JSONArray jsonArray = jObjError.getJSONArray("LoginResultdata");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                dataArrayMessage = dataArrayMessage + jsonArray.getString(i) + "\n";
                            }

                        } catch (Exception e) {
                        }

                        String maintenanceBtnText = "Try Again";
                        try {
                            maintenanceBtnText = jObjError.optString("btn_text");
                        } catch (Exception e) {
                        }
                        generic.genericCodes(rl_body, response.code(), userMessage, dataArrayMessage, maintenanceBtnText);
                    } catch (Exception e) {

                        generic.showSnackbar(progressBar, "هناك خطأ ما", Snackbar.LENGTH_LONG, "close", false);

                    }
                }
            }

            @Override
            public void onFailure(Call<DefaultResult> call, Throwable t) {

                generic.hideProgressBar(progressBar);
                generic.showSnackbar(progressBar, "هناك خطأ ما", Snackbar.LENGTH_LONG, "close", false);

            }
        });
    }

    public Bitmap uriToBitmap(Context c, Uri uri) {
        if (c == null && uri == null) {
            return null;
        }
        try {
            return MediaStore.Images.Media.getBitmap(c.getContentResolver(), Uri.fromFile(file));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void onResume() {
        super.onResume();

        if (StaticStrings.ISFROMFEATURES) {

            callApiFirstTime();
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 100: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.

                } else {
                    AskForPermissions();
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.);
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Bitmap photo = null;
        if (requestCode == CAMERA_REQUEST && resultCode == Activity.RESULT_OK) {

//            photo = (Bitmap) data.getExtras().get("data");
//            Uri tempUri = getImageUri(EditProfileActivity.this, photo);
//            setImageInProfileforGallery(photo, tempUri);
//            File finalFile = new File(getRealPathFromURI(tempUri));
//            convertiInToBase64(finalFile);

            try {
                String[] filePathColumn = {MediaStore.Images.Media.DATA};
                Cursor cursor = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, filePathColumn, null, null, null);
                if (cursor == null)
                    return;
                // find the file in the media area
                cursor.moveToLast();
                int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                String filePath = "file:///" + cursor.getString(columnIndex);
                cursor.close();
                photo = uriToBitmap(this, Uri.parse(filePath));
                // CALL THIS METHOD TO GET THE URI FROM THE BITMAP
                Uri tempUri = getImageUri(EditProfileActivity.this, photo);
                setImageInProfileforGallery(photo, tempUri);
                // CALL THIS METHOD TO GET THE ACTUAL PATH
                File finalFile = new File(getRealPathFromURI(tempUri));
                convertiInToBase64New(finalFile, tempUri);

            } catch (Exception e) {
                e.printStackTrace();
            }


        } else if (requestCode == RESULT_LOAD_IMG && resultCode == Activity.RESULT_OK) {
            if (resultCode == RESULT_OK) {
                try {
                    final Uri imageUri = data.getData();
                    final InputStream imageStream = getContentResolver().openInputStream(imageUri);
                    photo = BitmapFactory.decodeStream(imageStream);
                    Uri tempUri = getImageUri(EditProfileActivity.this, photo);
                    setImageInProfileforGallery(photo, tempUri);
                    // CALL THIS METHOD TO GET THE ACTUAL PATH
                    File finalFile = new File(getRealPathFromURI(tempUri));
                    convertiInToBase64(finalFile);

                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                    generic.showSnackbar(rl_body, "هناك خطأ ما", Snackbar.LENGTH_LONG, "close", false);
                }
            } else {
                generic.showSnackbar(rl_body, "لم تقم باختيار الصورة", Snackbar.LENGTH_LONG, "close", false);
            }
        }
    }

    public void setImageInProfileforGallery(Bitmap photo, Uri tempUri) {
//        iv_profile_up.setImageBitmap(photo);
        Picasso.get()
                .load(tempUri)
//                .resize(100, 100)
//                .transform(new CropCircleTransformation())
                .placeholder(R.drawable.profile_icon)
                .error(R.drawable.profile_icon)
                .memoryPolicy(MemoryPolicy.NO_CACHE, MemoryPolicy.NO_STORE)
                .into(iv_profile_up);

        companyavatar_FRONT = photo;
        avatar_FRONT = String.valueOf(photo);
    }

    public void setImageInProfileforCamera(Bitmap photo, ByteArrayOutputStream stream) {
//        iv_profile_up.setImageBitmap(photo);
        Picasso.get()
                .load(String.valueOf(stream.toByteArray()))
//                .resize(100, 100)
//                .transform(new CropCircleTransformation())
                .placeholder(R.drawable.profile_icon)
                .error(R.drawable.profile_icon)
                .memoryPolicy(MemoryPolicy.NO_CACHE, MemoryPolicy.NO_STORE)
                .into(iv_profile_up);

        companyavatar_FRONT = photo;
        avatar_FRONT = String.valueOf(photo);
    }

    public void convertiInToBase64(File path) {
        Bitmap bm = BitmapFactory.decodeFile(String.valueOf(path));
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.JPEG, 100, baos); //bm is the bitmap object
        byte[] byteArrayImage = baos.toByteArray();
        String encodedImage = Base64.encodeToString(byteArrayImage, Base64.DEFAULT);
        System.out.print("its image path2 " + encodedImage);
        docimageencode_FRONT = encodedImage;
    }

    public void convertiInToBase64New(File path, Uri tempUri) {
//        Bitmap bm = BitmapFactory.decodeFile(String.valueOf(path));

        Bitmap bms = null;
        try {
            bms = BitmapFactory.decodeStream(getContentResolver().openInputStream(tempUri));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        Bitmap bm = Bitmap.createScaledBitmap(bms, 1080, 1920, false);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.JPEG, 100, baos); //bm is the bitmap object
        byte[] byteArrayImage = baos.toByteArray();
        String encodedImage = Base64.encodeToString(byteArrayImage, Base64.DEFAULT);
        System.out.print("its image path2 " + encodedImage);
        docimageencode_FRONT = encodedImage;


    }

    public Uri getImageUri(Context inContext, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(inContext.getContentResolver(), inImage, "Title", null);
        return Uri.parse(path);
    }

    public String getRealPathFromURI(Uri uri) {
//        Cursor cursor = getContentResolver().query(uri, null, null, null, null);
//        cursor.moveToFirst();
//        int idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
//        return cursor.getString(idx);

        File finalFile = new File(realPathUtil.getRealPath(EditProfileActivity.this, uri));
        return finalFile.toString();
    }

    boolean AskForPermissions() {
        // Here, thisActivity is the current activity
        if (ContextCompat.checkSelfPermission(EditProfileActivity.this, android.Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(EditProfileActivity.this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(EditProfileActivity.this, android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(EditProfileActivity.this, android.Manifest.permission.READ_EXTERNAL_STORAGE) == true
                    || ActivityCompat.shouldShowRequestPermissionRationale(EditProfileActivity.this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == true
                    || ActivityCompat.shouldShowRequestPermissionRationale(EditProfileActivity.this, android.Manifest.permission.CAMERA) == true) {
                DialogBox();

            } else {

                // No explanation needed, we can request the permission.

                ActivityCompat.requestPermissions(EditProfileActivity.this,
                        new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE, android.Manifest.permission.WRITE_EXTERNAL_STORAGE, android.Manifest.permission.CAMERA},
                        100);
            }
            return false;
        }
        return true;
    }

    public void DialogBox() {

        final Dialog dialog = new Dialog(EditProfileActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.contest_pop);

        Button settings = (Button) dialog.findViewById(R.id.settings);
        Button cancle = (Button) dialog.findViewById(R.id.cancle);
        cancle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

                startInstalledAppDetailsActivity();

            }
        });
        dialog.show();
    }

    public void startInstalledAppDetailsActivity() {

        final Intent i = new Intent();
        i.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        i.addCategory(Intent.CATEGORY_DEFAULT);
        i.setData(Uri.parse("package:" + getPackageName()));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        i.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
        i.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
        startActivity(i);
    }

    public void callApiFirstTime() {
        if (ntobj.isConnectingToInternet()) {
            generic.showProgressBar(progressBar);
            objectBAJava.hideKeyboard();
            arrayListEditProfileServices.clear();
            arrayListEditProfileServicesAll.clear();
            tv_noresult.setVisibility(View.GONE);
            apigetProfile();
        } else {
            generic.hideProgressBar(progressBar);
            String Message = PreferenceManager.getDefaultSharedPreferences(EditProfileActivity.this).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
            generic.showSnackbar(rl_body, Message, Snackbar.LENGTH_LONG, "close", false);
        }
    }


    private void takePic() {

        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        file = new File(Environment.getExternalStorageDirectory(), "/DCIM" + "/photo_" + timeStamp + ".png");
        imageUri = FileProvider.getUriForFile(
                EditProfileActivity.this,
                "com.mersal.mersal.provider", file);
//        imageUri = Uri.fromFile(file);

        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
        startActivityForResult(intent, CAMERA_REQUEST);
    }


}
