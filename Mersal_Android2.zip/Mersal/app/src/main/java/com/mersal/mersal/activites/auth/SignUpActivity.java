package com.mersal.mersal.activites.auth;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.facebook.accountkit.AccessToken;
import com.facebook.accountkit.AccountKit;
import com.facebook.accountkit.AccountKitLoginResult;
import com.facebook.accountkit.ui.AccountKitActivity;
import com.facebook.accountkit.ui.AccountKitConfiguration;
import com.facebook.accountkit.ui.LoginType;
import com.mersal.mersal.R;
import com.mersal.mersal.activites.base.BaseActivity;
import com.mersal.mersal.activites.dashboard.DashboardActivity;
import com.mersal.mersal.activites.editprofile.EditProfileActivity;
import com.mersal.mersal.customviews.HeaderCustomTV;
import com.mersal.mersal.customviews.NoDataFoundCustomTV;
import com.mersal.mersal.generic.Interfaces.Generic;
import com.mersal.mersal.internetconnections.NetworkConnection;
import com.mersal.mersal.realm.UserInformation;
import com.mersal.mersal.retrofit.baseapi.ApiService;
import com.mersal.mersal.retrofit.baseapi.AppWebServices;
import com.mersal.mersal.retrofit.defualt.DefaultResult;
import com.mersal.mersal.retrofit.otp.OtpResult;
import com.mersal.mersal.retrofit.signup.SignUpResult;
import com.mersal.mersal.retrofit.signup.SignUpdata;
import com.mersal.mersal.utilties.StaticStrings;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Map;

import io.realm.Realm;
import io.realm.RealmResults;
import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static com.mersal.mersal.activites.auth.OtpVerificationActivity.APP_REQUEST_CODE;
import static com.mersal.mersal.activites.auth.SignUpPreActivity.SignUpPreActivityObject;
import static com.mersal.mersal.activites.auth.SignupIdScanActivity.docimageencode_BACK_ForSignup;
import static com.mersal.mersal.activites.auth.SignupIdScanActivity.docimageencode_FRONT_ForSignup;
import static com.mersal.mersal.utilties.StaticStrings.ISFROMFEDITPROFILE;

public class SignUpActivity extends BaseActivity {

    TextView tv_uname, tv_email, tv_pwd, tv_submit, tv_lbl_rgr, tv_lbl_dnt, tv_phone;
    RelativeLayout rl_submit, rl_body, header_left_rl;
    String st_username = "", st_pwd = "", st_phone ="";
    EditText et_username, et_pwd, et_email, et_phone;
    ProgressBar progressBar;
    NoDataFoundCustomTV tv_noresult;
    public static SignUpActivity SignUpActivityObject;
    NetworkConnection ntobj = new NetworkConnection(SignUpActivity.this);
    Generic generic;
    ImageView back_arrow;
    HeaderCustomTV toolbar_title;
    String st_sname = "", st_familyname = "", st_email = "", st_code = "", st_fname = "", st_gender = "", st_dob = "", st_ph = "", st_blood = "";
    public ArrayList<UserInformation> userProfile = new ArrayList<>();
    Realm realm;
    String id_name, civil_number, expiry_date;
    ImageView imgShowPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);


        if (SignUpActivity.this instanceof BaseActivity) {
            generic = (Generic) SignUpActivity.this;
        }
        generic.hideStatusBarForAuth();
        SignUpActivityObject = this;

        init();
        clickListener();
        objectBAJava.hideKeyboard();

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            st_fname = extras.getString("fname");
            st_dob = extras.getString("iddob");
            st_gender = extras.getString("gender");
            st_blood = extras.getString("Blood");
            id_name = extras.getString("idname");
            civil_number = extras.getString("id_number");
            expiry_date = extras.getString("expiry_date");
//            docimageencode_FRONT = extras.getString("id_front");
//            docimageencode_BACK = extras.getString("id_back");
            //            st_ph = extras.getString("ph");
            //            st_sname = extras.getString("sname");
//            st_familyname = extras.getString("familyname");
        }
    }

    public void init() {
        header_left_rl = (RelativeLayout) findViewById(R.id.header_left_rl);
        et_username = (EditText) findViewById(R.id.et_username);
        et_email = (EditText) findViewById(R.id.et_email);
        et_pwd = (EditText) findViewById(R.id.et_pwd);
        et_phone = findViewById(R.id.et_phone);
        tv_uname = (TextView) findViewById(R.id.tv_uname);
        tv_email = (TextView) findViewById(R.id.tv_email);
        tv_pwd = (TextView) findViewById(R.id.tv_pwd);
        tv_submit = (TextView) findViewById(R.id.tv_submit);
        tv_phone = findViewById(R.id.tv_phone);
        tv_lbl_dnt = (TextView) findViewById(R.id.tv_lbl_dnt);
        tv_lbl_rgr = (TextView) findViewById(R.id.tv_lbl_rgr);
        rl_submit = (RelativeLayout) findViewById(R.id.rl_submit);
        rl_body = (RelativeLayout) findViewById(R.id.rl_body);
        et_username.setTypeface(objectBAJava.Tahoma_Regular_font);
        et_phone.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_phone.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_email.setTypeface(objectBAJava.Tahoma_Regular_font);
        et_pwd.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_uname.setTypeface(objectBAJava.Tahoma_Regular_font);
        et_email.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_pwd.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_submit.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_lbl_rgr.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_lbl_dnt.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_noresult = (NoDataFoundCustomTV) findViewById(R.id.tv_noresult);
        imgShowPassword = findViewById(R.id.show_pass_btn);
        toolbar_title = (HeaderCustomTV) findViewById(R.id.toolbar_title);
        back_arrow = (ImageView) findViewById(R.id.back_arrow);
        toolbar_title.setText("إنشاء حساب");
        back_arrow.setVisibility(View.VISIBLE);

        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        progressBar.setVisibility(View.GONE);

        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT) {
            progressBar.getIndeterminateDrawable().setColorFilter(getResources()
                    .getColor(R.color.progress_bar_color_white), PorterDuff.Mode.SRC_IN);
        }
        Realm.init(this);    //initialize to access database for this activity
        realm = Realm.getDefaultInstance();
    }

    public void clickListener() {
        rl_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                velidation();
                objectBAJava.hideKeyboard();

            }
        });

        back_arrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                objectBAJava.hideStatusBar();
                finish();
                generic.animEnd();


            }
        });
        imgShowPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if( et_pwd.getTransformationMethod().equals(PasswordTransformationMethod.getInstance())){
                    et_pwd.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    imgShowPassword.setImageResource(R.drawable.password_show);
                }
                else {
                    et_pwd.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    imgShowPassword.setImageResource(R.drawable.password_hide);

                }
            }
        });
//        tv_lbl_rgr.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent mainIntent = new Intent(SignUpActivity.this, SignUpActivity.class);
//                startActivity(mainIntent);
//                overridePendingTransition(R.anim.start_slide_in_left, R.anim.start_slide_out_left);
//                objectBAJava.hideStatusBar();
//            }
//        });
    }

    public boolean containAlphanumeric(final String str) {
        byte counter = 0;
        boolean checkdigit = false, checkchar = false;
        for (int i = 0; i < str.length() && counter < 2; i++) {
            // If we find a non-digit character we return false.
            if (!checkdigit && Character.isDigit(str.charAt(i))) {
                checkdigit = true;
                counter++;
            }
            String a = String.valueOf(str.charAt(i));
            if (!checkchar && a.matches("[a-zA-Z]*")) {
                checkchar = true;
                counter++;
            }
        }
        if (checkdigit && checkchar) {
            return true;
        }
        return false;
    }

    public void velidation() {
        st_username = et_username.getText().toString();
        st_pwd = et_pwd.getText().toString();
        st_email = et_email.getText().toString();
        st_phone = et_phone.getText().toString();

//        if (st_email.trim().equals("")) {
//            et_email.requestFocus();
//            et_email.setError("ادخل بريد الكتروني صالح");
//        } else if (!st_email.contains("@") || !st_email.contains(".")) {
//            et_email.requestFocus();
//            et_email.setError("البريد الإلكتروني صالح مطلوب");
//        } else if (st_username.trim().equals("")) {
//            et_username.requestFocus();
//            et_username.setError("اسم المستخدم مطلوب");
//        } else
        if (st_pwd.trim().equals("")) {
            et_pwd.requestFocus();
            et_pwd.setError("كلمه المرور مطلوب");
        } else if (st_pwd.trim().length() < 6) {
            et_pwd.requestFocus();
            et_pwd.setError("كلمة المرور يجب ان تتكون من 6 رموز على الاقل");
        } else if(!containAlphanumeric(st_pwd.trim())){
            et_pwd.requestFocus();
            et_pwd.setError("كلمة المرور يجب أن تتكون من حروف و أرقام");
        }

        else if(st_phone.trim().equals("")){
            et_phone.requestFocus();
            et_phone.setError("رقم الهاتف مطلوب");
        }

        else {
            if (ntobj.isConnectingToInternet()) {
                objectBAJava.hideKeyboard();
                generic.showProgressBar(progressBar);
                apiCheckUserEmail();
//              phoneLogin(rl_body);

            } else {
                generic.hideProgressBar(progressBar);
                String Message = PreferenceManager.getDefaultSharedPreferences(SignUpActivity.this).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
                generic.showSnackbar(rl_body, Message, Snackbar.LENGTH_LONG, "close", false);
            }
        }
    }



    @Override
    protected void onActivityResult(
            final int requestCode,
            final int resultCode,
            final Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == APP_REQUEST_CODE) { // confirm that this response matches your request
            AccountKitLoginResult loginResult = data.getParcelableExtra(AccountKitLoginResult.RESULT_KEY);
            String toastMessage;
            if (loginResult.getError() != null) {
                toastMessage = loginResult.getError().getErrorType().getMessage();
//              showErrorActivity(loginResult.getError());

            } else if (loginResult.wasCancelled()) {

                toastMessage = "تم إلغاء تسجيل الدخول\n";
            } else {

                if (loginResult.getAccessToken() != null) {

                    toastMessage = "نجاح:" + loginResult.getAccessToken().getAccountId();
                    hideKeyboard();
//                    Intent intent = new Intent(SignUpActivity.this, FeaturesActivity.class);
//                    intent.putExtra("fname", st_fname);
//                    intent.putExtra("sname", st_sname);
//                    intent.putExtra("familyname", st_familyname);
//                    intent.putExtra("dob", st_dob);
//                    intent.putExtra("ph", st_ph);
//                    intent.putExtra("gender", st_gender);
//                    intent.putExtra("Blood", st_blood);
//                    intent.putExtra("username", st_username);
//                    intent.putExtra("password", st_pwd);
//                    intent.putExtra("email", st_email);
//                    intent.putExtra("code", "dummy");
//                    startActivity(intent);
//                    animStart();

                    if (ntobj.isConnectingToInternet()) {
                        objectBAJava.hideKeyboard();
                        apiSignUp();

                    } else {
                        String Message = PreferenceManager.getDefaultSharedPreferences(SignUpActivity.this).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
                        generic.showSnackbar(rl_body, Message, Snackbar.LENGTH_LONG, "close", false);
                    }


                } else {

                    toastMessage = String.format(
                            "نجاح...",
                            loginResult.getAuthorizationCode().substring(0, 10));
                    hideKeyboard();
//                    Intent intent = new Intent(SignUpActivity.this, FeaturesActivity.class);
//                    intent.putExtra("fname", st_fname);
//                    intent.putExtra("sname", st_sname);
//                    intent.putExtra("familyname", st_familyname);
//                    intent.putExtra("dob", st_dob);
//                    intent.putExtra("ph", st_ph);
//                    intent.putExtra("gender", st_gender);
//                    intent.putExtra("Blood", st_blood);
//                    intent.putExtra("username", st_username);
//                    intent.putExtra("password", st_pwd);
//                    intent.putExtra("email", st_email);
//                    intent.putExtra("code", "dummy");
//                    startActivity(intent);
//                    animStart();
                    if (ntobj.isConnectingToInternet()) {
                        objectBAJava.hideKeyboard();
                        apiSignUp();

                    } else {
                        String Message = PreferenceManager.getDefaultSharedPreferences(SignUpActivity.this).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
                        generic.showSnackbar(rl_body, Message, Snackbar.LENGTH_LONG, "close", false);
                    }
                }
                // If you have an authorization code, retrieve it from
                // loginResult.getAuthorizationCode()
                // and pass it to your server and exchange it for an access token.

                // Success! Start your next activity...
//                goToMyLoggedInActivity();
            }

            // Surface the result to your user in an appropriate way.
//            Toast.makeText(
//                    this,
//                    toastMessage,
//                    Toast.LENGTH_LONG)
//                    .show();

            // generic.showSnackbar(progressBar, toastMessage, Snackbar.LENGTH_LONG, "close", true);

        }

//        AccountKit.logOut();
    }

    public void getAceessacebook() {

        AccessToken accessToken = AccountKit.getCurrentAccessToken();

        if (accessToken != null) {
            //Handle Returning User
        } else {
            //Handle new or logged out user
        }
    }

    public void apiCheckUserEmail() {
        Map<String, String> params = generic.setBasicParams();
        params.put("email", st_email);
        params.put("username", st_username);
        OkHttpClient client = generic.setHeaderForReqs().build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(AppWebServices.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();

        ApiService service = retrofit.create(ApiService.class);
        Call<DefaultResult> call = service.validate_user(params);
        call.enqueue(new Callback<DefaultResult>() {

            @Override
            public void onResponse(Call<DefaultResult> call, retrofit2.Response<DefaultResult> response) {
                if (response.code() == 200) {

                    Boolean status = response.body().getstatus();
                    String Message = response.body().getMessage();

                    if (status) {
                        generic.hideProgressBar(progressBar);
                        hideKeyboard();
                        // phoneLogin(rl_body);

                        hideKeyboard();
                        apiCheckPhonenumber();


                        //                        intent.putExtra("sname", st_sname);
//                        intent.putExtra("familyname", st_familyname);
                        //                        intent.putExtra("ph", st_ph);

                    } else {
                        generic.hideProgressBar(progressBar);
                        Snackbar snackbar = Snackbar.make(rl_body, Message, Snackbar.LENGTH_LONG);
                        snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
                        snackbar.show();
                    }

                } else {
                    generic.hideProgressBar(progressBar);
                    try {

                        generic.hideProgressBar(progressBar);
                        String userMessage = PreferenceManager.getDefaultSharedPreferences(SignUpActivity.this).getString("oops", "هناك خطأ ما");
                        JSONObject jObjError = new JSONObject(response.errorBody().string());
                        try {
                            userMessage = jObjError.getString("message");
                        } catch (Exception e) {
                        }

                        String dataArrayMessage = "";
                        try {
                            JSONArray jsonArray = jObjError.getJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                dataArrayMessage = dataArrayMessage + jsonArray.getString(i) + "\n";
                            }

                        } catch (Exception e) {
                        }


                        String maintenanceBtnText = "Try Again";
                        try {
                            maintenanceBtnText = jObjError.optString("btn_text");
                        } catch (Exception e) {
                        }

                        generic.genericCodes(rl_body, response.code(), userMessage, dataArrayMessage, maintenanceBtnText);

                    } catch (Exception e) {

                        generic.hideProgressBar(progressBar);
                        Snackbar snackbar = Snackbar.make(rl_body, PreferenceManager.getDefaultSharedPreferences(SignUpActivity.this).getString("oops", "هناك خطأ ما"), Snackbar.LENGTH_LONG);
                        snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
                        snackbar.show();

                    }
                }
            }

            @Override
            public void onFailure(Call<DefaultResult> call, Throwable t) {
                generic.hideProgressBar(progressBar);
                Snackbar snackbar = Snackbar.make(rl_body, PreferenceManager.getDefaultSharedPreferences(SignUpActivity.this).getString("oops", "هناك خطأ ما"), Snackbar.LENGTH_LONG);
                snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
                snackbar.show();
            }
        });
    }

    public void apiSignUp() {

        generic.showProgressBar(progressBar);
        OkHttpClient client = generic.setHeaderForReqs().build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(AppWebServices.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();
        ApiService service = retrofit.create(ApiService.class);
//        Call<DefaultResult> call = service.register(params);
        Call<SignUpResult> call = service.registernew(st_username, st_fname, st_ph, st_pwd,
                st_pwd, st_gender, st_blood, st_dob, st_email, docimageencode_FRONT_ForSignup,
                "jpg", docimageencode_BACK_ForSignup, "jpg", id_name, expiry_date, civil_number,
                StaticStrings.DEVICE_TYPE.toString(), Build.MODEL, Build.VERSION.RELEASE);

        call.enqueue(new Callback<SignUpResult>() {
            @Override
            public void onResponse(Call<SignUpResult> call, retrofit2.Response<SignUpResult> response) {

                generic.hideProgressBar(progressBar);
                int code = response.code();
                if (response.code() == 200) {
                    Boolean status = response.body().getstatus();
                    String message = response.body().getMessage();

                    if (status) {
//                        generic.showSnackbar(rl_body, message, Snackbar.LENGTH_LONG, "close", true);

                        try {
                            SignUpPreActivityObject.finish();
                        } catch (Exception e) {
                        }
                        userProfile.clear();
                        SignUpdata data = response.body().getdata();
                        UserInformation object = new UserInformation();
                        object.setemail(data.getEmail());
                        object.setaddress(data.getaddress());
                        object.setauthtocken(data.getauth_token());
                        object.setdob(data.getdob());
                        object.setgender(data.getgender());
                        object.setpassword(st_pwd);
                        object.setName(data.getuser_name());
                        object.setuserid(data.getuser_id());
                        object.setId(1);
                        object.setis_vendor(data.getisvendor());
                        addDataintoUserinfo(object);
                        userProfile.add(object);
                        PreferenceManager.getDefaultSharedPreferences(SignUpActivity.this).edit().putBoolean("servicesstatus", data.getadd_services()).apply();
                        PreferenceManager.getDefaultSharedPreferences(SignUpActivity.this).edit().putString("username", data.getuser_name()).apply();
                        PreferenceManager.getDefaultSharedPreferences(SignUpActivity.this).edit().putString("documentstatus", data.getdocument_status()).apply();
                        PreferenceManager.getDefaultSharedPreferences(SignUpActivity.this).edit().putBoolean("firstTimeLogin", true).apply();
                        if (data.getadd_services()) {
                            Intent g = new Intent(SignUpActivity.this, DashboardActivity.class);
                            startActivity(g);
                            finish();
                            overridePendingTransition(R.anim.start_slide_in_left, R.anim.start_slide_out_left);
                        } else {
                            ISFROMFEDITPROFILE = false;
                            Intent g = new Intent(SignUpActivity.this, EditProfileActivity.class);
                            startActivity(g);
                            overridePendingTransition(R.anim.start_slide_in_left, R.anim.start_slide_out_left);
                        }

                    } else {

                        generic.showSnackbar(rl_body, message, Snackbar.LENGTH_LONG, "close", false);

                    }
                } else if (response.code() == 401) {
                    try {
                        RealmResults<UserInformation> results = getDataintoUserinfo();
                        if (results.size() > 0) {
                            deleteUserinfo();
                            PreferenceManager.getDefaultSharedPreferences(SignUpActivity.this).edit().putBoolean("firstTimeLogin", false).apply();
                        }
                        String userMessage = PreferenceManager.getDefaultSharedPreferences(SignUpActivity.this).getString("oops", "هناك خطأ ما");
                        try {

//                            String dataArrayMessage = "";
//                            try {
//                                ArrayList<String> message = response.body().getmessage();
//                                for (int i = 0; i < message.size(); i++) {
//                                    dataArrayMessage = dataArrayMessage + message.get(i) + "\n";
//                                }
//
//                            } catch (Exception e) {
//                            }

                            JSONObject jObjError = new JSONObject(response.errorBody().string());
                            String errorMessage = jObjError.getString("message");
//                            errorMessage = response.body().getMessage();
                            if (errorMessage != null && !errorMessage.equals("")) {
                                userMessage = errorMessage;
                            }
                        } catch (Exception e) {
                        }
                        String OK = PreferenceManager.getDefaultSharedPreferences(SignUpActivity.this).getString("ok", "موافق");
                        AlertDialog alert = new AlertDialog.Builder(SignUpActivity.this)
                                .create();
                        alert.setMessage(userMessage);
                        alert.setButton(DialogInterface.BUTTON_POSITIVE, OK, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {

                                dialog.dismiss();

                            }
                        });
                        alert.show();

                    } catch (Exception e) {

                        String userMessage = PreferenceManager.getDefaultSharedPreferences(SignUpActivity.this).getString("oops", "هناك خطأ ما");
                        showSnackbar(rl_body, userMessage, Snackbar.LENGTH_LONG, "close", false);
                    }

                } else {

                    try {

                        String userMessage = PreferenceManager.getDefaultSharedPreferences(SignUpActivity.this).getString("oops", "هناك خطأ ما");
                        JSONObject jObjError = new JSONObject(response.errorBody().string());
                        try {
                            userMessage = jObjError.getString("message");
                        } catch (Exception e) {
                        }

                        String dataArrayMessage = "";
                        try {
                            JSONArray jsonArray = jObjError.getJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                dataArrayMessage = dataArrayMessage + jsonArray.getString(i) + "\n";
                            }

                        } catch (Exception e) {
                        }

                        String maintenanceBtnText = "Try Again";
                        try {
                            maintenanceBtnText = jObjError.optString("btn_text");
                        } catch (Exception e) {
                        }
                        generic.genericCodes(rl_body, response.code(), userMessage, dataArrayMessage, maintenanceBtnText);
                    } catch (Exception e) {

                        generic.showSnackbar(progressBar, "هناك خطأ ما", Snackbar.LENGTH_LONG, "close", false);

                    }


                }
            }

            @Override
            public void onFailure(Call<SignUpResult> call, Throwable t) {

                generic.hideProgressBar(progressBar);
                generic.showSnackbar(progressBar, "هناك خطأ ما", Snackbar.LENGTH_LONG, "close", false);

            }
        });
    }


    public void apiCheckPhonenumber() {
        generic.showProgressBar(progressBar);
        Map<String, String> params = generic.setBasicParams();
        params.put("phone", et_phone.getText().toString());
        OkHttpClient client = generic.setHeaderForReqs().build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(AppWebServices.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();
        ApiService service = retrofit.create(ApiService.class);
        Call<DefaultResult> call = service.phonenumber(params);
        call.enqueue(new Callback<DefaultResult>() {

            @Override
            public void onResponse(Call<DefaultResult> call, retrofit2.Response<DefaultResult> response) {
                if (response.code() == 200) {

                    Boolean status = response.body().getstatus();
                    String Message = response.body().getMessage();

                    if (status) {
                        generic.hideProgressBar(progressBar);
                        hideKeyboard();
//                        Intent intent = new Intent(SignUpPreActivity.this, SignUpActivity.class);
//                        intent.putExtra("fname", st_fname);
//                        intent.putExtra("sname", st_sname);
//                        intent.putExtra("familyname", st_familyname);
//                        intent.putExtra("iddob", st_dob);
//                        intent.putExtra("ph", st_ph);
//                        intent.putExtra("gender", st_gender);
//                        intent.putExtra("Blood", st_blood);
//                        intent.putExtra("idname", id_name);
//                        intent.putExtra("id_number", civil_number);
//                        intent.putExtra("expiry_date", expiry_date);
//                        intent.putExtra("id_front", docimageencode_FRONT);
//                        intent.putExtra("id_back", docimageencode_BACK);
                        Intent intent = new Intent(SignUpActivity.this, OtpVerificationActivity.class);
                        intent.putExtra("phone", st_phone);
                        intent.putExtra("fname", st_fname);
                        intent.putExtra("iddob", st_dob);
                        intent.putExtra("gender", st_gender);
                        intent.putExtra("Blood", st_blood);
                        intent.putExtra("idname", id_name);
                        intent.putExtra("id_number", civil_number);
                        intent.putExtra("expiry_date", expiry_date);
                        intent.putExtra("username", st_username);
                        intent.putExtra("password", st_pwd);
                        intent.putExtra("email", st_email);
                        startActivity(intent);
                        finish();
                        animStart();



                    } else {
                        generic.hideProgressBar(progressBar);
                        Snackbar snackbar = Snackbar.make(rl_body, Message, Snackbar.LENGTH_LONG);
                        snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
                        snackbar.show();
                    }

                } else {
                    generic.hideProgressBar(progressBar);
                    try {

                        generic.hideProgressBar(progressBar);
                        String userMessage = PreferenceManager.getDefaultSharedPreferences(SignUpActivity.this).getString("oops", "هناك خطأ ما");
                        JSONObject jObjError = new JSONObject(response.errorBody().string());
                        try {
                            userMessage = jObjError.getString("message");
                        } catch (Exception e) {
                        }

                        String dataArrayMessage = "";
                        try {
                            JSONArray jsonArray = jObjError.getJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                dataArrayMessage = dataArrayMessage + jsonArray.getString(i) + "\n";
                            }

                        } catch (Exception e) {
                        }


                        String maintenanceBtnText = "Try Again";
                        try {
                            maintenanceBtnText = jObjError.optString("btn_text");
                        } catch (Exception e) {
                        }

                        generic.genericCodes(rl_body, response.code(), userMessage, dataArrayMessage, maintenanceBtnText);

                    } catch (Exception e) {

                        generic.hideProgressBar(progressBar);
                        Snackbar snackbar = Snackbar.make(rl_body, PreferenceManager.getDefaultSharedPreferences(SignUpActivity.this).getString("oops", "هناك خطأ ما"), Snackbar.LENGTH_LONG);
                        snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
                        snackbar.show();

                    }
                }
            }

            @Override
            public void onFailure(Call<DefaultResult> call, Throwable t) {
                generic.hideProgressBar(progressBar);
                Snackbar snackbar = Snackbar.make(rl_body, PreferenceManager.getDefaultSharedPreferences(SignUpActivity.this).getString("oops", "هناك خطأ ما"), Snackbar.LENGTH_LONG);
                snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
                snackbar.show();
            }
        });
    }

    public RealmResults<UserInformation> getDataintoUserinfo(String user_id) {
        realm.beginTransaction();  //open the database
        RealmResults<UserInformation> results = realm.where(UserInformation.class).equalTo("id", 1).findAllAsync();
        results.load();
        realm.commitTransaction();
        return results;
    }

    public void deleteUserinfo(String user_id) {

        realm.beginTransaction();  //open the database

        final RealmResults<UserInformation> results = realm.where(UserInformation.class).equalTo("id", 1).findAll();
        results.deleteAllFromRealm();
        realm.commitTransaction();
    }

    public void addDataintoUserinfo(UserInformation obj_) {

        RealmResults<UserInformation> results = getDataintoUserinfo(obj_.getuserid());
        if (results.size() > 0) {
            deleteUserinfo("1");
            addDataintoUserinfo(obj_);
        } else {
            realm.beginTransaction();  //open the database
            //database operation
            UserInformation obj = realm.createObject(UserInformation.class);
            obj.setId(obj_.getId());
            obj.setName(obj_.getName());
            obj.setemail(obj_.getemail());
            obj.setpassword(obj_.getpassword());
            obj.setaddress(obj_.getaddress());
            obj.setauthtocken(obj_.getauthtocken());
            obj.setdob(obj_.getdob());
            obj.setis_vendor(obj_.getis_vendor());
            obj.setuserid(obj_.getuserid());
            obj.setgender(obj_.getgender());
            //inserted all Data to database
            realm.commitTransaction(); //close the database
        }
    }

}
