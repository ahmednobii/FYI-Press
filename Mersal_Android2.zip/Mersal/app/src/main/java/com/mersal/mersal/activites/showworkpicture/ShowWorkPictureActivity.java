package com.mersal.mersal.activites.showworkpicture;

import android.graphics.PorterDuff;
import android.os.Build;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.drawable.GlideDrawable;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.github.chrisbanes.photoview.PhotoView;
import com.mersal.mersal.R;
import com.mersal.mersal.activites.base.BaseActivity;
import com.mersal.mersal.customviews.NoDataFoundCustomTV;
import com.mersal.mersal.generic.Interfaces.Generic;
import com.mersal.mersal.internetconnections.NetworkConnection;
import com.mersal.mersal.utilties.OnPinchListener;
import com.mersal.mersal.utilties.TouchImageView;

public class ShowWorkPictureActivity extends BaseActivity {

    public static ShowWorkPictureActivity objShowWorkPictureActivity;
    PhotoView iv_showimage;
    RelativeLayout header_left_rl, rl_body;
    ProgressBar progressBar;
    NoDataFoundCustomTV tv_noresult;
    NetworkConnection ntobj = new NetworkConnection(ShowWorkPictureActivity.this);
    Generic generic;
    String url;
    // Used to detect pinch zoom gesture.
    private ScaleGestureDetector scaleGestureDetector = null;
    private ScaleGestureDetector mScaleGestureDetector;
    private float mScaleFactor = 1.0f;
    private TouchImageView mImageView;

    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        setContentView(R.layout.activity_show_pic);
        if (ShowWorkPictureActivity.this instanceof BaseActivity) {
            generic = (Generic) ShowWorkPictureActivity.this;
        }
        generic.hideStatusBar();
        init();
        clickListener();
//        initControls();
        objectBAJava.hideKeyboard();
        objShowWorkPictureActivity = this;
    }

    public void init() {
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        progressBar.setVisibility(View.GONE);
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT) {
            progressBar.getIndeterminateDrawable().setColorFilter(getResources()
                    .getColor(R.color.progress_bar_color_white), PorterDuff.Mode.SRC_IN);
        }
        mImageView = (TouchImageView) findViewById(R.id.imageView);
        iv_showimage = (PhotoView) findViewById(R.id.iv_showimage);
        header_left_rl = (RelativeLayout) findViewById(R.id.header_left_rl);
        tv_noresult = (NoDataFoundCustomTV) findViewById(R.id.tv_noresult);
        rl_body = (RelativeLayout) findViewById(R.id.rl_main);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            url = extras.getString("imageuri");
        }

        progressBar.setVisibility(View.VISIBLE);
        mImageView.setVisibility(View.GONE);
//        mScaleGestureDetector = new ScaleGestureDetector(this, new ScaleListener());

        Glide.with(this)
                .load(url)
                .override(1080, 1920) // resizes the image to these dimensions (in pixel). resize does not respect aspect ratio
                .placeholder(R.drawable.no_image_available)
                .error(R.drawable.no_image_available)
                .dontAnimate()
                .listener(new RequestListener<String, GlideDrawable>() {
                    @Override
                    public boolean onException(Exception e, String model, Target<GlideDrawable> target, boolean isFirstResource) {
                        if (progressBar != null) {
//
                            progressBar.setVisibility(View.GONE);
                        }
                        mImageView.setVisibility(View.VISIBLE);
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(GlideDrawable resource, String model, Target<GlideDrawable> target,
                                                   boolean isFromMemoryCache, boolean isFirstResource) {
                        if (progressBar != null) {
//
                            progressBar.setVisibility(View.GONE);
                        }
                        mImageView.setVisibility(View.VISIBLE);
                        return false;
                    }
                })
                .into(mImageView);

    }

    public void clickListener() {

        header_left_rl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hideKeyboard();
                finish();
                animEnd();
            }

        });
    }

    private void initControls() {

        if (scaleGestureDetector == null) {
            // Create an instance of OnPinchListner custom class.
            OnPinchListener onPinchListener = new OnPinchListener(getApplicationContext(), mImageView);

            // Create the new scale gesture detector object use above pinch zoom gesture listener.
            scaleGestureDetector = new ScaleGestureDetector(getApplicationContext(), onPinchListener);
        }
    }

//    private void initControls() {
//
//        if (scaleGestureDetector == null) {
//            // Create an instance of OnPinchListner custom class.
//            OnPinchListener onPinchListener = new OnPinchListener(getApplicationContext(), iv_showimage);
//
//            // Create the new scale gesture detector object use above pinch zoom gesture listener.
//            scaleGestureDetector = new ScaleGestureDetector(getApplicationContext(), onPinchListener);
//        }
//    }

//    @Override
//    public boolean onTouchEvent(MotionEvent event) {
//        // Dispatch activity on touch event to the scale gesture detector.
//        scaleGestureDetector.onTouchEvent(event);
//        return true;
//    }

    // this redirects all touch events in the activity to the gesture detector
//    @Override
//    public boolean onTouchEvent(MotionEvent event) {
//        return mScaleGestureDetector.onTouchEvent(event);
//    }

    private class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {

        // when a scale gesture is detected, use it to resize the image
        @Override
        public boolean onScale(ScaleGestureDetector scaleGestureDetector) {
            mScaleFactor *= scaleGestureDetector.getScaleFactor();
            mImageView.setScaleX(mScaleFactor);
            mImageView.setScaleY(mScaleFactor);
            return true;
        }
    }

}
