package com.mersal.mersal.realm;

import io.realm.RealmObject;
//import io.realm.annotations.PrimaryKey;

public class UserInformation extends RealmObject {

    String  user_id, name, address, authtocken, email, gender, password,  dob;
    //    @PrimaryKey
    private int id;
    boolean is_vendor = false;

    public String getuserid() {

        if (user_id == null) {
            return "";
        }
        return user_id;
    }

    public void setuserid(String userid) {
        this.user_id = userid;
    }
    
    public Boolean getis_vendor() {

        if (is_vendor == false) {
            return false;
        }
        return is_vendor;
    }

    public void setis_vendor(Boolean is_vendor) {
        this.is_vendor = is_vendor;
    }
    
    public String getdob() {

        if (dob == null) {
            return "";
        }
        return dob;
    }

    public void setdob(String dob) {
        this.dob = dob;
    }

    public String getName() {
        if (name == null) {
            return "";
        }
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public String getaddress() {
        if (address == null) {
            return "";
        }

        return address;
    }

    public void setaddress(String address) {
        this.address = address;
    }

    public String getauthtocken() {


        if (authtocken == null) {
            return "";
        }
        return authtocken;
    }

    public void setauthtocken(String authtocken) {
        this.authtocken = authtocken;
    }

    public String getemail() {

        if (email == null) {
            return "";
        }
        return email;
    }

    public void setemail(String email) {
        this.email = email;
    }

    public String getgender() {

        if (gender == null) {
            return "";
        }
        return gender;
    }

    public void setgender(String gender) {
        this.gender = gender;
    }

    public String getpassword() {

        if (password == null) {
            return "";
        }
        return password;
    }

    public void setpassword(String password) {
        this.password = password;
    }


}

