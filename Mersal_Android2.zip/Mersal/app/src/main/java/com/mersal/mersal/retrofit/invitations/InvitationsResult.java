package com.mersal.mersal.retrofit.invitations;

import com.google.gson.annotations.SerializedName;
import com.mersal.mersal.retrofit.electorsdetails.ElectorsDetaildata;


public class InvitationsResult {
    @SerializedName("status")
    private Boolean status = false;

    @SerializedName("message")
    private String message = "";

    @SerializedName("data")
    private Invitationsdata data;

    public Boolean getstatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public Invitationsdata getdata() {
        return data;
    }


}