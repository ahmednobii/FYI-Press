
package com.mersal.mersal.retrofit.Login;


import com.google.gson.annotations.SerializedName;

public class LoginResult {
    @SerializedName("status")
    private Boolean status = false;

    @SerializedName("message")
    private String message = "";

    @SerializedName("data")
    private LoginResultdata LoginResultdata;

    public Boolean getstatus() {
        return status;
    }
    public String getMessage() {
        return message;
    }
    public LoginResultdata getdata() {
        return LoginResultdata;
    }

}