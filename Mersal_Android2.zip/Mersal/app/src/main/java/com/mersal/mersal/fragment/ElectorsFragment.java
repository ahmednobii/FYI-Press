package com.mersal.mersal.fragment;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.mersal.mersal.R;
import com.mersal.mersal.activites.auth.SignUpActivity;
import com.mersal.mersal.activites.auth.SigninActivity;
import com.mersal.mersal.activites.base.BaseActivity;
import com.mersal.mersal.activites.elections.ElectoionsDetailsActivity;
import com.mersal.mersal.activites.electors.ElectorsDetailsActivity;
import com.mersal.mersal.activites.registerdocuments.RegisterVoteWithScanActivity;
import com.mersal.mersal.adapter.ElectorsLvAdapter;
import com.mersal.mersal.customviews.NoDataFoundCustomTV;
import com.mersal.mersal.generic.Interfaces.Generic;
import com.mersal.mersal.internetconnections.NetworkConnection;
import com.mersal.mersal.retrofit.baseapi.ApiService;
import com.mersal.mersal.retrofit.baseapi.AppWebServices;
import com.mersal.mersal.retrofit.defualt.DefaultResult;
import com.mersal.mersal.retrofit.electors.ElectorsResult;
import com.mersal.mersal.retrofit.electors.Electorsdataelectors;
import com.mersal.mersal.utilties.StaticStrings;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Map;

import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static com.mersal.mersal.activites.base.BaseActivity.objectBAJava;
import static com.mersal.mersal.activites.dashboard.DashboardActivity.dashboardActivityObject;
import static com.mersal.mersal.utilties.StaticStrings.ISFROMREGISTERID;
import static com.mersal.mersal.utilties.StaticStrings.IsFirstTIMEINAPP;

public class ElectorsFragment extends Fragment {

    TextView tv_question, tv_logout, tv_submit, tv_addidcard, tv_addStatus, tv_details, tv_date, tv_datevalue;
    ListView listView;
    ProgressBar spinner, spinner1;
    RelativeLayout rl_submit, rl_logout, rl_addidcard, rl_details, rl_addcardmain, rl_body;
    RelativeLayout ll_two;
    Generic generic;
    ElectorsLvAdapter adapter;
    int total_records;
    boolean reqIsInProgress = false;
    int page = 1;
    String fromPrevId = "", election_id = "";
    ArrayList<Electorsdataelectors> activitiesData = new ArrayList<>();
    ArrayList<String> activitiesVoterData = new ArrayList<>();
    public static ElectorsFragment objElectorsFragment;
    NetworkConnection ntobj;
    NoDataFoundCustomTV tv_noresult;
    int selectedcount = 0;
    int selectedlimit = 0;
    public ArrayList<String> mArrayVotersId = new ArrayList<>();
    public String detailsofElection = "", titleofElection = "";
    String end_time;
    private TextView tv_description, tv_number_vote, tv_end_time;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.activity_electores, container, false);
        dashboardActivityObject.hideViewFromElectorFragment();
        dashboardActivityObject.hideheader_left_rlFromElectorFragment();
        objElectorsFragment = this;
        if (getActivity() instanceof BaseActivity) {
            generic = (Generic) getActivity();
        }
        init(rootView);
        clickListener();
//        firsttimeCall();
//        callApiFirsttime();
        generic.hideStatusBar();//initialize to access database for this activity
        return rootView;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        boolean isDeviceTockenSend = PreferenceManager.getDefaultSharedPreferences(objectBAJava).getBoolean("isDevicetockensend", false);
        System.out.println("Check device tocken start ef " + isDeviceTockenSend);

        if (!isDeviceTockenSend) {
            if (ntobj.isConnectingToInternet()) {
                objectBAJava.hideKeyboard();
                apiCallDeviceTocken();
            } else {
                String Message = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
//                generic.showSnackbar(rl_body, Message, Snackbar.LENGTH_LONG, "close", false);
            }
        }

        if (ntobj.isConnectingToInternet()) {
            objectBAJava.hideKeyboard();
            activitiesData.clear();
            tv_noresult.setVisibility(View.GONE);
            ll_two.setVisibility(View.GONE);
            if (!ISFROMREGISTERID) {
                callApiFirsttime();
            }
        } else {
            activitiesData.clear();
            tv_noresult.setVisibility(View.VISIBLE);
            ll_two.setVisibility(View.GONE);
            String Message = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
            generic.showSnackbar(rl_body, Message, Snackbar.LENGTH_LONG, "close", false);
        }
    }

    public void init(View rootView) {
        ntobj = new NetworkConnection(getActivity());
        listView = (ListView) rootView.findViewById(R.id.lv_propsel);
        tv_question = (TextView) rootView.findViewById(R.id.tv_question);
        tv_logout = (TextView) rootView.findViewById(R.id.tv_logout);
        tv_submit = (TextView) rootView.findViewById(R.id.tv_submit);
        tv_addStatus = (TextView) rootView.findViewById(R.id.tv_addStatus);
        rl_submit = (RelativeLayout) rootView.findViewById(R.id.rl_submit);
        rl_logout = (RelativeLayout) rootView.findViewById(R.id.rl_logout);
        rl_body = (RelativeLayout) rootView.findViewById(R.id.rl_body);
        rl_addcardmain = (RelativeLayout) rootView.findViewById(R.id.rl_addcardmain);
        ll_two = (RelativeLayout) rootView.findViewById(R.id.ll_two);
        tv_addidcard = (TextView) rootView.findViewById(R.id.tv_addidcard);
        rl_addidcard = (RelativeLayout) rootView.findViewById(R.id.rl_addidcard);
        rl_details = (RelativeLayout) rootView.findViewById(R.id.rl_details);
        tv_description = rootView.findViewById(R.id.tv_description);
        tv_number_vote = rootView.findViewById(R.id.tv_number_vote);
        tv_end_time = rootView.findViewById(R.id.tv_end_time);

        tv_question.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_addStatus.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_addidcard.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_description.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_number_vote.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_end_time.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_noresult = (NoDataFoundCustomTV) rootView.findViewById(R.id.tv_noresult);
        spinner = (ProgressBar) rootView.findViewById(R.id.progressBar);
        spinner1 = (ProgressBar) rootView.findViewById(R.id.progress_view1);
        spinner.setVisibility(View.GONE);
        spinner1.setVisibility(View.GONE);
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT) {
            spinner.getIndeterminateDrawable().setColorFilter(getResources()
                    .getColor(R.color.progress_bar_color_white), PorterDuff.Mode.SRC_IN);
            spinner1.getIndeterminateDrawable().setColorFilter(getResources()
                    .getColor(R.color.progress_bar_color_white), PorterDuff.Mode.SRC_IN);
        }
        rl_addcardmain.setVisibility(View.GONE);
        tv_addidcard.setVisibility(View.GONE);
        tv_addStatus.setVisibility(View.GONE);
        rl_addidcard.setVisibility(View.GONE);
        rl_logout.setVisibility(View.GONE);

        tv_details = (TextView) rootView.findViewById(R.id.tv_details);
        tv_details.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_date = (TextView) rootView.findViewById(R.id.tv_date);
        tv_date.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_datevalue = (TextView) rootView.findViewById(R.id.tv_datevalue);
        tv_datevalue.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_submit.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_logout.setTypeface(objectBAJava.Tahoma_Regular_font);

        int limit = PreferenceManager.getDefaultSharedPreferences(getActivity()).getInt("limit_number", 0);
        tv_number_vote.setText( " عدد الاصوات :" + " "+limit );
    }

    public void clickListener() {

        rl_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                logoutconfirm();
            }
        });

        rl_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                objectBAJava.hideStatusBar();

                velidation();
            }
        });


        rl_addidcard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                objectBAJava.hideStatusBar();
                Intent intent = new Intent(getActivity(), RegisterVoteWithScanActivity.class);
                startActivity(intent);
                getActivity().overridePendingTransition(R.anim.start_slide_in_left, R.anim.start_slide_out_left);
            }
        });

        rl_details.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                objectBAJava.hideStatusBar();

                goOnElectionDetailsActivity(detailsofElection, titleofElection);
            }
        });
    }

    public void voteConfirm() {


        String name = "";
        int nCount = 0;
        for (int i = 0; i < activitiesData.size(); i++) {
            if (activitiesData.get(i).getisselect()) {
                name += activitiesData.get(i).getelector_name() + ", ";
            }
        }
        name = name.substring(0, name.length()-2);
        AlertDialog alert = new AlertDialog.Builder(getActivity())
                .create();
        alert.setMessage("   هل أنت متأكد من إختيارك  \n"+ name+"?");
        alert.setButton(DialogInterface.BUTTON_POSITIVE, "نعم", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {

                dialog.dismiss();
                generic.showProgressBar(spinner);
                apiCallVote();

            }
        });
        alert.setButton(DialogInterface.BUTTON_NEGATIVE, "لا", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {

                dialog.dismiss();
                generic.hideProgressBar(spinner);

            }
        });
        alert.show();
    }

    public void apiCallElectorsList() {
        tv_noresult.setVisibility(View.GONE);
//        reqIsInProgress = true;
//        if (page == 1) {
        activitiesData.clear();
        activitiesData = new ArrayList<>();
        generic.showProgressBar(spinner);
//        }
//        else {
//
//            int bottomMargin = (int) getResources().getDimension(R.dimen.pagination_progressbar_size);
//            RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) listView.getLayoutParams();
//            lp.setMargins(8, 8, 8, bottomMargin + 5);
//            listView.setLayoutParams(lp);
//            spinner1.setVisibility(View.VISIBLE);
//        }

        Map<String, String> params = generic.setBasicParams();
        params.put("auth_token", generic.getAuthTockenFromDb());
//        params.put("page_no", String.valueOf(page));
//        params.put("order", "asc");
//        params.put("order_by", "date");
//        params.put("keyword", "");

        OkHttpClient client = generic.setHeaderForReqs().build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(AppWebServices.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();

        ApiService service = retrofit.create(ApiService.class);
        Call<ElectorsResult> call = service.electorslist(params);
        call.enqueue(new Callback<ElectorsResult>() {

            @Override
            public void onResponse(Call<ElectorsResult> call, retrofit2.Response<ElectorsResult> response) {
                if (response.code() == 200) {
                    Boolean status = response.body().getstatus();
                    String Message = response.body().getMessage();
//                    if (status) {
//                        generic.hideProgressBar(spinner);
//                        generic.hideProgressBar(spinner1);
//                        ll_two.setVisibility(View.VISIBLE);
//                        listView.setVisibility(View.VISIBLE);
//                        tv_noresult.setVisibility(View.GONE);

//                    if (status) {
                    if (!response.body().getdata().getuser_status().equals("rejected")) {
                        dashboardActivityObject.setTitleText("التصويت");
                        if (response.body().getdata().getdocument_status().equals("not_uploaded")) {

                            dashboardActivityObject.hideViewFromElectorFragment();
                            dashboardActivityObject.showheader_left_rlFromElectorFragment();

                            generic.hideProgressBar(spinner);
                            generic.hideProgressBar(spinner1);
                            ll_two.setVisibility(View.GONE);
                            listView.setVisibility(View.GONE);
                            tv_noresult.setVisibility(View.GONE);
                            rl_addcardmain.setVisibility(View.VISIBLE);
                            tv_addidcard.setVisibility(View.VISIBLE);
                            tv_addStatus.setVisibility(View.VISIBLE);
                            rl_addidcard.setVisibility(View.VISIBLE);
                            tv_addStatus.setText("أضف بطاقتك الشخصية حتى تتمكن من التصويت");
                            tv_addidcard.setText("أضف بطاقتك الشخصية");

                        } else if (response.body().getdata().getdocument_status().equals("uploaded")) {

                            dashboardActivityObject.hideViewFromElectorFragment();
                            dashboardActivityObject.showheader_left_rlFromElectorFragment();

                            generic.hideProgressBar(spinner);
                            generic.hideProgressBar(spinner1);
                            ll_two.setVisibility(View.GONE);
                            tv_noresult.setVisibility(View.GONE);
                            listView.setVisibility(View.GONE);
                            rl_addcardmain.setVisibility(View.VISIBLE);
                            tv_addidcard.setVisibility(View.VISIBLE);
                            tv_addStatus.setVisibility(View.VISIBLE);
                            rl_addidcard.setVisibility(View.GONE);
                            tv_addStatus.setText("في حالة قبول التسجيل ام لا، ستتم تحديث الصفحة و موافاتك برسالة نصية بغية ذلك");

                            dashboardActivityObject.setTitleText("لواتي مرسال");


                        } else if (response.body().getdata().getdocument_status().equals("rejected")) {

                            dashboardActivityObject.hideViewFromElectorFragment();
                            dashboardActivityObject.showheader_left_rlFromElectorFragment();
                            dashboardActivityObject.setTitleText("لواتي مرسال");
                            generic.hideProgressBar(spinner);
                            generic.hideProgressBar(spinner1);
                            ll_two.setVisibility(View.GONE);
                            tv_noresult.setVisibility(View.GONE);
                            listView.setVisibility(View.GONE);
                            rl_addcardmain.setVisibility(View.VISIBLE);
                            tv_addidcard.setVisibility(View.VISIBLE);
                            tv_addStatus.setVisibility(View.VISIBLE);
                            rl_addidcard.setVisibility(View.VISIBLE);
                            tv_addStatus.setText("قم بإعادة إدخال بياناتك ");
                            tv_addidcard.setText("أضف بطاقتك الشخصية");


                        } else if (response.body().getdata().getdocument_status().equals("approved")) {
                            if (IsFirstTIMEINAPP) {
                                dashboardActivityObject.setupNavigationView(2);
                                dashboardActivityObject.hideheader_left_rlFromElectorFragment();
                                dashboardActivityObject.hideViewFromElectorFragment();
                            } else {
                                dashboardActivityObject.showViewFromElectorFragment();
                                dashboardActivityObject.hideheader_left_rlFromElectorFragment();

                                if (status) {
                                    rl_addcardmain.setVisibility(View.GONE);
                                    tv_addidcard.setVisibility(View.GONE);
                                    tv_addStatus.setVisibility(View.GONE);
                                    rl_addidcard.setVisibility(View.GONE);
                                    generic.hideProgressBar(spinner);
                                    generic.hideProgressBar(spinner1);
                                    ll_two.setVisibility(View.VISIBLE);
                                    listView.setVisibility(View.VISIBLE);
                                    tv_noresult.setVisibility(View.GONE);

                                    tv_question.setText(response.body().getdata().getelection().gettitle());
                                    tv_datevalue.setText(response.body().getdata().getelection().getend_date());
                                    end_time = response.body().getdata().getelection().getend_time();
                                    end_time = end_time.replace("AM", "ص ");
                                    end_time = end_time.replace("PM", "م ");

                                    tv_end_time.setText( " وقت الإنتهاء : " + end_time +"");

                                    election_id = response.body().getdata().getelection().getid();
                                    detailsofElection = response.body().getdata().getelection().getshort_description();
                                    titleofElection = response.body().getdata().getelection().gettitle();
                                    if (response.body().getdata().getelectors().size() > 0) {
                                        for (int i = 0; i < response.body().getdata().getelectors().size(); i++) {
                                            activitiesData.add(response.body().getdata().getelectors().get(i));
                                        }
                                    }
                                    if (response.body().getdata().getuser().getselected_elector_ids() != null) {
                                        if (response.body().getdata().getuser().getselected_elector_ids().size() > 0) {
                                            for (int i = 0; i < response.body().getdata().getuser().getselected_elector_ids().size(); i++) {

                                                activitiesVoterData.add(response.body().getdata().getuser().getselected_elector_ids().get(i));
                                            }
                                        }
                                    }
                                    if (activitiesVoterData.size() > 0) {
                                        for (int i = 0; i < activitiesData.size(); i++) {

                                            for (int j = 0; j < activitiesVoterData.size(); j++) {

                                                if (activitiesVoterData.get(j).equals(activitiesData.get(i).getid())) {
                                                    activitiesData.get(i).setisvoted(true);
                                                }
                                            }
                                        }
                                    }

                                    if (!response.body().getdata().getuser().getis_already_voted()) {
                                        if (response.body().getdata().getelection().getno_of_electors_select().equals("0")) {

                                            ll_two.setVisibility(View.GONE);
                                            tv_noresult.setVisibility(View.VISIBLE);
                                            tv_noresult.setText("لا توجد انتخابات متاحة");

                                        } else {

                                            selectedlimit = Integer.parseInt(response.body().getdata().getelection().getno_of_electors_select());
                                            tv_number_vote.setText( " عدد الاصوات :" + " "+selectedlimit );
                                            PreferenceManager.getDefaultSharedPreferences(getActivity()).edit().putInt("limit_number", selectedlimit).apply();
                                            boolean isselect = response.body().getdata().getuser().getis_already_voted();
                                            if (activitiesData.size() == 0 || activitiesData == null) {
                                                ll_two.setVisibility(View.GONE);
                                                generic.hideProgressBar(spinner);
                                                spinner1.setVisibility(View.GONE);
                                                tv_noresult.setVisibility(View.VISIBLE);
                                                listView.setVisibility(View.GONE);
                                                rl_submit.setVisibility(View.GONE);
                                            } else {
                                                System.out.println("Size from first " + activitiesData.size());
                                                adapter = new ElectorsLvAdapter(objectBAJava, activitiesData, objElectorsFragment, isselect);
                                                listView.setAdapter(adapter);
                                                rl_submit.setVisibility(View.VISIBLE);
                                                ll_two.setVisibility(View.VISIBLE);
                                                listView.setVisibility(View.VISIBLE);
                                                generic.hideProgressBar(spinner);
                                                tv_noresult.setVisibility(View.GONE);
                                            }
                                        }
                                    } else // already cast vote

                                    {
                                        // hide button and disable selection
                                        boolean isselect = response.body().getdata().getuser().getis_already_voted();
                                        if (activitiesData.size() == 0 || activitiesData == null) {
                                            generic.hideProgressBar(spinner);
                                            spinner1.setVisibility(View.GONE);
                                            tv_noresult.setVisibility(View.VISIBLE);
                                            listView.setVisibility(View.GONE);
                                            rl_submit.setVisibility(View.GONE);
                                        } else {
                                            ll_two.setVisibility(View.VISIBLE);
                                            listView.setVisibility(View.VISIBLE);
                                            generic.hideProgressBar(spinner);
                                            tv_noresult.setVisibility(View.GONE);
                                            rl_submit.setVisibility(View.GONE);
                                            System.out.println("Size from second " + activitiesData.size());

                                            adapter = new ElectorsLvAdapter(getActivity(), activitiesData, objElectorsFragment, isselect);
                                            listView.setAdapter(adapter);
                                        }
                                    }

                                } else {
                                    generic.hideProgressBar(spinner);
                                    if (activitiesData.size() == 0 || activitiesData == null) {
                                        tv_noresult.setVisibility(View.VISIBLE);
                                        listView.setVisibility(View.GONE);
                                        tv_noresult.setText("لا يوجد تصويت فعال في هذه الفترة");
                                    }
//                        Snackbar snackbar = Snackbar.make(ll_two, Message, Snackbar.LENGTH_LONG);
//                        snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
//                        snackbar.show();
                                }
                            }
                        }

                    } else {
                        dashboardActivityObject.setTitleText("إنشاء حساب");
                        dashboardActivityObject.showheader_left_rlFromElectorFragment();
                        dashboardActivityObject.hideViewFromElectorFragment();
                        tv_noresult.setVisibility(View.GONE);
                        generic.hideProgressBar(spinner);
                        generic.hideProgressBar(spinner1);
                        ll_two.setVisibility(View.GONE);
                        listView.setVisibility(View.GONE);
                        rl_addcardmain.setVisibility(View.VISIBLE);
                        tv_addidcard.setVisibility(View.GONE);
                        tv_addStatus.setVisibility(View.VISIBLE);
                        rl_addidcard.setVisibility(View.GONE);
//                        tv_addStatus.setText("لا يمكنك التصويت");

//                        tv_addStatus.setText("لا يمكنك التصويت ، أنت مرفوض");
                        tv_addStatus.setText(" نعتذر عن قبول تسجيلك لعدم موافاتك بالشروط المطلوبة. للإستفسار يمكنك التواصل مع لجنة الكنترول على رقم"+"\n 98882478 ");
                        rl_logout.setVisibility(View.VISIBLE);
                    }

//                    }
//                    else {
//
//
//                        tv_noresult.setVisibility(View.VISIBLE);
//                        generic.hideProgressBar(spinner);
//                        generic.hideProgressBar(spinner1);
//                        ll_two.setVisibility(View.GONE);
//                        listView.setVisibility(View.GONE);
//                        rl_addcardmain.setVisibility(View.GONE);
//                        tv_addidcard.setVisibility(View.GONE);
//                        tv_addStatus.setVisibility(View.GONE);
//                        rl_addidcard.setVisibility(View.GONE);
//                        tv_noresult.setText("لا يوجد انتخابات");
//
//                    }

                } else {
//                    dashboardActivityObject.hideViewFromElectorFragment();
                    dashboardActivityObject.setTitleText("التصويت");
                    generic.hideProgressBar(spinner);
                    try {
                        if (activitiesData.size() == 0) {
                            tv_noresult.setVisibility(View.VISIBLE);
                            listView.setVisibility(View.GONE);
                        }
//                        spinner.setVisibility(View.GONE);
                        generic.hideProgressBar(spinner);
                        spinner1.setVisibility(View.GONE);
                        String userMessage = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("oops", "هناك خطأ ما");
                        JSONObject jObjError = new JSONObject(response.errorBody().string());
                        try {
                            userMessage = jObjError.getString("message");
                        } catch (Exception e) {
                        }
                        String dataArrayMessage = "";
                        try {
                            JSONArray jsonArray = jObjError.getJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                dataArrayMessage = dataArrayMessage + jsonArray.getString(i) + "\n";
                            }
                        } catch (Exception e) {
                        }
                        String maintenanceBtnText = "Try Again";
                        try {
                            maintenanceBtnText = jObjError.optString("btn_text");
                        } catch (Exception e) {
                        }
                        generic.genericCodes(ll_two, response.code(), userMessage, dataArrayMessage, maintenanceBtnText);

                    } catch (Exception e) {
//                        spinner.setVisibility(View.GONE);
                        generic.hideProgressBar(spinner);
                        spinner1.setVisibility(View.GONE);
                        if (activitiesData.size() == 0) {
                            tv_noresult.setVisibility(View.VISIBLE);
                            listView.setVisibility(View.GONE);
                        }
                        Snackbar snackbar = Snackbar.make(ll_two, PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("oops", "هناك خطأ ما"), Snackbar.LENGTH_LONG);
                        snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
                        snackbar.show();
                    }
                }
            }

            @Override
            public void onFailure(Call<ElectorsResult> call, Throwable t) {
                dashboardActivityObject.setTitleText("التصويت");
//                spinner.setVisibility(View.GONE);
                generic.hideProgressBar(spinner);
                spinner1.setVisibility(View.GONE);
                reqIsInProgress = false;

//                generic.showSnackbar(ll_two, "هناك خطأ ما", Snackbar.LENGTH_LONG, "", false);
                if (activitiesData.size() == 0) {
                    tv_noresult.setVisibility(View.VISIBLE);
                    listView.setVisibility(View.GONE);
                }
            }
        });
    }

    public void callApiFirsttime() {

        if (ntobj.isConnectingToInternet()) {
            ll_two.setVisibility(View.GONE);
            listView.setVisibility(View.GONE);
            generic.showProgressBar(spinner);
            tv_noresult.setVisibility(View.GONE);
            objectBAJava.hideKeyboard();
            reqIsInProgress = false;
            page = 1;
            total_records = 0;
            activitiesData.clear();
            generic.hideProgressBar(spinner1);
            apiCallElectorsList();
        } else {
            String Message = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
            generic.showSnackbar(rl_body, Message, Snackbar.LENGTH_LONG, "close", false);
            tv_noresult.setVisibility(View.VISIBLE);
            generic.hideProgressBar(spinner);
            ll_two.setVisibility(View.GONE);
            generic.hideProgressBar(spinner1);
            listView.setVisibility(View.GONE);
            page = 1;
            total_records = 0;
            reqIsInProgress = false;
            activitiesData.clear();
        }
    }

    public void goOnActivity(String id) {
        getActivity().getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
        Intent intent = new Intent(getActivity(), ElectorsDetailsActivity.class);
        intent.putExtra("id", id);
        startActivity(intent);
        getActivity().overridePendingTransition(R.anim.start_slide_in_left, R.anim.start_slide_out_left);
    }

    public void goOnElectionDetailsActivity(String details, String title) {
        getActivity().getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
        Intent intent = new Intent(getActivity(), ElectoionsDetailsActivity.class);
        intent.putExtra("details", details);
        intent.putExtra("title", title);
        startActivity(intent);
        getActivity().overridePendingTransition(R.anim.start_slide_in_left, R.anim.start_slide_out_left);
    }

    public void updateSelection(int position) {

        if (activitiesData.get(position).getisselect()) {
            activitiesData.get(position).setisselect(false);

        } else {
            activitiesData.get(position).setisselect(true);
        }
        adapter.notifyDataSetChanged();
    }

    public void velidation() {
        selectedcount = 0;
        for (int i = 0; i < activitiesData.size(); i++) {
            if (activitiesData.get(i).getisselect()) {
                selectedcount = selectedcount + 1;
            }
        }
        if (selectedcount <= 0) {
//            generic.showSnackbar(ll_two, "you are allow to select only" + selectedlimit + " electors", Snackbar.LENGTH_LONG, "close", false);
            generic.showSnackbar(rl_body,
                    "عليك إختيار " + selectedlimit + " فقط ", Snackbar.LENGTH_LONG, "close", false);

//            generic.showSnackbar(ll_two, "Select at least one", Snackbar.LENGTH_LONG, "close", false);

        } else if (selectedcount <= selectedlimit) {

            if (ntobj.isConnectingToInternet()) {
                tv_noresult.setVisibility(View.GONE);
                objectBAJava.hideKeyboard();

//                generic.showProgressBar(spinner);

                voteConfirm();

            } else {
                String Message = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
                generic.showSnackbar(rl_body, Message, Snackbar.LENGTH_LONG, "close", false);
            }

        } else {
            generic.showSnackbar(rl_body, " يسمح بإختيار عدد " + selectedlimit +  "فقط  ", Snackbar.LENGTH_LONG, "close", false);

//            generic.showSnackbar(ll_two, "you are allow to select only" + selectedlimit + " electors", Snackbar.LENGTH_LONG, "close", false);
        }
    }

    public void apiCallVote() {
        tv_noresult.setVisibility(View.GONE);
//        reqIsInProgress = true;
//        if (page == 1) {
        generic.showProgressBar(spinner);
//        }
//        else {
//
//            int bottomMargin = (int) getResources().getDimension(R.dimen.pagination_progressbar_size);
//            RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) listView.getLayoutParams();
//            lp.setMargins(8, 8, 8, bottomMargin + 5);
//            listView.setLayoutParams(lp);
//            spinner1.setVisibility(View.VISIBLE);
//        }

//        Map<String, String> params = generic.setBasicParams();
//        params.put("auth_token", generic.getAuthTockenFromDb());
//        params.put("election_id", String.valueOf(page));
//        params.put("elector_ids[]", "asc");
//        params.put("order_by", "date");
//        params.put("keyword", "");

        mArrayVotersId = new ArrayList<>();
        mArrayVotersId.clear();
        for (int i = 0; i < activitiesData.size(); i++) {
            if (activitiesData.get(i).getisselect()) {
                mArrayVotersId.add(activitiesData.get(i).getid());
            }
        }
        OkHttpClient client = generic.setHeaderForReqs().build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(AppWebServices.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();

        ApiService service = retrofit.create(ApiService.class);
//        Call<ElectorsResult> call = service.electorslist(params);

        Call<DefaultResult> call = service.vote_elector(generic.getAuthTockenFromDb(), election_id, mArrayVotersId,
                StaticStrings.DEVICE_TYPE.toString(), Build.MODEL, Build.VERSION.RELEASE);

        call.enqueue(new Callback<DefaultResult>() {

            @Override
            public void onResponse(Call<DefaultResult> call, retrofit2.Response<DefaultResult> response) {
                if (response.code() == 200) {

                    Boolean status = response.body().getstatus();
                    String Message = response.body().getMessage();

                    if (status) {
//                        generic.hideProgressBar(spinner);
//                        tv_noresult.setVisibility(View.GONE);
                        generic.showSnackbar(rl_body, Message, Snackbar.LENGTH_LONG, "close", true);

                        if (ntobj.isConnectingToInternet()) {
                            ll_two.setVisibility(View.GONE);
                            listView.setVisibility(View.GONE);
                            generic.showProgressBar(spinner);
                            tv_noresult.setVisibility(View.GONE);
                            objectBAJava.hideKeyboard();
                            reqIsInProgress = false;
                            page = 1;
                            total_records = 0;
                            activitiesData.clear();
                            generic.hideProgressBar(spinner1);
                            apiCallElectorsList();
                        } else {
                            String Messagee = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
                            generic.showSnackbar(rl_body, Messagee, Snackbar.LENGTH_LONG, "close", false);
                            tv_noresult.setVisibility(View.VISIBLE);
                            generic.hideProgressBar(spinner);
                            ll_two.setVisibility(View.GONE);
                            generic.hideProgressBar(spinner1);
                            listView.setVisibility(View.GONE);
                            page = 1;
                            total_records = 0;
                            reqIsInProgress = false;
                            activitiesData.clear();
                        }

                    } else {
                        generic.hideProgressBar(spinner);
                        Snackbar snackbar = Snackbar.make(ll_two, Message, Snackbar.LENGTH_LONG);
                        snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
                        snackbar.show();
                        adapter.notifyDataSetChanged();
                    }

                } else {
                    generic.hideProgressBar(spinner);
                    try {

                        String userMessage = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("oops", "هناك خطأ ما");
                        JSONObject jObjError = new JSONObject(response.errorBody().string());
                        try {
                            userMessage = jObjError.getString("message");
                        } catch (Exception e) {
                        }

                        String dataArrayMessage = "";
                        try {
                            JSONArray jsonArray = jObjError.getJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                dataArrayMessage = dataArrayMessage + jsonArray.getString(i) + "\n";
                            }

                        } catch (Exception e) {
                        }


                        String maintenanceBtnText = "Try Again";
                        try {
                            maintenanceBtnText = jObjError.optString("btn_text");
                        } catch (Exception e) {
                        }

                        generic.genericCodes(ll_two, response.code(), userMessage, dataArrayMessage, maintenanceBtnText);

                    } catch (Exception e) {

//                        spinner.setVisibility(View.GONE);
                        generic.hideProgressBar(spinner);
                        spinner1.setVisibility(View.GONE);
                        Snackbar snackbar = Snackbar.make(ll_two, PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("oops", "هناك خطأ ما"), Snackbar.LENGTH_LONG);
                        snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
                        snackbar.show();

                    }
                }
            }

            @Override
            public void onFailure(Call<DefaultResult> call, Throwable t) {
//                spinner.setVisibility(View.GONE);
                generic.hideProgressBar(spinner);
                spinner1.setVisibility(View.GONE);
                reqIsInProgress = false;

                Snackbar snackbar = Snackbar.make(ll_two, PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("oops", "هناك خطأ ما"), Snackbar.LENGTH_LONG);
                snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
                snackbar.show();
            }
        });
    }

    @Override

    public void onResume() {
        super.onResume();
        objectBAJava.hideKeyboard();
//        generic.hideProgressBar(spinner);
        generic.hideProgressBar(spinner1);

//        if (ntobj.isConnectingToInternet()) {
//            objectBAJava.hideKeyboard();
//            activitiesData.clear();
//            tv_noresult.setVisibility(View.GONE);
//            ll_two.setVisibility(View.GONE);
//            callApiFirsttime();
//        } else {
//            activitiesData.clear();
//            tv_noresult.setVisibility(View.VISIBLE);
//            ll_two.setVisibility(View.GONE);
//            String Message = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
//            generic.showSnackbar(rl_body, Message, Snackbar.LENGTH_LONG, "close", false);
//        }

        if (ISFROMREGISTERID) {
            if (ntobj.isConnectingToInternet()) {
                objectBAJava.hideKeyboard();
                activitiesData.clear();
                tv_noresult.setVisibility(View.GONE);
                ll_two.setVisibility(View.GONE);
                callApiFirsttime();
            } else {
                activitiesData.clear();
                tv_noresult.setVisibility(View.VISIBLE);
                ll_two.setVisibility(View.GONE);
                String Message = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
                generic.showSnackbar(rl_body, Message, Snackbar.LENGTH_LONG, "close", false);
            }
        }

    }

    public void firsttimeCall() {

//        if (ntobj.isConnectingToInternet()) {
//            objectBAJava.hideKeyboard();
//            activitiesData.clear();
//            tv_noresult.setVisibility(View.GONE);
//            ll_two.setVisibility(View.GONE);
//            callApiFirsttime();
//        } else {
//            activitiesData.clear();
//            tv_noresult.setVisibility(View.VISIBLE);
//            ll_two.setVisibility(View.GONE);
//            String Message = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
//            generic.showSnackbar(rl_body, Message, Snackbar.LENGTH_LONG, "close", false);
//        }

    }

    public void apiCallDeviceTocken() {
        Map<String, String> params = generic.setBasicParams();
        params.put("auth_token", generic.getAuthTockenFromDb());
        params.put("device_token", generic.getDeviceToken());
        OkHttpClient client = generic.setHeaderForReqs().build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(AppWebServices.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();

        ApiService service = retrofit.create(ApiService.class);
        Call<DefaultResult> call = service.update_device(params);
        call.enqueue(new Callback<DefaultResult>() {

            @Override
            public void onResponse(Call<DefaultResult> call, retrofit2.Response<DefaultResult> response) {
                if (response.code() == 200) {

                    Boolean status = response.body().getstatus();
                    String Message = response.body().getMessage();

                    if (status) {
                        PreferenceManager.getDefaultSharedPreferences(objectBAJava).edit().putBoolean("isDevicetockensend", true).apply();
                        System.out.println("Check device tocken start ef in api true");

//                        generic.hideProgressBar(spinner);
//                        generic.hideProgressBar(spinner1);
//                        ll_two.setVisibility(View.VISIBLE);
//                        listView.setVisibility(View.VISIBLE);
//                        tv_noresult.setVisibility(View.GONE);
//                        tv_question.setText(response.body().getdata().getelection().gettitle());
//                        election_id = response.body().getdata().getelection().getid();
//
//                        if (response.body().getdata().getelectors().size() > 0) {
//                            for (int i = 0; i < response.body().getdata().getelectors().size(); i++) {
//                                activitiesData.add(response.body().getdata().getelectors().get(i));
//                            }
//                        }
//
//                        if (response.body().getdata().getuser().getselected_elector_ids() != null) {
//                            if (response.body().getdata().getuser().getselected_elector_ids().size() > 0) {
//                                for (int i = 0; i < response.body().getdata().getuser().getselected_elector_ids().size(); i++) {
//
//                                    activitiesVoterData.add(response.body().getdata().getuser().getselected_elector_ids().get(i));
//                                }
//                            }
//                        }
//
//                        if (activitiesVoterData.size() > 0) {
//                            for (int i = 0; i < activitiesData.size(); i++) {
//
//                                for (int j = 0; j < activitiesVoterData.size(); j++) {
//
//                                    if (activitiesVoterData.get(j).equals(activitiesData.get(i).getid())) {
//                                        activitiesData.get(i).setisvoted(true);
//                                    }
//                                }
//                            }
//                        }
//                        if (response.body().getdata().getuser().getis_document_uploaded()) {
//                            if (response.body().getdata().getuser().getis_document_verified()) {
//                                if (!response.body().getdata().getuser().getis_already_voted()) {
//                                    if (response.body().getdata().getelection().getno_of_electors_select().equals("0")) {
//
//                                        ll_two.setVisibility(View.GONE);
//                                        tv_noresult.setVisibility(View.VISIBLE);
//                                        tv_noresult.setText("لا توجد انتخابات متاحة");
//
//                                    } else {
//
//                                        selectedlimit = Integer.parseInt(response.body().getdata().getelection().getno_of_electors_select());
//                                        boolean isselect = response.body().getdata().getuser().getis_already_voted();
//                                        if (activitiesData.size() == 0) {
//
//                                            ll_two.setVisibility(View.GONE);
//                                            generic.hideProgressBar(spinner);
//                                            spinner1.setVisibility(View.GONE);
//                                            tv_noresult.setVisibility(View.VISIBLE);
//                                            listView.setVisibility(View.GONE);
//                                            rl_submit.setVisibility(View.GONE);
//
//                                        } else {
//                                            adapter = new ElectorsLvAdapter(getActivity(), activitiesData, objElectorsFragment, isselect);
//                                            listView.setAdapter(adapter);
//                                            rl_submit.setVisibility(View.VISIBLE);
//                                            ll_two.setVisibility(View.VISIBLE);
//                                            listView.setVisibility(View.VISIBLE);
//                                            generic.hideProgressBar(spinner);
//                                            tv_noresult.setVisibility(View.GONE);
//                                        }
//                                    }
//
//                                } else // already cast vote
//                                {
//                                    // hide button and disable selection
//                                    boolean isselect = response.body().getdata().getuser().getis_already_voted();
//
//                                    if (activitiesData.size() == 0) {
//                                        generic.hideProgressBar(spinner);
//                                        spinner1.setVisibility(View.GONE);
//                                        tv_noresult.setVisibility(View.VISIBLE);
//                                        listView.setVisibility(View.GONE);
//                                        rl_submit.setVisibility(View.GONE);
//
//                                    } else {
//                                        ll_two.setVisibility(View.VISIBLE);
//                                        listView.setVisibility(View.VISIBLE);
//                                        generic.hideProgressBar(spinner);
//                                        tv_noresult.setVisibility(View.GONE);
//                                        rl_submit.setVisibility(View.GONE);
//                                        adapter = new ElectorsLvAdapter(getActivity(), activitiesData, objElectorsFragment, isselect);
//                                        listView.setAdapter(adapter);
//                                    }
//                                }
//                            } else // under review
//                            {
//                                ll_two.setVisibility(View.GONE);
//                                listView.setVisibility(View.GONE);
//                                tv_noresult.setVisibility(View.VISIBLE);
//                                tv_noresult.setText("المستند قيد المراجعة");
//                            }
//                        } else // upload document
//                        {
//                            Intent intent = new Intent(getActivity(), RegisterVoteActivity.class);
//                            startActivity(intent);
//                            getActivity().overridePendingTransition(R.anim.start_slide_in_left, R.anim.start_slide_out_left);
//                        }
//                        Snackbar snackbar = Snackbar.make(ll_two, Message, Snackbar.LENGTH_LONG);
//                        snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
//                        snackbar.show();

                    } else {
//                        generic.hideProgressBar(spinner);
//                        if (activitiesData.size() == 0) {
//                            tv_noresult.setVisibility(View.VISIBLE);
//                            listView.setVisibility(View.GONE);
//                        }

//                        Snackbar snackbar = Snackbar.make(ll_two, Message, Snackbar.LENGTH_LONG);
//                        snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
//                        snackbar.show();
                        System.out.println("Check device tocken start ef in api false");

                    }

//                } else {
//                    generic.hideProgressBar(spinner);
//                    try {
//
//                        if (activitiesData.size() == 0) {
//                            tv_noresult.setVisibility(View.VISIBLE);
//                            listView.setVisibility(View.GONE);
//                        }
//
////                        spinner.setVisibility(View.GONE);
//                        generic.hideProgressBar(spinner);
//                        spinner1.setVisibility(View.GONE);
//
//                        String userMessage = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("oops", "هناك خطأ ما");
//                        JSONObject jObjError = new JSONObject(response.errorBody().string());
//                        try {
//                            userMessage = jObjError.getString("message");
//                        } catch (Exception e) {
//                        }
//
//                        String dataArrayMessage = "";
//                        try {
//                            JSONArray jsonArray = jObjError.getJSONArray("data");
//                            for (int i = 0; i < jsonArray.length(); i++) {
//                                dataArrayMessage = dataArrayMessage + jsonArray.getString(i) + "\n";
//                            }
//
//                        } catch (Exception e) {
//                        }
//
//
//                        String maintenanceBtnText = "Try Again";
//                        try {
//                            maintenanceBtnText = jObjError.optString("btn_text");
//                        } catch (Exception e) {
//                        }
//
//                        generic.genericCodes(ll_two, response.code(), userMessage, dataArrayMessage, maintenanceBtnText);
//
//                    } catch (Exception e) {
//
////                        spinner.setVisibility(View.GONE);
//                        generic.hideProgressBar(spinner);
//                        spinner1.setVisibility(View.GONE);
//                        if (activitiesData.size() == 0) {
//                            tv_noresult.setVisibility(View.VISIBLE);
//                            listView.setVisibility(View.GONE);
//                        }
//
//                        Snackbar snackbar = Snackbar.make(ll_two, PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("oops", "هناك خطأ ما"), Snackbar.LENGTH_LONG);
//                        snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
//                        snackbar.show();
//
//                    }
//                }
                }
            }

            @Override
            public void onFailure(Call<DefaultResult> call, Throwable t) {
////                spinner.setVisibility(View.GONE);
//                generic.hideProgressBar(spinner);
//                spinner1.setVisibility(View.GONE);
//                reqIsInProgress = false;
//
//                Snackbar snackbar = Snackbar.make(ll_two, PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("oops", "هناك خطأ ما"), Snackbar.LENGTH_LONG);
//                snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
//                snackbar.show();
//
//                if (activitiesData.size() == 0) {
//                    tv_noresult.setVisibility(View.VISIBLE);
//                    listView.setVisibility(View.GONE);
//                }

                System.out.println("Check device tocken start ef in api exception");

            }
        });
    }

    public boolean allowBackPressed() {
        objectBAJava.hideKeyboard();
        generic.hideProgressBar(spinner);
        generic.hideProgressBar(spinner1);
        return true;
    }

    public void logoutconfirm() {

        AlertDialog alert = new AlertDialog.Builder(getActivity())
                .create();
        alert.setMessage("هل تريد بالتأكيد تسجيل الخروج؟");
        alert.setButton(DialogInterface.BUTTON_POSITIVE, "حسنا", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {

                dialog.dismiss();
                logout();

            }
        });
        alert.setButton(DialogInterface.BUTTON_NEGATIVE, "لا", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {

                dialog.dismiss();


            }
        });
        alert.show();
    }

    public void logout() {

        generic.showProgressBar(spinner);
        Map<String, String> params = generic.setBasicParams();
        params.put("auth_token", generic.getAuthTockenFromDb());
        params.put("all_devices", "0");

        OkHttpClient client = generic.setHeaderForReqs().build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(AppWebServices.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();
        ApiService service = retrofit.create(ApiService.class);
        Call<DefaultResult> call = service.logout(params);
        call.enqueue(new Callback<DefaultResult>() {
            @Override
            public void onResponse(Call<DefaultResult> call, retrofit2.Response<DefaultResult> response) {

                generic.hideProgressBar(spinner);

                if (response.code() == 200) {

                    String message = response.body().getMessage();
                    Boolean status = response.body().getstatus();

                    if (status) {

                        PreferenceManager.getDefaultSharedPreferences(getActivity()).edit().putBoolean("firstTimeLogin", false).apply();
                        PreferenceManager.getDefaultSharedPreferences(getActivity()).edit().putBoolean("servicesstatus", false).apply();
                        getActivity().finish();
                        generic.finishAllActivities();
                        Intent g = new Intent(getActivity(), SigninActivity.class);
                        g.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(g);
                        // Clear all notification that received from FCM notifications bcz when app open then all notifications should be gone
//                        NotificationManager nMgr = (NotificationManager) getActivity().getSystemService(Context.NOTIFICATION_SERVICE);
//                        nMgr.cancelAll();
                        getActivity().overridePendingTransition(R.anim.start_slide_in_left, R.anim.start_slide_out_left);
                        generic.deleteUserinfo();

                    } else {

                        generic.showSnackbar(spinner, message, Snackbar.LENGTH_LONG, "close", false);

                    }
                } else {

                    try {

                        String userMessage = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("oops", "هناك خطأ ما");
                        JSONObject jObjError = new JSONObject(response.errorBody().string());
                        try {
                            userMessage = jObjError.getString("message");
                        } catch (Exception e) {
                        }

                        String dataArrayMessage = "";
                        try {
                            JSONArray jsonArray = jObjError.getJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                dataArrayMessage = dataArrayMessage + jsonArray.getString(i) + "\n";
                            }

                        } catch (Exception e) {
                        }

                        String maintenanceBtnText = "Try Again";
                        try {
                            maintenanceBtnText = jObjError.optString("btn_text");
                        } catch (Exception e) {
                        }
                        generic.genericCodes(spinner, response.code(), userMessage, dataArrayMessage, maintenanceBtnText);
                    } catch (Exception e) {

                        generic.showSnackbar(spinner, "هناك خطأ ما", Snackbar.LENGTH_LONG, "close", false);

                    }


                }
            }

            @Override
            public void onFailure(Call<DefaultResult> call, Throwable t) {

                generic.hideProgressBar(spinner);
                generic.showSnackbar(spinner, "هناك خطأ ما", Snackbar.LENGTH_LONG, "close", false);

            }
        });
    }

//    public void velidation() {
//        selectedcount = 0;
//        for (int i = 0; i < activitiesData.size(); i++) {
//            if (activitiesData.get(i).getisselect()) {
//                selectedcount = selectedcount + 1;
//            }
//        }
//        if (selectedcount <= 0) {
////            generic.showSnackbar(ll_two, "you are allow to select only" + selectedlimit + " electors", Snackbar.LENGTH_LONG, "close", false);
//            generic.showSnackbar(rl_body, " عليك إختيار " + selectedlimit + " مرشح ", Snackbar.LENGTH_LONG, "close", false);
//
////            generic.showSnackbar(ll_two, "Select at least one", Snackbar.LENGTH_LONG, "close", false);
//
//        } else if (selectedcount <= selectedlimit) {
//
//            if (ntobj.isConnectingToInternet()) {
//                tv_noresult.setVisibility(View.GONE);
//                objectBAJava.hideKeyboard();
//
////                generic.showProgressBar(spinner);
//
//                voteConfirm();
//
//            } else {
//                String Message = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
//                generic.showSnackbar(rl_body, Message, Snackbar.LENGTH_LONG, "close", false);
//            }
//
//        } else {
//            generic.showSnackbar(rl_body, " يسمح بإختيار " + selectedlimit + " مرشح فقط ", Snackbar.LENGTH_LONG, "close", false);
//
////            generic.showSnackbar(ll_two, "you are allow to select only" + selectedlimit + " electors", Snackbar.LENGTH_LONG, "close", false);
//        }
//    }

}
