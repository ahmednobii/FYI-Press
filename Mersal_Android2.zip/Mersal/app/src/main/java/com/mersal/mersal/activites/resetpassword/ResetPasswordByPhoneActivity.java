package com.mersal.mersal.activites.resetpassword;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.mersal.mersal.R;
import com.mersal.mersal.activites.base.BaseActivity;
import com.mersal.mersal.customviews.HeaderCustomTV;
import com.mersal.mersal.customviews.NoDataFoundCustomTV;
import com.mersal.mersal.generic.Interfaces.Generic;
import com.mersal.mersal.internetconnections.NetworkConnection;
import com.mersal.mersal.retrofit.baseapi.ApiService;
import com.mersal.mersal.retrofit.baseapi.AppWebServices;
import com.mersal.mersal.retrofit.defualt.DefaultResult;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Map;

import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ResetPasswordByPhoneActivity extends BaseActivity {

    TextView tv_submit;
    RelativeLayout rl_submit, rl_body, header_left_rl;
    String st_email = "", st_pwd = "", st_code = "";
    EditText et_email, et_pwd, et_code;
    ProgressBar progressBar;
    NoDataFoundCustomTV tv_noresult;
    public static ResetPasswordByPhoneActivity objResetPasswordActivity;
    NetworkConnection ntobj = new NetworkConnection(ResetPasswordByPhoneActivity.this);
    Generic generic;
    ImageView back_arrow;
    HeaderCustomTV toolbar_title;
    String otp_code;
    ImageView imgShowPassword1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_passwordbyphone);
        if (ResetPasswordByPhoneActivity.this instanceof BaseActivity) {
            generic = (Generic) ResetPasswordByPhoneActivity.this;
        }
        Intent intent = getIntent();
        if (intent.hasExtra("code")) {
            otp_code = intent.getStringExtra("code");
        }
        generic.hideStatusBarForAuth();
        objResetPasswordActivity = this;

        init();
        clickListener();
        objectBAJava.hideKeyboard();
    }

    public boolean containAlphanumeric(final String str) {
        byte counter = 0;
        boolean checkdigit = false, checkchar = false;
        for (int i = 0; i < str.length() && counter < 2; i++) {
            // If we find a non-digit character we return false.
            if (!checkdigit && Character.isDigit(str.charAt(i))) {
                checkdigit = true;
                counter++;
            }
            String a = String.valueOf(str.charAt(i));
            if (!checkchar && a.matches("[a-zA-Z]*")) {
                checkchar = true;
                counter++;
            }
        }
        if (checkdigit && checkchar) {
            return true;
        }
        return false;
    }

    public void init() {
        header_left_rl = (RelativeLayout) findViewById(R.id.header_left_rl);
        tv_submit = (TextView) findViewById(R.id.tv_submit);
        rl_submit = (RelativeLayout) findViewById(R.id.rl_submit);
        rl_body = (RelativeLayout) findViewById(R.id.rl_body);
        et_email = (EditText) findViewById(R.id.et_email);
        et_email.setTypeface(objectBAJava.Tahoma_Regular_font);
        et_pwd = (EditText) findViewById(R.id.et_pwd);
        et_pwd.setTypeface(objectBAJava.Tahoma_Regular_font);
        et_code = (EditText) findViewById(R.id.et_code);
        et_code.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_submit.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_noresult = (NoDataFoundCustomTV) findViewById(R.id.tv_noresult);
        imgShowPassword1 = findViewById(R.id.show_pass_btn1);
        toolbar_title = (HeaderCustomTV) findViewById(R.id.toolbar_title);
        back_arrow = (ImageView) findViewById(R.id.back_arrow);
        toolbar_title.setText("إعادة تعين كلمة المرور");
        back_arrow.setVisibility(View.VISIBLE);

        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        progressBar.setVisibility(View.GONE);

        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT) {
            progressBar.getIndeterminateDrawable().setColorFilter(getResources()
                    .getColor(R.color.progress_bar_color_white), PorterDuff.Mode.SRC_IN);
        }
    }

    public void clickListener() {
        rl_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                velidation();
            }
        });
        header_left_rl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                objectBAJava.hideStatusBar();
                finish();
                generic.animEnd();
            }
        });

        imgShowPassword1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if( et_pwd.getTransformationMethod().equals(PasswordTransformationMethod.getInstance())){
                    et_pwd.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    imgShowPassword1.setImageResource(R.drawable.password_show);
                }
                else {
                    et_pwd.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    imgShowPassword1.setImageResource(R.drawable.password_hide);
                }
            }
        });
    }

    public void velidation() {
        st_email = et_email.getText().toString();
        st_pwd = et_pwd.getText().toString();
        st_code = et_code.getText().toString();

        if (st_email.trim().equals("")) {
            et_email.requestFocus();
            et_email.setError("البريد الإلكتروني مطلوب");
        }
         else if (st_pwd.trim().equals("")) {
            et_pwd.requestFocus();
            et_pwd.setError("كلمه المرور مطلوب");
        }
        else if (st_pwd.trim().length() < 6) {
            et_pwd.requestFocus();
            et_pwd.setError("كلمة المرور يجب أن تتكون من ٦ رموز على الأقل");
        }
        else if(!containAlphanumeric(st_pwd.trim())){
            et_pwd.requestFocus();
            et_pwd.setError("كلمة المرور يجب أن تتكون من حروف و أرقام");
        }
        else if (st_code.trim().equals("")) {
            et_email.requestFocus();
            et_email.setError("الرمز مطلوب");
        } else {
            if (ntobj.isConnectingToInternet()) {
                objectBAJava.hideKeyboard();
                callApiFirsttime();

            } else {
                String Message = PreferenceManager.getDefaultSharedPreferences(ResetPasswordByPhoneActivity.this).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
                generic.showSnackbar(rl_body, Message, Snackbar.LENGTH_LONG, "close", false);
            }
        }

    }

    public void apiResetPasswords() {
//
//        reqIsInProgress = true;
        generic.showProgressBar(progressBar);
        Map<String, String> params = generic.setBasicParams();
        params.put("phone", st_email);
        params.put("password", st_pwd);
        params.put("code", st_code);
        params.put("c_password", st_pwd);


        OkHttpClient client = generic.setHeaderForReqs().build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(AppWebServices.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();

        ApiService service = retrofit.create(ApiService.class);
        Call<DefaultResult> call = service.resetpasswordbyphone(params);
        call.enqueue(new Callback<DefaultResult>() {

            @Override
            public void onResponse(Call<DefaultResult> call, retrofit2.Response<DefaultResult> response) {

                if (response.code() == 200) {

                    Boolean status = response.body().getstatus();
                    String Message = response.body().getMessage();

                    if (status) {

                        generic.hideProgressBar(progressBar);
                        AlertDialog alert = new AlertDialog.Builder(ResetPasswordByPhoneActivity.this)
                                .create();
                        alert.setMessage(Message);
                        alert.setButton(DialogInterface.BUTTON_POSITIVE, "موافق", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {

                                dialog.dismiss();

                                finish();
                                animEnd();
                            }
                        });
                        alert.setButton(DialogInterface.BUTTON_NEGATIVE, "الغاء", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {

                                dialog.dismiss();
                                finish();
                                animEnd();
                            }
                        });
                        alert.show();

                    } else {
                        generic.hideProgressBar(progressBar);

//                        tv_noresult.setVisibility(View.VISIBLE);
//                        rl_body.setVisibility(View.GONE);
                        Snackbar snackbar = Snackbar.make(rl_body, Message, Snackbar.LENGTH_LONG);
                        snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
                        snackbar.show();
                    }

                } else {
                    generic.hideProgressBar(progressBar);
                    try {

//                        progressBar.setVisibility(View.GONE);
                        generic.hideProgressBar(progressBar);

                        String userMessage = PreferenceManager.getDefaultSharedPreferences(ResetPasswordByPhoneActivity.this).getString("oops", "هناك خطأ ما");
                        JSONObject jObjError = new JSONObject(response.errorBody().string());
                        try {
                            userMessage = jObjError.getString("message");
                        } catch (Exception e) {
                        }

                        String dataArrayMessage = "";
                        try {
                            JSONArray jsonArray = jObjError.getJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                dataArrayMessage = dataArrayMessage + jsonArray.getString(i) + "\n";
                            }

                        } catch (Exception e) {
                        }


                        String maintenanceBtnText = "Try Again";
                        try {
                            maintenanceBtnText = jObjError.optString("btn_text");
                        } catch (Exception e) {
                        }

                        generic.genericCodes(rl_body, response.code(), userMessage, dataArrayMessage, maintenanceBtnText);

                    } catch (Exception e) {

//                        progressBar.setVisibility(View.GONE);
                        generic.hideProgressBar(progressBar);

                        rl_body.setVisibility(View.GONE);

                        Snackbar snackbar = Snackbar.make(rl_body, PreferenceManager.getDefaultSharedPreferences(ResetPasswordByPhoneActivity.this).getString("oops", "هناك خطأ ما"), Snackbar.LENGTH_LONG);
                        snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
                        snackbar.show();

                    }
                }
            }

            @Override
            public void onFailure(Call<DefaultResult> call, Throwable t) {
//                progressBar.setVisibility(View.GONE);
                generic.hideProgressBar(progressBar);

                Snackbar snackbar = Snackbar.make(rl_body, PreferenceManager.getDefaultSharedPreferences(ResetPasswordByPhoneActivity.this).getString("oops", "هناك خطأ ما"), Snackbar.LENGTH_LONG);
                snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
                snackbar.show();

            }
        });
    }

    public void callApiFirsttime() {

        if (ntobj.isConnectingToInternet()) {
//            rl_body.setVisibility(View.GONE);
            objectBAJava.hideKeyboard();
            generic.showProgressBar(progressBar);
            if(otp_code.compareTo(st_code)!= 0)
            {
                generic.hideProgressBar(progressBar);
                Snackbar snackbar = Snackbar.make(rl_body, PreferenceManager.getDefaultSharedPreferences(ResetPasswordByPhoneActivity.this).getString("oops", "هناك خطأ في الرمز"), Snackbar.LENGTH_LONG);
                snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
                snackbar.show();
            }
            else
                apiResetPasswords();
        } else {
            String Message = PreferenceManager.getDefaultSharedPreferences(ResetPasswordByPhoneActivity.this).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
            generic.showSnackbar(tv_noresult, Message, Snackbar.LENGTH_LONG, "close", false);

            generic.hideProgressBar(progressBar);
        }
    }
}
