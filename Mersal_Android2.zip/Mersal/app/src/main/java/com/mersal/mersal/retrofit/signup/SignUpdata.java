package com.mersal.mersal.retrofit.signup;

/**
 * Created by Muhammad_Umar_Ch on 07/12/2017.
 */

public class SignUpdata {

//    private String user_id = "";
//    private String user_name = "";
//    private String auth_token = "";
//    private String document_status = "";
//
//    public String getdocument_status() {
//        if (document_status == null ) {
//            return "";
//        }
//        return document_status;
//    }
//
//    public String getuser_id() {
//        if (user_id == null ) {
//            return "";
//        }
//        return user_id;
//    }
//
//    public String getuser_name() {
//        if (user_name == null ) {
//            return "";
//        }
//        return user_name;
//    }
//
//
//    public String getauth_token() {
//        if (auth_token == null ) {
//            return "";
//        }
//        return auth_token;
//    }


    private String user_id = "";
    private String user_name = "";
    private String email = "";
    private String auth_token = "";
    private String phone = "";
    private String dob = "";
    private String gender = "";
    private String address = "";
    private boolean is_vendor = false;

    private String document_status = "";

    public String getdocument_status() {
        if (document_status == null ) {
            return "";
        }
        return document_status;
    }
    private boolean add_services = false;

    public boolean getadd_services() {

        return add_services;
    }

    public boolean getisvendor() {

        return is_vendor;
    }

    public String getdob() {
        if (dob == null ) {
            return "";
        }
        return dob;
    }

    public String getgender() {
        if (gender == null ) {
            return "";
        }
        return gender;
    }

    public String getaddress() {
        if (address == null ) {
            return "";
        }
        return address;
    }

    public String getuser_id() {
        if (user_id == null ) {
            return "";
        }
        return user_id;
    }

    public String getuser_name() {
        if (user_name == null ) {
            return "";
        }
        return user_name;
    }

    public String getEmail() {
        if (email == null) {
            return "";
        }

        return email;
    }

    public String getauth_token() {
        if (auth_token == null ) {
            return "";
        }
        return auth_token;
    }

    public String getphoneNumber() {
        if (phone == null ) {
            return "";
        }
        return phone;
    }



}