package com.mersal.mersal.retrofit.general;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;


public class CitiesResult {
    @SerializedName("status")
    private Boolean status = false;

    @SerializedName("message")
    private String message = "";

    @SerializedName("data")
    private ArrayList<Citiesdata> data;

    public Boolean getstatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public ArrayList<Citiesdata> getdata() {
        return data;
    }


}