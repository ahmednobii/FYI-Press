package com.mersal.mersal.retrofit.electors;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Muhammad_Umar_Ch on 07/12/2017.
 */

public class Electorsdataelection {

    @SerializedName("short_description")
    private String short_description = "";
    @SerializedName("id")
    private String id = "";
    @SerializedName("title")
    private String title = "";
    @SerializedName("date")
    private String date = "";
    @SerializedName("no_of_electors_select")
    private String no_of_electors_select;
    @SerializedName("end_date")
    private String end_date = "";
    @SerializedName("end_time")
    private String end_time= "";

    public String getend_date() {
        if (end_date == null) {
            return "";
        }
        return end_date;
    }

    public String getend_time() {
        if (end_time == null) {
            return "";
        }
        return end_time;
    }

    public String getshort_description() {
        if (short_description == null) {
            return "";
        }
        return short_description;
    }

    public String getid() {

        if (id == null) {
            return "";
        }
        return id;
    }

    public String gettitle() {
        if (title == null) {
            return "";
        }
        return title;
    }

    public String getdate() {
        if (date == null) {
            return "";
        }
        return date;
    }

    public String getno_of_electors_select() {
        if (no_of_electors_select == null) {
            return "";
        }
        return no_of_electors_select;
    }

}
