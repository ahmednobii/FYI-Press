package com.mersal.mersal.activites.dashboard;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.graphics.PorterDuff;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

import com.mersal.mersal.R;
import com.mersal.mersal.activites.base.BaseActivity;
import com.mersal.mersal.activites.changepassword.ChangePasswordActivity;
import com.mersal.mersal.customviews.HeaderCustomTV;
import com.mersal.mersal.customviews.NoDataFoundCustomTV;
import com.mersal.mersal.fcm.MyFirebaseMessagingService;
import com.mersal.mersal.fragment.ElectorsFragment;
import com.mersal.mersal.fragment.InvitationsFragment;
import com.mersal.mersal.fragment.ProfileFragment;
import com.mersal.mersal.generic.Interfaces.Generic;
import com.mersal.mersal.internetconnections.NetworkConnection;

import static com.mersal.mersal.utilties.StaticStrings.ISFROMREGISTERID;
import static com.mersal.mersal.utilties.StaticStrings.IsFirstTIMEINAPP;
import static com.mersal.mersal.utilties.StaticStrings.TYPE;

public class DashboardActivity extends BaseActivity {

    ProgressBar progressBar;
    NoDataFoundCustomTV tv_noresult;
    public static DashboardActivity dashboardActivityObject;
    NetworkConnection ntobj = new NetworkConnection(DashboardActivity.this);
    Generic generic;
    ImageView back_arrow;
    RelativeLayout header_left_rl;
    FrameLayout rootLayout;
    public HeaderCustomTV toolbar_title;
    String title = "", message = "", isnotify = "no", type = "";
    boolean isgoingtoElec = false;
    BottomNavigationView bottomNavigationView;
    boolean doubleBackToExitPressedOnce = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);


        if (DashboardActivity.this instanceof BaseActivity) {
            generic = (Generic) DashboardActivity.this;
        }

        dashboardActivityObject = this;
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            title = extras.getString("title");
            message = extras.getString("message");
            isnotify = "yes";
            type = extras.getString("type");
            TYPE = type;

        }
        init();
        clickListener();
        objectBAJava.hideKeyboard();
    }

    public void init() {
        tv_noresult = (NoDataFoundCustomTV) findViewById(R.id.tv_noresult);
        ISFROMREGISTERID = false;
        toolbar_title = (HeaderCustomTV) findViewById(R.id.toolbar_title);
        back_arrow = (ImageView) findViewById(R.id.back_arrow);
        header_left_rl = (RelativeLayout) findViewById(R.id.header_left_rl);
//        toolbar_title.setText("Voting");
        back_arrow.setVisibility(View.GONE);
        rootLayout = (FrameLayout) findViewById(R.id.rootLayout);

        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        progressBar.setVisibility(View.GONE);
        bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottom_navigation);

        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT) {
            progressBar.getIndeterminateDrawable().setColorFilter(getResources()
                    .getColor(R.color.progress_bar_color_white), PorterDuff.Mode.SRC_IN);
        }
        if (isnotify.equals("yes")) {
            setupNavigationView(1);
        } else {
//            setupNavigationView(2);
            IsFirstTIMEINAPP = true;
            setupNavigationView(0);
        }
    }

    public void clickListener() {
        back_arrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                objectBAJava.hideStatusBar();
                finish();
                objectBAJava.finishAllActivities();
//                generic.animEnd();

            }
        });

    }

    public void setupNavigationView(int index) {
        if (bottomNavigationView != null) {

            // Select first menu item by default and show Fragment accordingly.
            Menu menu = bottomNavigationView.getMenu();
            selectFragment(menu.getItem(index));

            // Set action to perform when any menu-item is selected.
            bottomNavigationView.setOnNavigationItemSelectedListener(
                    new BottomNavigationView.OnNavigationItemSelectedListener() {
                        @Override
                        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                            selectFragment(item);
                            return false;
                        }
                    });
        }
    }

    protected void selectFragment(MenuItem item) {
        item.setChecked(true);
        switch (item.getItemId()) {
            case R.id.action_voting:
                isgoingtoElec = true;
//                pushFragment(new VotingFragment());
                callV4Fragment(new ElectorsFragment());

//                toolbar_title.setText(R.string.bottom_voting);
                break;
            case R.id.action_notifications:
                isgoingtoElec = false;
                toolbar_title.setText(R.string.bottom_notify);
                callV4Fragment(new InvitationsFragment());
                break;
            case R.id.action_profile:
                isgoingtoElec = false;
                toolbar_title.setText(R.string.bottom_profile);
                callV4Fragment(new ProfileFragment());
                break;
        }
    }

    protected void pushFragment(Fragment fragment) {
        if (fragment == null)
            return;

        FragmentManager fragmentManager = getFragmentManager();
        if (fragmentManager != null) {
            FragmentTransaction ft = fragmentManager.beginTransaction();
            if (ft != null) {
                ft.replace(R.id.rootLayout, fragment);
                ft.commit();
            }
        }
    }

    public void callV4Fragment(android.support.v4.app.Fragment fragment) {
        android.support.v4.app.FragmentManager fragmentManager13 = getSupportFragmentManager();
        android.support.v4.app.FragmentTransaction fragmentTransaction13 = fragmentManager13.beginTransaction();
        if (isgoingtoElec) {
            fragmentTransaction13.replace(R.id.rootLayout, fragment, "TAG_FRAGMENT");
            fragmentTransaction13.addToBackStack(null);
        } else {
            fragmentTransaction13.replace(R.id.rootLayout, fragment, "");
        }
        fragmentTransaction13.commitAllowingStateLoss();
    }

    public void hideViewFromElectorFragment() {
        bottomNavigationView.setVisibility(View.GONE);
//        header_left_rl.setVisibility(View.VISIBLE);
//        back_arrow.setVisibility(View.VISIBLE);
    }
    public void showViewFromElectorFragment() {
        bottomNavigationView.setVisibility(View.VISIBLE);
//        header_left_rl.setVisibility(View.VISIBLE);
//        header_left_rl.setVisibility(View.GONE);
//        back_arrow.setVisibility(View.GONE);
    }
    public void showheader_left_rlFromElectorFragment() {
        header_left_rl.setVisibility(View.VISIBLE);
        back_arrow.setVisibility(View.VISIBLE);

    }
    public void hideheader_left_rlFromElectorFragment() {

        header_left_rl.setVisibility(View.GONE);
        back_arrow.setVisibility(View.GONE);
    }



    public void setTitleText(String title) {
        toolbar_title.setText(title);

    }


    @Override
    public void onBackPressed() {
        hideKeyboard();
//        if (doubleBackToExitPressedOnce) {
        dashboardActivityObject.finish();
        super.onBackPressed();
        return;
//        }
//        doubleBackToExitPressedOnce = true;
        //  Toast.makeText(this, PreferenceManager.getDefaultSharedPreferences(DashboardActivity.this).getString("press_again", "Press again to exist"), Toast.LENGTH_SHORT).show();

//        new Handler().postDelayed(new Runnable() {
//
//            @Override
//            public void run() {
//                doubleBackToExitPressedOnce = false;
//            }
//        }, 2000);
    }
}