package com.mersal.mersal.retrofit.defualt;

import com.google.gson.annotations.SerializedName;


public class DefaultResult {
    @SerializedName("status")
    private Boolean status = false;

    @SerializedName("message")
    private String message = "";

    public Boolean getstatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

}

