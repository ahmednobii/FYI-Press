package com.mersal.mersal.retrofit.notifications;

import com.google.gson.annotations.SerializedName;
import com.mersal.mersal.retrofit.invitations.InvitationsDataInvitations;
import com.mersal.mersal.retrofit.invitations.invitationsServices;

import java.util.ArrayList;

/**
 * Created by Muhammad_Umar_Ch on 07/12/2017.
 */

public class Notificationsdata {

    @SerializedName("notifications")
    private ArrayList<NotificationsDatanotifications> notifications;

    public ArrayList<NotificationsDatanotifications> getnotifications() {
        return notifications;
    }

    @SerializedName("services")
    private ArrayList<invitationsServices> services;

    public ArrayList<invitationsServices> getservices() {
        return services;
    }


}
