package com.mersal.mersal.fragment;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.mersal.mersal.R;
import com.mersal.mersal.activites.auth.FeaturesActivity;
import com.mersal.mersal.activites.base.BaseActivity;
import com.mersal.mersal.activites.showworkpicture.ShowWorkPictureActivity;
import com.mersal.mersal.adapter.FeaturesLvAdapter;
import com.mersal.mersal.adapter.InvitationsLvAdapter;
import com.mersal.mersal.customviews.NoDataFoundCustomTV;
import com.mersal.mersal.generic.Interfaces.Generic;
import com.mersal.mersal.internetconnections.NetworkConnection;
import com.mersal.mersal.retrofit.baseapi.ApiService;
import com.mersal.mersal.retrofit.baseapi.AppWebServices;
import com.mersal.mersal.retrofit.defualt.DefaultResult;
import com.mersal.mersal.retrofit.invitations.InvitationsDataInvitations;
import com.mersal.mersal.retrofit.invitations.InvitationsResult;
import com.mersal.mersal.retrofit.invitations.invitationsServices;
import com.mersal.mersal.retrofit.notifications.NotificatiionsResult;
import com.mersal.mersal.retrofit.notifications.NotificationsDatanotifications;
import com.mersal.mersal.retrofit.services.ServicesResult;
import com.mersal.mersal.retrofit.services.ServicesdataServices;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Map;

import de.mrapp.android.dialog.MaterialDialog;
import info.hoang8f.android.segmented.SegmentedGroup;
import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static com.mersal.mersal.activites.base.BaseActivity.objectBAJava;
import static com.mersal.mersal.utilties.StaticStrings.TYPE;

public class InvitationsFragment extends Fragment {

    TextView tv_services, tv_services_title;
    ListView listView;
    ProgressBar spinner;
    Generic generic;
    InvitationsLvAdapter adapter;
    String fromPrevId = "", election_id = "";
    ArrayList<InvitationsDataInvitations> invitationsactivitiesData = new ArrayList<>();
    ArrayList<NotificationsDatanotifications> notificationactivitiesData = new ArrayList<>();
    public static InvitationsFragment objInvitationsFragment;
    NetworkConnection ntobj;
    NoDataFoundCustomTV tv_noresult;
    RelativeLayout ll_two, rl_body, rl_segmented2, r1_two_blood_tv;
    ArrayList<invitationsServices> activitiesDataServices = new ArrayList<>();
    private String[] Services_name = new String[0];
    ArrayList<String> Services_names = new ArrayList<String>();
    ArrayList<String> Services_Code = new ArrayList<String>();
    int ServicesPositionClicked = 0;
    String ServicesCode = "", Services = "";
    boolean isNotificationsTab = true;
    SegmentedGroup segmentedGroup;
    RadioButton rb_messages, rb_invit;
    boolean ifChangetab = false;
    boolean isFirstTimeCall = true;
    View rootViewNew;
    Handler handlerMessages = new Handler();
    Handler handlerInvitations = new Handler();
    boolean isRunhandlerMessages = false;
    boolean isRunhandlerInvitations = false;
    boolean isInvitationRequsting = false;
    boolean isMessagesRequsting = false;
    boolean isMessagesLastNeed = true;
    boolean isInvitationsLasthNeed = true;
    int scrolly;
    public ArrayList<ServicesdataServices> arrayListEditProfileServices = new ArrayList<>();


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_invitations, container, false);
        rootViewNew = rootView;
        objInvitationsFragment = this;
        if (getActivity() instanceof BaseActivity) {
            generic = (Generic) getActivity();
        }
        init(rootView);
        clickListener();
        generic.hideStatusBar();
        return rootView;
    }

    public void init(View rootView) {
        segmentedGroup = (SegmentedGroup) rootView.findViewById(R.id.segmentedGroup);
        segmentedGroup.setTintColor(getResources().getColor(R.color.header_color));
        rl_segmented2 = (RelativeLayout) rootView.findViewById(R.id.rl_segmented2);
        ntobj = new NetworkConnection(getActivity());
        listView = (ListView) rootView.findViewById(R.id.lv_propsel);
        tv_services = (TextView) rootView.findViewById(R.id.tv_services);
        tv_services_title = (TextView) rootView.findViewById(R.id.tv_services_title);
        ll_two = (RelativeLayout) rootView.findViewById(R.id.ll_two);
        rl_body = (RelativeLayout) rootView.findViewById(R.id.rl_body);
        r1_two_blood_tv = (RelativeLayout) rootView.findViewById(R.id.r1_two_blood_tv);
        tv_services.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_noresult = (NoDataFoundCustomTV) rootView.findViewById(R.id.tv_noresult);
        spinner = (ProgressBar) rootView.findViewById(R.id.progressBar);
        tv_services.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_services_title.setTypeface(objectBAJava.Tahoma_Regular_font);
        spinner.setVisibility(View.GONE);
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT) {
            spinner.getIndeterminateDrawable().setColorFilter(getResources()
                    .getColor(R.color.progress_bar_color_white), PorterDuff.Mode.SRC_IN);
        }

        rb_messages = (RadioButton) rootView.findViewById(R.id.rb_messages);
        rb_messages.setTypeface(objectBAJava.Tahoma_Regular_font);
        rb_invit = (RadioButton) rootView.findViewById(R.id.rb_invit);
        rb_invit.setTypeface(objectBAJava.Tahoma_Regular_font);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


        if (TYPE.equals("invitation")) {
            isNotificationsTab = false;
            ifChangetab = true;
            rb_invit.performClick();
//            callapiCallInvitationsList();
        } else {
            rb_messages.performClick();
            isNotificationsTab = true;
            ifChangetab = true;
//            callapiCallNotificationsList();
        }

        boolean isDeviceTockenSend = PreferenceManager.getDefaultSharedPreferences(objectBAJava).getBoolean("isDevicetockensend", false);
        System.out.println("Check device tocken start inv " + isDeviceTockenSend);

        if (!isDeviceTockenSend) {
            if (ntobj.isConnectingToInternet()) {
                objectBAJava.hideKeyboard();
                apiCallDeviceTocken();
            } else {
//                String Message = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
//                generic.showSnackbar(rl_body, Message, Snackbar.LENGTH_LONG, "close", false);
            }
        }
    }

    public void clickListener() {
        tv_services.setText("الكل");

        listView.setOnScrollListener(new AbsListView.OnScrollListener() {

            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                // TODO Auto-generated method stub

            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem,
                                 int visibleItemCount, int totalItemCount) {
                scrolly = firstVisibleItem;

            }
        });

        rb_invit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tv_services.setText("الكل");
                isNotificationsTab = false;
                ifChangetab = true;
                pauseRefreshInvitations();
                pauseRefreshMessages();
                callapiCallInvitationsList();
            }
        });
        rb_messages.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tv_services.setText("الكل");

                isNotificationsTab = true;
                ifChangetab = true;
                pauseRefreshInvitations();
                pauseRefreshMessages();
                callapiCallNotificationsList();
            }
        });

        r1_two_blood_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ntobj.isConnectingToInternet()) {
                    generic.showProgressBar(spinner);
                    if (arrayListEditProfileServices.size() == 0) {
                        if (isNotificationsTab) {
//                            callapiCallNotificationsList();
                            apiGetServices();
                        } else {
//                            callapiCallInvitationsList();
                            apiGetServices();

                        }
                    } else {
                        String cancel = "لا";
                        String ok = "حسنا";
                        MaterialDialog.Builder builder = new MaterialDialog.Builder(getActivity());
                        Services_name = Services_names.toArray(new String[Services_names.size()]);
                        builder.setNegativeButton(cancel, citycreateNegativeButtonListener());
//                        builder.setPositiveButton(ok, citycreatePositiveButtonListener());
                        builder.setSingleChoiceItems(Services_name, ServicesPositionClicked, citycreateSingleChoiceListener());
                        builder.create();
                        builder.show();
                        generic.hideProgressBar(spinner);

                    }

                } else {

                    String OK = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("ok", "موافق");
                    AlertDialog alert = new AlertDialog.Builder(getActivity())
                            .create();
                    alert.setMessage(PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى"));
                    alert.setButton(DialogInterface.BUTTON_POSITIVE, OK, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
                    alert.show();

                }

            }
        });

    }

    public void apiCallInvitationsList(String service_id) {
        tv_noresult.setVisibility(View.GONE);
        activitiesDataServices.clear();
        isFirstTimeCall = false;

//        generic.showProgressBar(spinner);
        Map<String, String> params = generic.setBasicParams();
        params.put("auth_token", generic.getAuthTockenFromDb());
        params.put("service_id", service_id);
        OkHttpClient client = generic.setHeaderForReqs().build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(AppWebServices.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();

        ApiService service = retrofit.create(ApiService.class);
        Call<InvitationsResult> call = service.invitation(params);
        call.enqueue(new Callback<InvitationsResult>() {

            @Override
            public void onResponse(Call<InvitationsResult> call, retrofit2.Response<InvitationsResult> response) {
                if (response.code() == 200) {
                    isInvitationRequsting = false;
                    Boolean status = response.body().getstatus();
                    String Message = response.body().getMessage();

                    if (status) {
                        generic.hideProgressBar(spinner);
                        ll_two.setVisibility(View.VISIBLE);
                        listView.setVisibility(View.VISIBLE);
                        tv_noresult.setVisibility(View.GONE);

                        if (response.body().getdata().getinvitations().size() > 0) {
                            for (int i = 0; i < response.body().getdata().getinvitations().size(); i++) {
                                invitationsactivitiesData.add(response.body().getdata().getinvitations().get(i));
                            }
                        }

////                        services start
//                        if (activitiesDataServices.size() <= 0) {
//                            activitiesDataServices.clear();
//                            if (response.body().getdata().getservices() != null) {
//                                if (response.body().getdata().getservices().size() > 0) {
//                                    for (int i = 0; i < response.body().getdata().getservices().size(); i++) {
//                                        activitiesDataServices.add(response.body().getdata().getservices().get(i));
//                                    }
//                                }
//                            }
//                            Services_name = new String[0];
//                            Services_names = new ArrayList<String>();
//                            Services_Code = new ArrayList<String>();
//                            for (int i = 0; i <= activitiesDataServices.size() - 1; i++) {
//                                Services_names.add(activitiesDataServices.get(i).gettitle());
//                                Services_Code.add(activitiesDataServices.get(i).getid());
//                            }
//                            String cancel = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("الغاء", "الغاء");
//                            String ok = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("ok", "موافق");
//                            MaterialDialog.Builder builder = new MaterialDialog.Builder(getActivity());
//                            Services_name = Services_names.toArray(new String[Services_names.size()]);
//                            builder.setNegativeButton(cancel, citycreateNegativeButtonListener());
//                            builder.setSingleChoiceItems(Services_name, ServicesPositionClicked, citycreateSingleChoiceListener());
//                            builder.create();
//                            ServicesPositionClicked = 0;
//                            if (ifChangetab) {
//                                ServicesPositionClicked = Services_names.size() - 1;
//                            }
//                            Services = Services_names.get(ServicesPositionClicked);
//                            ServicesCode = Services_Code.get(ServicesPositionClicked);
//                            tv_services.setText(Services_names.get(ServicesPositionClicked));
////                            builder.show();
//                        }
////                        end services

                        if (invitationsactivitiesData.size() > 0) {

                            if (isInvitationsLasthNeed) {
                                adapter = new InvitationsLvAdapter(objectBAJava, invitationsactivitiesData, notificationactivitiesData, objInvitationsFragment, isNotificationsTab);
                                listView.setAdapter(adapter);
                                listView.setSelection(listView.getAdapter().getCount() - 1);
                                adapter.notifyDataSetChanged();

                            } else {
                                adapter = new InvitationsLvAdapter(objectBAJava, invitationsactivitiesData, notificationactivitiesData, objInvitationsFragment, isNotificationsTab);
                                listView.setAdapter(adapter);
                                adapter.notifyDataSetChanged();

                                try {
                                    listView.setSelection(scrolly);
                                } catch (Exception e) {

                                }
                                adapter.notifyDataSetChanged();

//                                ((InvitationsLvAdapter) listView.getAdapter()).notifyDataSetChanged();

                            }

                        } else {
                            tv_noresult.setVisibility(View.VISIBLE);
                            listView.setVisibility(View.GONE);
                            ll_two.setVisibility(View.GONE);
                        }

                    } else {
                        generic.hideProgressBar(spinner);
                        if (invitationsactivitiesData.size() == 0) {
                            tv_noresult.setVisibility(View.VISIBLE);
                            listView.setVisibility(View.GONE);
                        }

//                        Snackbar snackbar = Snackbar.make(ll_two, Message, Snackbar.LENGTH_LONG);
//                        snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
//                        snackbar.show();
                    }

                    if (!isRunhandlerInvitations) {
                        isRunhandlerInvitations = true;
                        refreshInvitations();
                        System.out.println("here is in refreshInvitations ");
                    }

                } else {
                    generic.hideProgressBar(spinner);
                    try {

                        if (invitationsactivitiesData.size() == 0) {
                            tv_noresult.setVisibility(View.VISIBLE);
                            listView.setVisibility(View.GONE);
                        }

//                        spinner.setVisibility(View.GONE);
                        generic.hideProgressBar(spinner);
                        String userMessage = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("oops", "هناك خطأ ما");
                        JSONObject jObjError = new JSONObject(response.errorBody().string());
                        try {
                            userMessage = jObjError.getString("message");
                        } catch (Exception e) {
                        }

                        String dataArrayMessage = "";
                        try {
                            JSONArray jsonArray = jObjError.getJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                dataArrayMessage = dataArrayMessage + jsonArray.getString(i) + "\n";
                            }

                        } catch (Exception e) {
                        }


                        String maintenanceBtnText = "Try Again";
                        try {
                            maintenanceBtnText = jObjError.optString("btn_text");
                        } catch (Exception e) {
                        }

                        generic.genericCodes(ll_two, response.code(), userMessage, dataArrayMessage, maintenanceBtnText);

                    } catch (Exception e) {

//                        spinner.setVisibility(View.GONE);
                        generic.hideProgressBar(spinner);
                        if (invitationsactivitiesData.size() == 0) {
                            tv_noresult.setVisibility(View.VISIBLE);
                            listView.setVisibility(View.GONE);
                            ll_two.setVisibility(View.GONE);
                        }

//                        Snackbar snackbar = Snackbar.make(ll_two, PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("oops", "هناك خطأ ما"), Snackbar.LENGTH_LONG);
//                        snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
//                        snackbar.show();

                    }
                }
            }

            @Override
            public void onFailure(Call<InvitationsResult> call, Throwable t) {
//                spinner.setVisibility(View.GONE);
                generic.hideProgressBar(spinner);
//
//                Snackbar snackbar = Snackbar.make(ll_two, PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("oops", "هناك خطأ ما"), Snackbar.LENGTH_LONG);
//                snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
//                snackbar.show();
                isInvitationRequsting = false;

                if (invitationsactivitiesData.size() == 0) {
                    tv_noresult.setVisibility(View.VISIBLE);
                    listView.setVisibility(View.GONE);
                    ll_two.setVisibility(View.GONE);
                }
            }
        });
    }

    public void callapiCallInvitationsList() {

        if (ntobj.isConnectingToInternet()) {

            ll_two.setVisibility(View.GONE);
            listView.setVisibility(View.GONE);
            generic.showProgressBar(spinner);
            tv_noresult.setVisibility(View.GONE);
            invitationsactivitiesData.clear();
            activitiesDataServices.clear();
            objectBAJava.hideKeyboard();
            isInvitationRequsting = true;
            ServicesCode="all";
            apiCallInvitationsList(ServicesCode);
        } else {
            activitiesDataServices.clear();
            String Message = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
            generic.showSnackbar(tv_noresult, Message, Snackbar.LENGTH_LONG, "close", false);
            tv_noresult.setVisibility(View.VISIBLE);
            generic.hideProgressBar(spinner);
            ll_two.setVisibility(View.GONE);
            listView.setVisibility(View.GONE);
            invitationsactivitiesData.clear();
        }
    }

    public void callapiCallNotificationsList() {

        if (ntobj.isConnectingToInternet()) {
            ll_two.setVisibility(View.GONE);
            listView.setVisibility(View.GONE);
            generic.showProgressBar(spinner);
            tv_noresult.setVisibility(View.GONE);
            objectBAJava.hideKeyboard();
            notificationactivitiesData.clear();
            activitiesDataServices.clear();
            isMessagesRequsting = true;
//            apiGetServices();
            ServicesCode="all";
            apiCallNotificationsList(ServicesCode);
        } else {
            activitiesDataServices.clear();
            String Message = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
            generic.showSnackbar(rl_body, Message, Snackbar.LENGTH_LONG, "close", false);
            tv_noresult.setVisibility(View.VISIBLE);
            generic.hideProgressBar(spinner);
            ll_two.setVisibility(View.GONE);
            listView.setVisibility(View.GONE);
            notificationactivitiesData.clear();
        }
    }

    public void apiCallNotificationsList(String service_id) {
        tv_noresult.setVisibility(View.GONE);
        isFirstTimeCall = false;
        notificationactivitiesData.clear();
        notificationactivitiesData = new ArrayList<>();
//        generic.showProgressBar(spinner);
        Map<String, String> params = generic.setBasicParams();
        params.put("auth_token", generic.getAuthTockenFromDb());
        params.put("service_id", service_id);
        OkHttpClient client = generic.setHeaderForReqs().build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(AppWebServices.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();
        ApiService service = retrofit.create(ApiService.class);
        Call<NotificatiionsResult> call = service.notification(params);
        call.enqueue(new Callback<NotificatiionsResult>() {

            @Override
            public void onResponse(Call<NotificatiionsResult> call, retrofit2.Response<NotificatiionsResult> response) {
                isMessagesRequsting = false;
                if (response.code() == 200) {
                    Boolean status = response.body().getstatus();
                    String Message = response.body().getMessage();
                    if (status) {
                        generic.hideProgressBar(spinner);
                        ll_two.setVisibility(View.VISIBLE);
                        listView.setVisibility(View.VISIBLE);
                        tv_noresult.setVisibility(View.GONE);

                        if (response.body().getdata().getnotifications().size() > 0) {
                            for (int i = 0; i < response.body().getdata().getnotifications().size(); i++) {
                                notificationactivitiesData.add(response.body().getdata().getnotifications().get(i));
                            }
                        }

                        if (notificationactivitiesData.size() > 0) {
                            System.out.println("here is in refresh Size notificationactivitiesData " + notificationactivitiesData.size());


                            if (isMessagesLastNeed) {
                                adapter = new InvitationsLvAdapter(objectBAJava, invitationsactivitiesData, notificationactivitiesData, objInvitationsFragment, isNotificationsTab);
                                listView.setAdapter(adapter);
                                listView.setSelection(listView.getAdapter().getCount() - 1);
                                adapter.notifyDataSetChanged();
                            } else {
                                adapter = new InvitationsLvAdapter(objectBAJava, invitationsactivitiesData, notificationactivitiesData, objInvitationsFragment, isNotificationsTab);
                                listView.setAdapter(adapter);
                                adapter.notifyDataSetChanged();

                                try {
                                    listView.setSelection(scrolly);
                                } catch (Exception e) {

                                }
                                adapter.notifyDataSetChanged();

//                                ((InvitationsLvAdapter) listView.getAdapter()).notifyDataSetChanged();

                            }

                        } else {
                            tv_noresult.setVisibility(View.VISIBLE);
                            listView.setVisibility(View.GONE);
                            ll_two.setVisibility(View.GONE);
                        }
////start services
//                        if (activitiesDataServices.size() <= 0) {
//                            activitiesDataServices.clear();
//                            if (response.body().getdata().getservices() != null) {
//                                if (response.body().getdata().getservices().size() > 0) {
//                                    for (int i = 0; i < response.body().getdata().getservices().size(); i++) {
//                                        activitiesDataServices.add(response.body().getdata().getservices().get(i));
//                                    }
//                                }
//                            }
//                            Services_name = new String[0];
//                            Services_names = new ArrayList<String>();
//                            Services_Code = new ArrayList<String>();
//                            for (int i = 0; i <= activitiesDataServices.size() - 1; i++) {
//                                Services_names.add(activitiesDataServices.get(i).gettitle());
//                                Services_Code.add(activitiesDataServices.get(i).getid());
//                            }
//                            String cancel = "إلغاء";
//                            String ok = "حسنا";
//                            MaterialDialog.Builder builder = new MaterialDialog.Builder(objectBAJava);
//                            Services_name = Services_names.toArray(new String[Services_names.size()]);
//                            builder.setNegativeButton(cancel, citycreateNegativeButtonListener());
//                            builder.setSingleChoiceItems(Services_name, ServicesPositionClicked, citycreateSingleChoiceListener());
//                            builder.create();
////                            ServicesPositionClicked = 0;
//                            if (ifChangetab) {
//                                ServicesPositionClicked = Services_names.size() - 1;
//                            }
//                            Services = Services_names.get(ServicesPositionClicked);
//                            ServicesCode = Services_Code.get(ServicesPositionClicked);
//                            tv_services.setText(Services_names.get(ServicesPositionClicked));
////                            builder.show();
//                        }
//
//                        //services end

                        if (!isRunhandlerMessages) {
                            isRunhandlerMessages = true;
                            refreshMessages();
                            System.out.println("here is in refreshMessages ");
                        }


                    } else {
                        generic.hideProgressBar(spinner);
                        if (notificationactivitiesData.size() == 0) {
                            tv_noresult.setVisibility(View.VISIBLE);
                            listView.setVisibility(View.GONE);
                        }
//                        Snackbar snackbar = Snackbar.make(ll_two, Message, Snackbar.LENGTH_LONG);
//                        snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
//                        snackbar.show();
                    }

                } else {
                    generic.hideProgressBar(spinner);
                    try {

                        if (notificationactivitiesData.size() == 0) {
                            tv_noresult.setVisibility(View.VISIBLE);
                            listView.setVisibility(View.GONE);
                        }

//                        spinner.setVisibility(View.GONE);
                        generic.hideProgressBar(spinner);
                        String userMessage = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("oops", "هناك خطأ ما");
                        JSONObject jObjError = new JSONObject(response.errorBody().string());
                        try {
                            userMessage = jObjError.getString("message");
                        } catch (Exception e) {
                        }

                        String dataArrayMessage = "";
                        try {
                            JSONArray jsonArray = jObjError.getJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                dataArrayMessage = dataArrayMessage + jsonArray.getString(i) + "\n";
                            }

                        } catch (Exception e) {
                        }


                        String maintenanceBtnText = "Try Again";
                        try {
                            maintenanceBtnText = jObjError.optString("btn_text");
                        } catch (Exception e) {
                        }

                        generic.genericCodes(ll_two, response.code(), userMessage, dataArrayMessage, maintenanceBtnText);

                    } catch (Exception e) {

//                        spinner.setVisibility(View.GONE);
                        generic.hideProgressBar(spinner);
                        if (notificationactivitiesData.size() == 0) {
                            tv_noresult.setVisibility(View.VISIBLE);
                            listView.setVisibility(View.GONE);
                            ll_two.setVisibility(View.GONE);
                        }

//                        Snackbar snackbar = Snackbar.make(ll_two, PreferenceManager.getDefaultSharedPreferences(objectBAJava).getString("oops", "هناك خطأ ما"), Snackbar.LENGTH_LONG);
//                        snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
//                        snackbar.show();

                    }
                }
            }

            @Override
            public void onFailure(Call<NotificatiionsResult> call, Throwable t) {
//                spinner.setVisibility(View.GONE);
                generic.hideProgressBar(spinner);
                isMessagesRequsting = false;
//                Snackbar snackbar = Snackbar.make(ll_two, "هناك خطأ ما", Snackbar.LENGTH_LONG);
//                snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
//                snackbar.show();

                //      generic.showSnackbar(rl_body, "هناك خطأ ما", Snackbar.LENGTH_LONG, "", false);
                if (notificationactivitiesData.size() == 0) {
                    tv_noresult.setVisibility(View.VISIBLE);
                    listView.setVisibility(View.GONE);
                    ll_two.setVisibility(View.GONE);
                }
            }
        });
    }

    public void showWorkPictures(String urlforimag) {

        Intent intent = new Intent(getActivity(), ShowWorkPictureActivity.class);
        intent.putExtra("imageuri", urlforimag);
        startActivity(intent);
        generic.animStart();

    }

    private DialogInterface.OnClickListener citycreateSingleChoiceListener() {
        return new DialogInterface.OnClickListener() {
            @Override
            public void onClick(final DialogInterface dialog, final int position) {
                isInvitationsLasthNeed = true;
                isMessagesLastNeed = true;
                ServicesPositionClicked = position;
                Services = Services_names.get(ServicesPositionClicked);
                ServicesCode = Services_Code.get(ServicesPositionClicked);
                tv_services.setText(Services_names.get(ServicesPositionClicked));
                ifChangetab = false;
//                if (!isFirstTimeCall) {
                if (isNotificationsTab) {
                    if (ntobj.isConnectingToInternet()) {
                        ll_two.setVisibility(View.GONE);
                        listView.setVisibility(View.GONE);
                        generic.showProgressBar(spinner);
                        tv_noresult.setVisibility(View.GONE);
                        objectBAJava.hideKeyboard();
                        notificationactivitiesData.clear();
                        isMessagesRequsting = true;
                        apiCallNotificationsList(ServicesCode);
                    } else {
                        String Message = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
                        generic.showSnackbar(tv_noresult, Message, Snackbar.LENGTH_LONG, "close", false);
                        tv_noresult.setVisibility(View.VISIBLE);
                        generic.hideProgressBar(spinner);
                        ll_two.setVisibility(View.GONE);
                        listView.setVisibility(View.GONE);
                        notificationactivitiesData.clear();
                    }
                } else {
                    if (ntobj.isConnectingToInternet()) {
                        ll_two.setVisibility(View.GONE);
                        listView.setVisibility(View.GONE);
                        generic.showProgressBar(spinner);
                        tv_noresult.setVisibility(View.GONE);
                        objectBAJava.hideKeyboard();
                        invitationsactivitiesData.clear();
                        isInvitationRequsting = true;
                        apiCallInvitationsList(ServicesCode);
                    } else {
                        String Message = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
                        generic.showSnackbar(tv_noresult, Message, Snackbar.LENGTH_LONG, "close", false);
                        tv_noresult.setVisibility(View.VISIBLE);
                        generic.hideProgressBar(spinner);
                        ll_two.setVisibility(View.GONE);
                        listView.setVisibility(View.GONE);
                        invitationsactivitiesData.clear();
                    }
                }
//                }

                dialog.dismiss();
                System.out.println("its value of ServicesPositionClicked " + ServicesPositionClicked + " " + Services + " " + ServicesCode);
            }

        };
    }

    private DialogInterface.OnClickListener citycreateNegativeButtonListener() {
        return new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        };
    }

    public void apiCallDeviceTocken() {
        Map<String, String> params = generic.setBasicParams();
        params.put("auth_token", generic.getAuthTockenFromDb());
        params.put("device_token", generic.getDeviceToken());
        OkHttpClient client = generic.setHeaderForReqs().build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(AppWebServices.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();

        ApiService service = retrofit.create(ApiService.class);
        Call<DefaultResult> call = service.update_device(params);
        call.enqueue(new Callback<DefaultResult>() {

            @Override
            public void onResponse(Call<DefaultResult> call, retrofit2.Response<DefaultResult> response) {
                if (response.code() == 200) {

                    Boolean status = response.body().getstatus();
                    String Message = response.body().getMessage();

                    if (status) {
                        PreferenceManager.getDefaultSharedPreferences(objectBAJava).edit().putBoolean("isDevicetockensend", true).apply();
                        System.out.println("Check device tocken start inv in api true");

//                        generic.hideProgressBar(spinner);
//                        generic.hideProgressBar(spinner1);
//                        ll_two.setVisibility(View.VISIBLE);
//                        listView.setVisibility(View.VISIBLE);
//                        tv_noresult.setVisibility(View.GONE);
//                        tv_question.setText(response.body().getdata().getelection().gettitle());
//                        election_id = response.body().getdata().getelection().getid();
//
//                        if (response.body().getdata().getelectors().size() > 0) {
//                            for (int i = 0; i < response.body().getdata().getelectors().size(); i++) {
//                                activitiesData.add(response.body().getdata().getelectors().get(i));
//                            }
//                        }
//
//                        if (response.body().getdata().getuser().getselected_elector_ids() != null) {
//                            if (response.body().getdata().getuser().getselected_elector_ids().size() > 0) {
//                                for (int i = 0; i < response.body().getdata().getuser().getselected_elector_ids().size(); i++) {
//
//                                    activitiesVoterData.add(response.body().getdata().getuser().getselected_elector_ids().get(i));
//                                }
//                            }
//                        }
//
//                        if (activitiesVoterData.size() > 0) {
//                            for (int i = 0; i < activitiesData.size(); i++) {
//
//                                for (int j = 0; j < activitiesVoterData.size(); j++) {
//
//                                    if (activitiesVoterData.get(j).equals(activitiesData.get(i).getid())) {
//                                        activitiesData.get(i).setisvoted(true);
//                                    }
//                                }
//                            }
//                        }
//                        if (response.body().getdata().getuser().getis_document_uploaded()) {
//                            if (response.body().getdata().getuser().getis_document_verified()) {
//                                if (!response.body().getdata().getuser().getis_already_voted()) {
//                                    if (response.body().getdata().getelection().getno_of_electors_select().equals("0")) {
//
//                                        ll_two.setVisibility(View.GONE);
//                                        tv_noresult.setVisibility(View.VISIBLE);
//                                        tv_noresult.setText("لا توجد انتخابات متاحة");
//
//                                    } else {
//
//                                        selectedlimit = Integer.parseInt(response.body().getdata().getelection().getno_of_electors_select());
//                                        boolean isselect = response.body().getdata().getuser().getis_already_voted();
//                                        if (activitiesData.size() == 0) {
//
//                                            ll_two.setVisibility(View.GONE);
//                                            generic.hideProgressBar(spinner);
//                                            spinner1.setVisibility(View.GONE);
//                                            tv_noresult.setVisibility(View.VISIBLE);
//                                            listView.setVisibility(View.GONE);
//                                            rl_submit.setVisibility(View.GONE);
//
//                                        } else {
//                                            adapter = new ElectorsLvAdapter(getActivity(), activitiesData, objElectorsFragment, isselect);
//                                            listView.setAdapter(adapter);
//                                            rl_submit.setVisibility(View.VISIBLE);
//                                            ll_two.setVisibility(View.VISIBLE);
//                                            listView.setVisibility(View.VISIBLE);
//                                            generic.hideProgressBar(spinner);
//                                            tv_noresult.setVisibility(View.GONE);
//                                        }
//                                    }
//
//                                } else // already cast vote
//                                {
//                                    // hide button and disable selection
//                                    boolean isselect = response.body().getdata().getuser().getis_already_voted();
//
//                                    if (activitiesData.size() == 0) {
//                                        generic.hideProgressBar(spinner);
//                                        spinner1.setVisibility(View.GONE);
//                                        tv_noresult.setVisibility(View.VISIBLE);
//                                        listView.setVisibility(View.GONE);
//                                        rl_submit.setVisibility(View.GONE);
//
//                                    } else {
//                                        ll_two.setVisibility(View.VISIBLE);
//                                        listView.setVisibility(View.VISIBLE);
//                                        generic.hideProgressBar(spinner);
//                                        tv_noresult.setVisibility(View.GONE);
//                                        rl_submit.setVisibility(View.GONE);
//                                        adapter = new ElectorsLvAdapter(getActivity(), activitiesData, objElectorsFragment, isselect);
//                                        listView.setAdapter(adapter);
//                                    }
//                                }
//                            } else // under review
//                            {
//                                ll_two.setVisibility(View.GONE);
//                                listView.setVisibility(View.GONE);
//                                tv_noresult.setVisibility(View.VISIBLE);
//                                tv_noresult.setText("المستند قيد المراجعة");
//                            }
//                        } else // upload document
//                        {
//                            Intent intent = new Intent(getActivity(), RegisterVoteActivity.class);
//                            startActivity(intent);
//                            getActivity().overridePendingTransition(R.anim.start_slide_in_left, R.anim.start_slide_out_left);
//                        }
//                        Snackbar snackbar = Snackbar.make(ll_two, Message, Snackbar.LENGTH_LONG);
//                        snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
//                        snackbar.show();

                    } else {
//                        generic.hideProgressBar(spinner);
//                        if (activitiesData.size() == 0) {
//                            tv_noresult.setVisibility(View.VISIBLE);
//                            listView.setVisibility(View.GONE);
//                        }

//                        Snackbar snackbar = Snackbar.make(ll_two, Message, Snackbar.LENGTH_LONG);
//                        snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
//                        snackbar.show();
                        System.out.println("Check device tocken start inv in api false");

                    }

//                } else {
//                    generic.hideProgressBar(spinner);
//                    try {
//
//                        if (activitiesData.size() == 0) {
//                            tv_noresult.setVisibility(View.VISIBLE);
//                            listView.setVisibility(View.GONE);
//                        }
//
////                        spinner.setVisibility(View.GONE);
//                        generic.hideProgressBar(spinner);
//                        spinner1.setVisibility(View.GONE);
//
//                        String userMessage = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("oops", "هناك خطأ ما");
//                        JSONObject jObjError = new JSONObject(response.errorBody().string());
//                        try {
//                            userMessage = jObjError.getString("message");
//                        } catch (Exception e) {
//                        }
//
//                        String dataArrayMessage = "";
//                        try {
//                            JSONArray jsonArray = jObjError.getJSONArray("data");
//                            for (int i = 0; i < jsonArray.length(); i++) {
//                                dataArrayMessage = dataArrayMessage + jsonArray.getString(i) + "\n";
//                            }
//
//                        } catch (Exception e) {
//                        }
//
//
//                        String maintenanceBtnText = "Try Again";
//                        try {
//                            maintenanceBtnText = jObjError.optString("btn_text");
//                        } catch (Exception e) {
//                        }
//
//                        generic.genericCodes(ll_two, response.code(), userMessage, dataArrayMessage, maintenanceBtnText);
//
//                    } catch (Exception e) {
//
////                        spinner.setVisibility(View.GONE);
//                        generic.hideProgressBar(spinner);
//                        spinner1.setVisibility(View.GONE);
//                        if (activitiesData.size() == 0) {
//                            tv_noresult.setVisibility(View.VISIBLE);
//                            listView.setVisibility(View.GONE);
//                        }
//
//                        Snackbar snackbar = Snackbar.make(ll_two, PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("oops", "هناك خطأ ما"), Snackbar.LENGTH_LONG);
//                        snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
//                        snackbar.show();
//
//                    }
//                }
                }
            }

            @Override
            public void onFailure(Call<DefaultResult> call, Throwable t) {
////                spinner.setVisibility(View.GONE);
//                generic.hideProgressBar(spinner);
//                spinner1.setVisibility(View.GONE);
//                reqIsInProgress = false;
//
//                Snackbar snackbar = Snackbar.make(ll_two, PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("oops", "هناك خطأ ما"), Snackbar.LENGTH_LONG);
//                snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
//                snackbar.show();
//
//                if (activitiesData.size() == 0) {
//                    tv_noresult.setVisibility(View.VISIBLE);
//                    listView.setVisibility(View.GONE);
//                }

                System.out.println("Check device tocken start inv in api exception");

            }
        });
    }

    public void refreshMessages() {

        handlerMessages.postDelayed(new Runnable() {
            public void run() {
                // Actions to do after 10 seconds
                if (!isMessagesRequsting) {
                    if (ntobj.isConnectingToInternet()) {
//                        objectBAJava.hideKeyboard();
                        notificationactivitiesData.clear();
                        activitiesDataServices.clear();
                        System.out.println("here is in refreshMessages ServicesCode " + ServicesCode);
                        isMessagesLastNeed = false;
                        //  View c = listView.getChildAt(0);
                        //   scrolly = -c.getTop() + listView.getFirstVisiblePosition() * c.getHeight();
                        apiCallNotificationsList(ServicesCode);
                    } else {
                        activitiesDataServices.clear();
                        String Message = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
                        generic.showSnackbar(rl_body, Message, Snackbar.LENGTH_LONG, "close", false);
                        tv_noresult.setVisibility(View.VISIBLE);
                        generic.hideProgressBar(spinner);
                        ll_two.setVisibility(View.GONE);
                        listView.setVisibility(View.GONE);
                        notificationactivitiesData.clear();
                    }

                }
                System.out.println("here is in refreshMessages in");
                handlerMessages.postDelayed(this, 10000);

            }
        }, 10000);
    }

    public void pauseRefreshMessages() {

        try {
            handlerMessages.removeCallbacksAndMessages(null);
            isRunhandlerMessages = false;
        } catch (Exception e) {
        }

    }

    public void refreshInvitations() {

        handlerInvitations.postDelayed(new Runnable() {

            public void run() {
                if (!isInvitationRequsting) {
                    if (ntobj.isConnectingToInternet()) {
//                    if (isFirstTimeCall) {
//                        ll_two.setVisibility(View.GONE);
//                        listView.setVisibility(View.GONE);
//                        generic.showProgressBar(spinner);
//                        tv_noresult.setVisibility(View.GONE);
//                    }                        objectBAJava.hideKeyboard();
                        invitationsactivitiesData.clear();
                        activitiesDataServices.clear();
                        System.out.println("here is in refreshInvitations ServicesCode " + ServicesCode);
                        isInvitationsLasthNeed = false;
                        // View c = listView.getChildAt(0);
                        // scrolly = -c.getTop() + listView.getFirstVisiblePosition() * c.getHeight();
                        apiCallInvitationsList(ServicesCode);
                    } else {
                        activitiesDataServices.clear();
                        String Message = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
                        generic.showSnackbar(tv_noresult, Message, Snackbar.LENGTH_LONG, "close", false);
                        tv_noresult.setVisibility(View.VISIBLE);
                        generic.hideProgressBar(spinner);
                        ll_two.setVisibility(View.GONE);
                        listView.setVisibility(View.GONE);
                        invitationsactivitiesData.clear();
                    }
                }
                System.out.println("here is in refreshInvitations in");
                handlerInvitations.postDelayed(this, 10000);
            }
        }, 10000);

    }

    public void pauseRefreshInvitations() {
        try {
            handlerInvitations.removeCallbacksAndMessages(null);
            isRunhandlerInvitations = false;
        } catch (Exception e) {
        }
    }

    @Override
    public void onDestroy() {
        pauseRefreshMessages();
        pauseRefreshInvitations();
        super.onDestroy();
    }

    @Override
    public void onPause() {
        super.onPause();
        pauseRefreshMessages();
        pauseRefreshInvitations();
    }

    @Override
    public void onResume() {
        super.onResume();
        isFirstTimeCall = true;
        isMessagesLastNeed = true;
        isInvitationsLasthNeed = true;

//        if (ntobj.isConnectingToInternet()) {
//            objectBAJava.hideKeyboard();
//            invitationsactivitiesData.clear();
//            notificationactivitiesData.clear();
//            activitiesDataServices.clear();
//            tv_noresult.setVisibility(View.GONE);
//            callapiCallNotificationsList();
//        } else {
//            activitiesDataServices.clear();
//            notificationactivitiesData.clear();
//            invitationsactivitiesData.clear();
//            tv_noresult.setVisibility(View.VISIBLE);
//            String Message = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
//            generic.showSnackbar(rl_body, Message, Snackbar.LENGTH_LONG, "close", false);
//        }

    }

    public void apiGetServices() {

        arrayListEditProfileServices.clear();
        generic.showProgressBar(spinner);
        Map<String, String> params = generic.setBasicParams();
        params.put("auth_token", generic.getAuthTockenFromDb());
        OkHttpClient client = generic.setHeaderForReqsForSaveServices().build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(AppWebServices.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();
        ApiService service = retrofit.create(ApiService.class);
        Call<ServicesResult> call = service.services(params);
        call.enqueue(new Callback<ServicesResult>() {
            @Override
            public void onResponse(Call<ServicesResult> call, retrofit2.Response<ServicesResult> response) {
                generic.hideProgressBar(spinner);
                int code = response.code();
                if (response.code() == 200) {
                    Boolean status = response.body().getstatus();
                    String message = response.body().getMessage();
                    if (status) {
                        if (response.body().getdata().getservicesdataServices().size() > 0) {

//                            for (int i = 0; i < response.body().getdata().getservicesdataServices().size(); i++) {
//                                ServicesdataServices servicesdataServicesobj = new ServicesdataServices();
//                                servicesdataServicesobj = response.body().getdata().getservicesdataServices().get(i);
//                                servicesdataServicesobj.setstatusinapp(false);
//                                activitiesDataArray.add(servicesdataServicesobj);
//                            }

                            if (response.body().getdata().getuser_services() != null) {

                                if (response.body().getdata().getuser_services().size() > 0) {

                                    for (int i = 0; i < response.body().getdata().getuser_services().size(); i++) {
                                        ServicesdataServices editProfileServices = new ServicesdataServices();
                                        editProfileServices = response.body().getdata().getuser_services().get(i);
                                        editProfileServices.setstatusinapp(true);
                                        arrayListEditProfileServices.add(editProfileServices);
                                    }
                                    ServicesdataServices editProfileServices = new ServicesdataServices();
                                    editProfileServices.setid("all");
                                    editProfileServices.settitle("الكل");
                                    editProfileServices.setstatus("1");
                                    editProfileServices.setstatusinapp(true);
                                    arrayListEditProfileServices.add(editProfileServices);
                                }
                            }
                            //                        services start

//                            if (arrayListEditProfileServices.size() <= 0) {
//                                arrayListEditProfileServices.clear();
//                                if (response.body().getdata().getservices() != null) {
//                                    if (response.body().getdata().getservices().size() > 0) {
//                                        for (int i = 0; i < response.body().getdata().getservices().size(); i++) {
//                                            arrayListEditProfileServices.add(response.body().getdata().getservices().get(i));
//                                        }
//                                    }
//                                }
                            Services_name = new String[0];
                            Services_names = new ArrayList<String>();
                            Services_Code = new ArrayList<String>();
                            for (int i = 0; i <= arrayListEditProfileServices.size() - 1; i++) {
                                Services_names.add(arrayListEditProfileServices.get(i).gettitle());
                                Services_Code.add(arrayListEditProfileServices.get(i).getid());
                            }
                            String cancel = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("الغاء", "الغاء");
                            String ok = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("ok", "موافق");
                            MaterialDialog.Builder builder = new MaterialDialog.Builder(getActivity());
                            Services_name = Services_names.toArray(new String[Services_names.size()]);
                            ServicesPositionClicked = Services_names.size() - 1;
                            Services = Services_names.get(ServicesPositionClicked);
                            ServicesCode = Services_Code.get(ServicesPositionClicked);
                            tv_services.setText(Services_names.get(ServicesPositionClicked));
                            builder.setNegativeButton(cancel, citycreateNegativeButtonListener());
                            builder.setSingleChoiceItems(Services_name, ServicesPositionClicked, citycreateSingleChoiceListener());
                            builder.create();
                            builder.show();

//                            ServicesPositionClicked = 0;
//                                if (ifChangetab) {
//                                }

//                            }
//                        end services


//                            if (activitiesDataArray.size() > 0) {
//
//                                if (arrayListEditProfileServices.size() > 0) {
//
//                                    for (int i = 0; i < activitiesDataArray.size(); i++) {
//                                        {
//
//                                            for (int j = 0; j < arrayListEditProfileServices.size(); j++) {
//                                                {
//                                                    if (activitiesDataArray.get(i).getid().equals(arrayListEditProfileServices.get(j).getid())) {
//
//                                                        activitiesDataArray.get(i).setstatusinapp(true);
//                                                    }
//                                                }
//                                            }
//                                        }
//                                    }
//                                }
//                            }
//                            else {
//                                rl_body.setVisibility(View.GONE);
//                                tv_noresult.setVisibility(View.VISIBLE);
//                            }

                        } else {
                            ll_two.setVisibility(View.GONE);
                            tv_noresult.setVisibility(View.VISIBLE);
                        }

                    } else {
                      //  generic.showSnackbar(rl_body, message, Snackbar.LENGTH_LONG, "close", false);
                        ll_two.setVisibility(View.GONE);
                        tv_noresult.setVisibility(View.VISIBLE);
                    }
                } else {
                    try {
                        String userMessage = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("oops", "هناك خطأ ما");
                        JSONObject jObjError = new JSONObject(response.errorBody().string());
                        try {
                            userMessage = jObjError.getString("message");
                        } catch (Exception e) {
                        }

                        String dataArrayMessage = "";
                        try {
                            JSONArray jsonArray = jObjError.getJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                dataArrayMessage = dataArrayMessage + jsonArray.getString(i) + "\n";
                            }
                        } catch (Exception e) {
                        }
                        String maintenanceBtnText = "Try Again";
                        try {
                            maintenanceBtnText = jObjError.optString("btn_text");
                        } catch (Exception e) {
                        }
                        generic.genericCodes(ll_two, response.code(), userMessage, dataArrayMessage, maintenanceBtnText);
                    } catch (Exception e) {
                        //  generic.showSnackbar(spinner, "هناك خطأ ما", Snackbar.LENGTH_LONG, "close", false);
                    }
                }
            }

            @Override
            public void onFailure(Call<ServicesResult> call, Throwable t) {
                generic.hideProgressBar(spinner);
                //   generic.showSnackbar(spinner, "هناك خطأ ما", Snackbar.LENGTH_LONG, "close", false);

            }
        });
    }

}