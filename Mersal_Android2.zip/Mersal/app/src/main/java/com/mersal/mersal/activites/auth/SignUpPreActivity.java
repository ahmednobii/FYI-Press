package com.mersal.mersal.activites.auth;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.Snackbar;
import android.text.InputFilter;
import android.text.Spanned;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.mersal.mersal.R;
import com.mersal.mersal.activites.base.BaseActivity;
import com.mersal.mersal.customviews.HeaderCustomTV;
import com.mersal.mersal.customviews.NoDataFoundCustomTV;
import com.mersal.mersal.generic.Interfaces.Generic;
import com.mersal.mersal.internetconnections.NetworkConnection;
import com.mersal.mersal.retrofit.baseapi.ApiService;
import com.mersal.mersal.retrofit.baseapi.AppWebServices;
import com.mersal.mersal.retrofit.defualt.DefaultResult;
import com.mersal.mersal.retrofit.otp.OtpResult;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.Map;

import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class SignUpPreActivity extends BaseActivity {

    TextView tv_blood_value, tv_blood, tv_submit, tv_dob, tv_gender;
    RelativeLayout rl_submit, r1_two_gender_tv, r1_two_blood_tv, rl_body, header_left_rl;
    String st_email = "", st_sname = "", st_familyname = "", st_fname = "", st_gender = "", st_dob = "", st_ph = "", st_blood = "";
    EditText et_name, et_sname, et_pwd, et_fname, et_ph;
    ProgressBar progressBar;
    LinearLayout ll_blood;
    NoDataFoundCustomTV tv_noresult;
    public static SignUpPreActivity SignUpPreActivityObject;
    NetworkConnection ntobj = new NetworkConnection(SignUpPreActivity.this);
    Generic generic;
    ImageView back_arrow;
    HeaderCustomTV toolbar_title;
    Calendar myCalendar;
    private String blockCharacterSet = ".';][}{*&^%$#@!~#^|$%&*!;,N-_()<> ";
    String id_name, id_date_of_birth, civil_number, expiry_date;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup_pre);

        if (SignUpPreActivity.this instanceof BaseActivity) {
            generic = (Generic) SignUpPreActivity.this;
        }
        generic.hideStatusBarForAuth();
        SignUpPreActivityObject = this;

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            id_name = extras.getString("idname");
            id_date_of_birth = extras.getString("iddob");
            civil_number = extras.getString("id_number");
            expiry_date = extras.getString("expiry_date");
//            docimageencode_FRONT = extras.getString("id_front");
//            docimageencode_BACK = extras.getString("id_back");
        }

        init();
        clickListener();
        objectBAJava.hideKeyboard();
    }

    public void init() {

        et_sname = (EditText) findViewById(R.id.et_sname);
        et_fname = (EditText) findViewById(R.id.et_fname);
        tv_gender = (TextView) findViewById(R.id.tv_gender);
        tv_dob = (TextView) findViewById(R.id.tv_dob);
        et_ph = (EditText) findViewById(R.id.et_ph);
        tv_blood_value = (TextView) findViewById(R.id.tv_blood_value);
        tv_blood = (TextView) findViewById(R.id.tv_blood);
        toolbar_title = (HeaderCustomTV) findViewById(R.id.toolbar_title);
        back_arrow = (ImageView) findViewById(R.id.back_arrow);
        et_name = (EditText) findViewById(R.id.et_name);
        et_pwd = (EditText) findViewById(R.id.et_pwd);
        tv_submit = (TextView) findViewById(R.id.tv_submit);
        rl_submit = (RelativeLayout) findViewById(R.id.rl_submit);
        ll_blood = (LinearLayout) findViewById(R.id.ll_blood);
        header_left_rl = (RelativeLayout) findViewById(R.id.header_left_rl);
        rl_body = (RelativeLayout) findViewById(R.id.rl_body);
        et_name.setTypeface(objectBAJava.roboto_regular);
        et_name.setTypeface(objectBAJava.roboto_regular);
        tv_submit.setTypeface(objectBAJava.roboto_regular);
        tv_blood.setTypeface(objectBAJava.roboto_regular);
        tv_noresult = (NoDataFoundCustomTV) findViewById(R.id.tv_noresult);
        r1_two_gender_tv = (RelativeLayout) findViewById(R.id.r1_two_gender_tv);
        r1_two_blood_tv = (RelativeLayout) findViewById(R.id.r1_two_blood_tv);
        toolbar_title.setText("إنشاء حساب");
        back_arrow.setVisibility(View.VISIBLE);
        myCalendar = Calendar.getInstance();
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        progressBar.setVisibility(View.GONE);

        et_sname.setTypeface(objectBAJava.Tahoma_Regular_font);
        et_name.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_gender.setTypeface(objectBAJava.Tahoma_Regular_font);
        et_fname.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_dob.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_dob.setText(id_date_of_birth);
//        et_name.setText(id_name);
//        et_name.setClickable(false);
//        et_name.setFocusable(false);
//        tv_dob.setClickable(false);
//        tv_dob.setFocusable(false);
        et_ph.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_blood_value.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_submit.setTypeface(objectBAJava.Tahoma_Regular_font);

        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT) {
            progressBar.getIndeterminateDrawable().setColorFilter(getResources()
                    .getColor(R.color.progress_bar_color_white), PorterDuff.Mode.SRC_IN);
        }

        et_ph.setFilters(new InputFilter[]{filter});
    }

    public void selectgender() {

        final CharSequence[] gender = {"ذكر", "أنثى"};
        final AlertDialog.Builder alert = new AlertDialog.Builder(SignUpPreActivity.this);
        alert.setTitle("الجنس");
        final String[] gen = new String[2];
        alert.setSingleChoiceItems(gender, -1, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (gender[which] == "ذكر") {
                    gen[0] = "1";
                    tv_gender.setText("ذكر");
                    dialog.dismiss();
                } else if (gender[which] == "أنثى") {
                    gen[0] = "2";
                    tv_gender.setText("أنثى");
                    dialog.dismiss();
                } else if (gender[which] == "Other") {
                    gen[0] = "2";
                    tv_gender.setText("other");
                    dialog.dismiss();
                }
            }
        });
        alert.show();
    }

    public void clickListener() {

//        tv_dob.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                objectBAJava.hideKeyboard();
//                DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
//
//                    @Override
//                    public void onDateSet(DatePicker view, int year, int monthOfYear,
//                                          int dayOfMonth) {
//                        // TODO Auto-generated method stub
//                        myCalendar.set(Calendar.YEAR, year);
//                        myCalendar.set(Calendar.MONTH, monthOfYear);
//                        myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
//
//                        Calendar cal = Calendar.getInstance();
//                        cal.set(year, monthOfYear, dayOfMonth);
//                        Date current = cal.getTime();
//                        int diff1 = new Date().compareTo(current);
//
//
//                        if (diff1 <= 0) {
//                            generic.showSnackbar(rl_body, "لا يمكنك اختيار التاريخ الحالي ، يجب أن يكون أقدم", Snackbar.LENGTH_LONG, "close", false);
//                            return;
//                        } else {
//                            String myFormat = "yyyy-MM-dd"; //In which you need put here
//                            SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
//                            tv_dob.setText(sdf.format(myCalendar.getTime()));
//                        }
//                    }
//
//                };
//                new DatePickerDialog(SignUpPreActivity.this, date, myCalendar.get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
//                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
//            }
//        });

        tv_gender.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                objectBAJava.hideKeyboard();
                selectgender();
            }
        });

        ll_blood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                objectBAJava.hideKeyboard();
                selectBloodGroup();
            }
        });


        rl_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                validation();

            }
        });

        header_left_rl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Intent mainIntent = new Intent(SigninActivity.this, EmailVerificationActivity.class);
//                startActivity(mainIntent);
//                overridePendingTransition(R.anim.start_slide_in_left, R.anim.start_slide_out_left);
//                objectBAJava.hideStatusBar();

                objectBAJava.hideStatusBar();
                finish();
                generic.animEnd();
            }
        });
    }

    protected void validation() {
        st_fname = et_name.getText().toString();
//        st_sname = et_sname.getText().toString();
//        st_familyname = et_fname.getText().toString();
//        st_dob = tv_dob.getText().toString();
//        st_ph = et_ph.getText().toString();
        st_gender = tv_gender.getText().toString();
        st_blood = tv_blood_value.getText().toString();
        if (st_fname.trim().equals("")) {
            et_name.requestFocus();
            et_name.setError("الاسم الكامل مطلوب");
        }
//        else if (st_sname.trim().equals("")) {
//            et_sname.setError("إسم الأب مطلوب");
//            et_sname.requestFocus();
//        } else if (st_familyname.trim().equals("")) {
//            et_fname.setError("القبيلة/العائلة مطلوب");
//            et_fname.requestFocus();
//        }
        else if (st_gender.trim().equals("Gender")) {
            generic.showSnackbar(tv_gender, "مطلوب الجنس", Snackbar.LENGTH_LONG, "close", false);
        }
//        else if (st_dob.trim().equals("")) {
//            generic.showSnackbar(tv_dob, "تاريخ الميلاد مطلوب", Snackbar.LENGTH_LONG, "close", false);
//        }
//        else if (st_ph.trim().equals("")) {
//            et_ph.setError("رقم الهاتف مطلوب");
//            et_ph.requestFocus();
//        }
        else if (st_blood.trim().equals("")) {
            generic.showSnackbar(tv_blood_value, "نوع فصيلة الدم مطلوبة", Snackbar.LENGTH_LONG, "close", false);
        } else {

//            hideKeyboard();
//            Intent intent = new Intent(SignUpPreActivity.this, SignUpActivity.class);
//            intent.putExtra("fname", st_fname);
//            intent.putExtra("sname", st_sname);
//            intent.putExtra("familyname", st_familyname);
//            intent.putExtra("dob", st_dob);
//            intent.putExtra("ph", st_ph);
//            intent.putExtra("gender", st_gender);
//            intent.putExtra("Blood", st_blood);
//            startActivity(intent);
//            animStart();
            if (ntobj.isConnectingToInternet()) {
                objectBAJava.hideKeyboard();
                generic.showProgressBar(progressBar);
//                apiCheckPhonenumber();

                generic.hideProgressBar(progressBar);
                hideKeyboard();
                Intent intent = new Intent(SignUpPreActivity.this, SignUpActivity.class);
                intent.putExtra("fname", st_fname);
                intent.putExtra("gender", st_gender);
                intent.putExtra("Blood", st_blood);
                intent.putExtra("idname", id_name);
                intent.putExtra("id_number", civil_number);
                intent.putExtra("expiry_date", expiry_date);
                intent.putExtra("iddob", id_date_of_birth);
//                intent.putExtra("sname", st_sname);
//                intent.putExtra("familyname", st_familyname);
                //                intent.putExtra("ph", st_ph);
//                        intent.putExtra("id_front", docimageencode_FRONT);
//                        intent.putExtra("id_back", docimageencode_BACK);
                startActivity(intent);
                animStart();


            } else {
                generic.hideProgressBar(progressBar);
                String Message = PreferenceManager.getDefaultSharedPreferences(SignUpPreActivity.this).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
                generic.showSnackbar(rl_body, Message, Snackbar.LENGTH_LONG, "close", false);
            }
        }
    }

    public void selectBloodGroup() {

        final CharSequence[] gender = {"A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-", "لا أعلم"};
        final AlertDialog.Builder alert = new AlertDialog.Builder(SignUpPreActivity.this);
        alert.setTitle("إختر فصيلة دمك");
        final String[] gen = new String[8];
        alert.setSingleChoiceItems(gender, -1, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (gender[which] == "A+") {
                    gen[0] = "1";
                    tv_blood_value.setText("A+");
                    dialog.dismiss();
                } else if (gender[which] == "A-") {
                    gen[0] = "2";
                    tv_blood_value.setText("A-");
                    dialog.dismiss();
                } else if (gender[which] == "B+") {
                    gen[0] = "2";
                    tv_blood_value.setText("B+");
                    dialog.dismiss();
                } else if (gender[which] == "B-") {
                    gen[0] = "2";
                    tv_blood_value.setText("B-");
                    dialog.dismiss();
                } else if (gender[which] == "AB+") {
                    gen[0] = "2";
                    tv_blood_value.setText("AB+");
                    dialog.dismiss();
                } else if (gender[which] == "AB-") {
                    gen[0] = "2";
                    tv_blood_value.setText("AB-");
                    dialog.dismiss();
                } else if (gender[which] == "O+") {
                    gen[0] = "2";
                    tv_blood_value.setText("O+");
                    dialog.dismiss();
                } else if (gender[which] == "O-") {
                    gen[0] = "2";
                    tv_blood_value.setText("O-");
                    dialog.dismiss();
                }
                else if(gender[which] == "لا أعلم"){
                    gen[0] = "2";
                    tv_blood_value.setText("  لا أعلم");
                    dialog.dismiss();

                }
            }
        });
        alert.show();
    }

    public void apigetOtpCode() {

        generic.showProgressBar(progressBar);

        Map<String, String> params = generic.setBasicParams();
        System.out.println("its device token from sigin " + getDeviceToken());
        params.put("phone", st_ph);

        OkHttpClient client = generic.setHeaderForReqs().build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(AppWebServices.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();
        ApiService service = retrofit.create(ApiService.class);
        Call<OtpResult> call = service.verifyphone(params);
        call.enqueue(new Callback<OtpResult>() {
            @Override
            public void onResponse(Call<OtpResult> call, retrofit2.Response<OtpResult> response) {

                generic.hideProgressBar(progressBar);
                int code = response.code();
                if (response.code() == 200) {
                    Boolean status = response.body().getstatus();
                    String message = response.body().getMessage();

                    if (status) {

                        hideKeyboard();
                        Intent intent = new Intent(SignUpPreActivity.this, SignUpActivity.class);
                        intent.putExtra("fname", st_fname);
                        intent.putExtra("sname", st_sname);
                        intent.putExtra("familyname", st_familyname);
                        intent.putExtra("iddob", st_dob);
                        intent.putExtra("ph", st_ph);
                        intent.putExtra("gender", st_gender);
                        intent.putExtra("Blood", st_blood);
                        intent.putExtra("email", "umarh@gmail.com");
                        intent.putExtra("code", response.body().getdata().getcode());


                        intent.putExtra("idname", id_name);
                        intent.putExtra("id_number", civil_number);
                        intent.putExtra("expiry_date", expiry_date);
//                        intent.putExtra("id_front", docimageencode_FRONT);
//                        intent.putExtra("id_back", docimageencode_BACK);

                        startActivity(intent);
                        finish();
                        animStart();


                    } else {
                        generic.showSnackbar(rl_body, message, Snackbar.LENGTH_LONG, "close", false);

                    }
                } else {

                    try {

                        String userMessage = PreferenceManager.getDefaultSharedPreferences(SignUpPreActivity.this).getString("oops", "هناك خطأ ما");
                        JSONObject jObjError = new JSONObject(response.errorBody().string());
                        try {
                            userMessage = jObjError.getString("message");
                        } catch (Exception e) {
                        }

                        String dataArrayMessage = "";
                        try {
                            JSONArray jsonArray = jObjError.getJSONArray("LoginResultdata");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                dataArrayMessage = dataArrayMessage + jsonArray.getString(i) + "\n";
                            }

                        } catch (Exception e) {
                        }

                        String maintenanceBtnText = "Try Again";
                        try {
                            maintenanceBtnText = jObjError.optString("btn_text");
                        } catch (Exception e) {
                        }
                        generic.genericCodes(rl_body, response.code(), userMessage, dataArrayMessage, maintenanceBtnText);
                    } catch (Exception e) {

                        generic.showSnackbar(progressBar, "هناك خطأ ما", Snackbar.LENGTH_LONG, "close", false);

                    }
                }
            }

            @Override
            public void onFailure(Call<OtpResult> call, Throwable t) {

                generic.hideProgressBar(progressBar);
                generic.showSnackbar(progressBar, "هناك خطأ ما", Snackbar.LENGTH_LONG, "close", false);

            }
        });
    }

    private InputFilter filter = new InputFilter() {

        @Override
        public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {

            if (source != null && blockCharacterSet.contains(("" + source))) {
                return "";
            }
            return null;
        }
    };

    public void apiCheckPhonenumber() {
        Map<String, String> params = generic.setBasicParams();
        params.put("phone", st_ph);
        OkHttpClient client = generic.setHeaderForReqs().build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(AppWebServices.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();

        ApiService service = retrofit.create(ApiService.class);
        Call<DefaultResult> call = service.phonenumber(params);
        call.enqueue(new Callback<DefaultResult>() {

            @Override
            public void onResponse(Call<DefaultResult> call, retrofit2.Response<DefaultResult> response) {
                if (response.code() == 200) {

                    Boolean status = response.body().getstatus();
                    String Message = response.body().getMessage();

                    if (status) {
                        generic.hideProgressBar(progressBar);
                        hideKeyboard();
                        Intent intent = new Intent(SignUpPreActivity.this, SignUpActivity.class);
                        intent.putExtra("fname", st_fname);
                        intent.putExtra("sname", st_sname);
                        intent.putExtra("familyname", st_familyname);
                        intent.putExtra("iddob", st_dob);
                        intent.putExtra("ph", st_ph);
                        intent.putExtra("gender", st_gender);
                        intent.putExtra("Blood", st_blood);
                        intent.putExtra("idname", id_name);
                        intent.putExtra("id_number", civil_number);
                        intent.putExtra("expiry_date", expiry_date);
//                        intent.putExtra("id_front", docimageencode_FRONT);
//                        intent.putExtra("id_back", docimageencode_BACK);


                        startActivity(intent);
                        animStart();
                    } else {
                        generic.hideProgressBar(progressBar);
                        Snackbar snackbar = Snackbar.make(rl_body, Message, Snackbar.LENGTH_LONG);
                        snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
                        snackbar.show();
                    }

                } else {
                    generic.hideProgressBar(progressBar);
                    try {

                        generic.hideProgressBar(progressBar);
                        String userMessage = PreferenceManager.getDefaultSharedPreferences(SignUpPreActivity.this).getString("oops", "هناك خطأ ما");
                        JSONObject jObjError = new JSONObject(response.errorBody().string());
                        try {
                            userMessage = jObjError.getString("message");
                        } catch (Exception e) {
                        }

                        String dataArrayMessage = "";
                        try {
                            JSONArray jsonArray = jObjError.getJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                dataArrayMessage = dataArrayMessage + jsonArray.getString(i) + "\n";
                            }

                        } catch (Exception e) {
                        }


                        String maintenanceBtnText = "Try Again";
                        try {
                            maintenanceBtnText = jObjError.optString("btn_text");
                        } catch (Exception e) {
                        }

                        generic.genericCodes(rl_body, response.code(), userMessage, dataArrayMessage, maintenanceBtnText);

                    } catch (Exception e) {

                        generic.hideProgressBar(progressBar);
                        Snackbar snackbar = Snackbar.make(rl_body, PreferenceManager.getDefaultSharedPreferences(SignUpPreActivity.this).getString("oops", "هناك خطأ ما"), Snackbar.LENGTH_LONG);
                        snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
                        snackbar.show();

                    }
                }
            }

            @Override
            public void onFailure(Call<DefaultResult> call, Throwable t) {
                generic.hideProgressBar(progressBar);
                Snackbar snackbar = Snackbar.make(rl_body, PreferenceManager.getDefaultSharedPreferences(SignUpPreActivity.this).getString("oops", "هناك خطأ ما"), Snackbar.LENGTH_LONG);
                snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
                snackbar.show();
            }
        });
    }
}
