package com.mersal.mersal.fragment;

import android.graphics.PorterDuff;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.mersal.mersal.R;
import com.mersal.mersal.activites.base.BaseActivity;
import com.mersal.mersal.adapter.VotingLvAdapter;
import com.mersal.mersal.customviews.NoDataFoundCustomTV;
import com.mersal.mersal.generic.Interfaces.Generic;
import com.mersal.mersal.internetconnections.NetworkConnection;
import com.mersal.mersal.retrofit.baseapi.ApiService;
import com.mersal.mersal.retrofit.baseapi.AppWebServices;
import com.mersal.mersal.retrofit.votinglist.VotingElectionsResult;
import com.mersal.mersal.retrofit.votinglist.VotingResult;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Map;

import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static com.mersal.mersal.activites.base.BaseActivity.objectBAJava;


public class VotingFragment extends Fragment {
    TextView tv_question, tv_submit;
    NoDataFoundCustomTV ls_tv_nodatafound;
    //    HeaderCustomTV home_title;
    ListView listView;
    ProgressBar spinner, spinner1;
    RelativeLayout rl_submit;
    NetworkConnection ntobj;
    VotingFragment votingFragment;
    RelativeLayout rl_body, rl_saveseeting;
    Generic generic;
    VotingLvAdapter adapter;
    int total_records;
    boolean reqIsInProgress = false;
    int page = 1;
    ArrayList<VotingElectionsResult> activitiesData = new ArrayList<>();

//    ImageView back_arrow;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_voting, container, false);

        votingFragment = this;
        if (getActivity() instanceof BaseActivity) {
            generic = (Generic) getActivity();
        }
        init(rootView);
        clicklisteners();
        callApiFirsttime();
        generic.hideStatusBar();//initialize to access database for this activity
        return rootView;

    }

    public void init(View rootView_) {
//
//        home_title = (HeaderCustomTV) getActivity().findViewById(R.id.toolbar_title);
//        home_title.setText("Voting");
        ntobj = new NetworkConnection(getActivity());
        spinner = (ProgressBar) rootView_.findViewById(R.id.progressBar);
        spinner1 = (ProgressBar) rootView_.findViewById(R.id.progress_view1);
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT) {
            spinner.getIndeterminateDrawable().setColorFilter(getResources()
                    .getColor(R.color.progress_bar_color_white), PorterDuff.Mode.SRC_IN);
            spinner1.getIndeterminateDrawable().setColorFilter(getResources()
                    .getColor(R.color.progress_bar_color_white), PorterDuff.Mode.SRC_IN);
        }
        listView = (ListView) rootView_.findViewById(R.id.lv_propsel);
        ls_tv_nodatafound = (NoDataFoundCustomTV) rootView_.findViewById(R.id.tv_noresult);
        rl_body = (RelativeLayout) rootView_.findViewById(R.id.rl_body);
        ls_tv_nodatafound.setVisibility(View.GONE);
//        back_arrow = (ImageView) rootView_.findViewById(R.id.back_arrow);
        rl_submit = (RelativeLayout) rootView_.findViewById(R.id.rl_submit);
        tv_question = (TextView) rootView_.findViewById(R.id.tv_question);
        tv_submit = (TextView) rootView_.findViewById(R.id.tv_submit);
        tv_question.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_submit.setTypeface(objectBAJava.Tahoma_Regular_font);

//        back_arrow.setVisibility(View.VISIBLE);
    }

    public void clicklisteners() {

//        back_arrow.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                objectBAJava.hideStatusBar();
//                getActivity().finish();
//                generic.animEnd();
//
//            }
//        });

        rl_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

//                objectBAJava.hideStatusBar();
//                getActivity().finish();
//                generic.animEnd();

            }
        });
    }

    public void Pagination(ArrayList<VotingElectionsResult> activitiesDataArray, int position) {

        int a = activitiesDataArray.size() - 1;
        if (position == a) {
            if (reqIsInProgress == false && total_records > activitiesDataArray.size()) {
                page = page + 1;
                apiCallVotingList();

            }
        }
    }

    public void apiCallVotingList() {
        ls_tv_nodatafound.setVisibility(View.GONE);
        reqIsInProgress = true;
        if (page == 1) {
            activitiesData.clear();
            generic.showProgressBar(spinner);
        } else {

            int bottomMargin = (int) getResources().getDimension(R.dimen.pagination_progressbar_size);
            RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) listView.getLayoutParams();
            lp.setMargins(8, 8, 8, bottomMargin + 5);
            listView.setLayoutParams(lp);
            spinner1.setVisibility(View.VISIBLE);
        }

        Map<String, String> params = generic.setBasicParams();
        params.put("auth_token", generic.getAuthTockenFromDb());
        params.put("page_size", "20");
        params.put("page_no", String.valueOf(page));
        params.put("order", "asc");
        params.put("order_by", "date");
        params.put("keyword", "");


        OkHttpClient client = generic.setHeaderForReqs().build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(AppWebServices.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();

        ApiService service = retrofit.create(ApiService.class);
        Call<VotingResult> call = service.votinglist(params);
        call.enqueue(new Callback<VotingResult>() {

            @Override
            public void onResponse(Call<VotingResult> call, retrofit2.Response<VotingResult> response) {

                reqIsInProgress = false;
                if (response.code() == 200) {

                    Boolean status = response.body().getstatus();
                    String Message = response.body().getMessage();

                    if (status) {

                        generic.hideProgressBar(spinner);
                        generic.hideProgressBar(spinner1);
                        rl_body.setVisibility(View.VISIBLE);
                        listView.setVisibility(View.VISIBLE);
                        ls_tv_nodatafound.setVisibility(View.GONE);

                        if (response.body().getdata().getelections().getresult().size() > 0) {
                            for (int i = 0; i < response.body().getdata().getelections().getresult().size(); i++) {
                                activitiesData.add(response.body().getdata().getelections().getresult().get(i));
                            }
                        }

                        total_records = Integer.parseInt(response.body().getdata().getelections().gettotal_records());
                        page = response.body().getdata().getelections().getpage();
//                        home_title.setText(response.body().getdata().getPage_title());

                        if (page == 1) {
                            generic.hideProgressBar(spinner);
                        } else {
                            RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) listView.getLayoutParams();
                            lp.setMargins(8, 8, 8, 8);
                            listView.setLayoutParams(lp);
                            spinner1.setVisibility(View.GONE);
                        }

                        if (listView.getAdapter() == null) {
                            adapter = new VotingLvAdapter(getActivity(), activitiesData, votingFragment);
                            listView.setAdapter(adapter);
                        } else {
                            adapter.notifyDataSetChanged();
                        }

                        if (activitiesData.size() == 0) {

                            generic.hideProgressBar(spinner);
                            spinner1.setVisibility(View.GONE);
                            ls_tv_nodatafound.setVisibility(View.VISIBLE);
                            listView.setVisibility(View.GONE);
                        }

                    } else {
                        generic.hideProgressBar(spinner);
                        if (activitiesData.size() == 0) {
                            ls_tv_nodatafound.setVisibility(View.VISIBLE);
                            listView.setVisibility(View.GONE);
                        }

                        Snackbar snackbar = Snackbar.make(rl_body, Message, Snackbar.LENGTH_LONG);
                        snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
                        snackbar.show();
                    }

                } else {
                    generic.hideProgressBar(spinner);
                    try {

                        if (activitiesData.size() == 0) {
                            ls_tv_nodatafound.setVisibility(View.VISIBLE);
                            listView.setVisibility(View.GONE);
                        }

//                        spinner.setVisibility(View.GONE);
                        generic.hideProgressBar(spinner);
                        spinner1.setVisibility(View.GONE);

                        String userMessage = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("oops", "هناك خطأ ما");
                        JSONObject jObjError = new JSONObject(response.errorBody().string());
                        try {
                            userMessage = jObjError.getString("message");
                        } catch (Exception e) {
                        }

                        String dataArrayMessage = "";
                        try {
                            JSONArray jsonArray = jObjError.getJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                dataArrayMessage = dataArrayMessage + jsonArray.getString(i) + "\n";
                            }

                        } catch (Exception e) {
                        }


                        String maintenanceBtnText = "Try Again";
                        try {
                            maintenanceBtnText = jObjError.optString("btn_text");
                        } catch (Exception e) {
                        }

                        generic.genericCodes(rl_body, response.code(), userMessage, dataArrayMessage, maintenanceBtnText);

                    } catch (Exception e) {

//                        spinner.setVisibility(View.GONE);
                        generic.hideProgressBar(spinner);
                        spinner1.setVisibility(View.GONE);
                        if (activitiesData.size() == 0) {
                            ls_tv_nodatafound.setVisibility(View.VISIBLE);
                            listView.setVisibility(View.GONE);
                        }

                        Snackbar snackbar = Snackbar.make(rl_body, PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("oops", "هناك خطأ ما"), Snackbar.LENGTH_LONG);
                        snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
                        snackbar.show();

                    }
                }
            }

            @Override
            public void onFailure(Call<VotingResult> call, Throwable t) {
//                spinner.setVisibility(View.GONE);
                generic.hideProgressBar(spinner);
                spinner1.setVisibility(View.GONE);
                reqIsInProgress = false;

                Snackbar snackbar = Snackbar.make(rl_body, PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("oops", "هناك خطأ ما"), Snackbar.LENGTH_LONG);
                snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
                snackbar.show();

                if (activitiesData.size() == 0) {
                    ls_tv_nodatafound.setVisibility(View.VISIBLE);
                    listView.setVisibility(View.GONE);
                }
            }
        });
    }

    public void callApiFirsttime() {

        if (ntobj.isConnectingToInternet()) {
            rl_body.setVisibility(View.GONE);
            objectBAJava.hideKeyboard();
            reqIsInProgress = false;
            page = 1;
            total_records = 0;
            activitiesData.clear();
            generic.showProgressBar(spinner);
            generic.hideProgressBar(spinner1);
            apiCallVotingList();
        } else {
            String Message = PreferenceManager.getDefaultSharedPreferences(getActivity()).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
            generic.showSnackbar(ls_tv_nodatafound, Message, Snackbar.LENGTH_LONG, "close", false);
            ls_tv_nodatafound.setVisibility(View.VISIBLE);
            generic.hideProgressBar(spinner);
            rl_body.setVisibility(View.GONE);
            generic.hideProgressBar(spinner1);
            page = 1;
            total_records = 0;
            reqIsInProgress = false;
            activitiesData.clear();
        }
    }

    public void goOnActivity(String id) {
//        Intent intent = new Intent(getActivity(), ElectorsActivity.class);
//        intent.putExtra("id", id);
//        startActivity(intent);
//        getActivity().overridePendingTransition(R.anim.start_slide_in_left, R.anim.start_slide_out_left);
    }


}