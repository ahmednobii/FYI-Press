package com.mersal.mersal.adapter;

import android.content.Context;
import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.mersal.mersal.R;
import com.mersal.mersal.fragment.VotingFragment;
import com.mersal.mersal.retrofit.votinglist.VotingElectionsResult;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

import static com.mersal.mersal.activites.base.BaseActivity.objectBAJava;


public class VotingLvAdapter extends ArrayAdapter<String> {
    private final Context context;
    ArrayList<VotingElectionsResult> activitiesDataArray = new ArrayList<>();
    LayoutInflater inflater = null;
    VotingFragment fragment;

    public VotingLvAdapter(Context context, ArrayList<VotingElectionsResult> activitiesDataArray, VotingFragment fragment_) {
        super(context, R.layout.lv_voting_item);
        this.context = context;
        this.fragment = fragment_;
        this.activitiesDataArray = activitiesDataArray;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }


    @Override
    public int getCount() {
        return activitiesDataArray.size();
    }

    private class ViewHolder {
        TextView tv_uname, tv_udetails;
        CircleImageView iv_profile;
        RelativeLayout rl_body, rl_profile;
    }

    @Override
    public View getView(final int position, View convertView, final ViewGroup parent) {

        final ViewHolder holder;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.lv_voting_item, parent, false);
            holder = new ViewHolder();
            holder.tv_uname = (TextView) convertView.findViewById(R.id.tv_uname);
            holder.rl_profile = (RelativeLayout) convertView.findViewById(R.id.rl_profile);
            holder.tv_udetails = (TextView) convertView.findViewById(R.id.tv_udetails);
            holder.iv_profile = (CircleImageView) convertView.findViewById(R.id.iv_profile);
            holder.rl_body = (RelativeLayout) convertView.findViewById(R.id.rl_body);

            convertView.setTag(holder);

        } else
            holder = (ViewHolder) convertView.getTag();
//        holder.tv_uname.setTypeface(objectBAJava.roboto_regular);
//        holder.tv_udetails.setTypeface(objectBAJava.roboto_regular);
//        holder.tv_uname.setTypeface(objectBAJava.roboto_bold);

        holder.tv_uname.setText(activitiesDataArray.get(position).gettitle());
        holder.tv_udetails.setText(activitiesDataArray.get(position).getshort_description());

//
//        Glide.with(context)
//                .load(R.drawable.profile_icon)
//                .placeholder(R.drawable.profile_icon)
//                .error(R.drawable.profile_icon)
//                .into(holder.iv_profile);

        fragment.Pagination(activitiesDataArray, position);

        holder.rl_body.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragment.goOnActivity(activitiesDataArray.get(position).getid());

            }
        });


        return convertView;
    }

}



