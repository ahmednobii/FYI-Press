package com.mersal.mersal.retrofit.notifications;

import com.google.gson.annotations.SerializedName;
import com.mersal.mersal.retrofit.invitations.Invitationsdata;


public class NotificatiionsResult {
    @SerializedName("status")
    private Boolean status = false;

    @SerializedName("message")
    private String message = "";

    @SerializedName("data")
    private Notificationsdata data;

    public Boolean getstatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public Notificationsdata getdata() {
        return data;
    }


}

//InvitationsResult