package com.mersal.mersal.retrofit.general;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Muhammad_Umar_Ch on 07/12/2017.
 */

public class Citiesdatasectors {

    @SerializedName("id")
    private String id = "";
    @SerializedName("name")
    private String name = "";
    @SerializedName("created_at")
    private String created_at = "";

    public String getid() {
        return id;
    }

    public String getname() {
        return name;
    }

    public String getcreated_at() {
        return created_at;
    }


}
