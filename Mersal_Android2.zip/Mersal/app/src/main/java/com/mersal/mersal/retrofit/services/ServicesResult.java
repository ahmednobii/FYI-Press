package com.mersal.mersal.retrofit.services;

import com.google.gson.annotations.SerializedName;
import com.mersal.mersal.retrofit.otp.Otpdata;

import java.util.ArrayList;


public class ServicesResult {
    @SerializedName("status")
    private Boolean status = false;

    @SerializedName("message")
    private String message = "";

    @SerializedName("data")
    private Servicesdata data;

    public Boolean getstatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public Servicesdata getdata() {
        return data;
    }


}