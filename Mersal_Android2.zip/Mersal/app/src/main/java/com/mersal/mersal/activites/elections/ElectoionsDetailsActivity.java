package com.mersal.mersal.activites.elections;

import android.graphics.PorterDuff;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.mersal.mersal.R;
import com.mersal.mersal.activites.base.BaseActivity;
import com.mersal.mersal.customviews.HeaderCustomTV;
import com.mersal.mersal.customviews.NoDataFoundCustomTV;
import com.mersal.mersal.generic.Interfaces.Generic;
import com.mersal.mersal.internetconnections.NetworkConnection;
import com.mersal.mersal.retrofit.electors.Electorsdataelectors;

import java.util.ArrayList;

import io.realm.Realm;

public class ElectoionsDetailsActivity extends BaseActivity {

    TextView tv_unamedet, tv_six, tv_uname, tv_tafaseel;
    HeaderCustomTV toolbar_title;
    ProgressBar spinner;
    RelativeLayout rl_body;
    Generic generic;
    String fromdetails = "", fromtitle = "";
    ImageView back_arrow, iv_profile;
    ArrayList<Electorsdataelectors> activitiesData = new ArrayList<>();
    public static ElectoionsDetailsActivity objElectoionsDetailsActivity;
    NetworkConnection ntobj = new NetworkConnection(ElectoionsDetailsActivity.this);
    NoDataFoundCustomTV tv_noresult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_election_details);

        if (ElectoionsDetailsActivity.this instanceof BaseActivity) {
            generic = (Generic) ElectoionsDetailsActivity.this;
        }
        generic.hideStatusBarForAuth();
        objElectoionsDetailsActivity = this;
        objectBAJava.hideKeyboard();

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            fromdetails = extras.getString("details");
            fromtitle = extras.getString("title");
        }
        init();
        clickListener();
    }

    public void init() {
        toolbar_title = (HeaderCustomTV) findViewById(R.id.toolbar_title);
        back_arrow = (ImageView) findViewById(R.id.back_arrow);
        toolbar_title.setText("تفاصيل التصويت");
        iv_profile = (ImageView) findViewById(R.id.iv_profile);
        tv_unamedet = (TextView) findViewById(R.id.tv_unamedet);
        tv_tafaseel = (TextView) findViewById(R.id.tv_tafaseel);
        tv_six = (TextView) findViewById(R.id.tv_six);
        tv_uname = (TextView) findViewById(R.id.tv_uname);
        rl_body = (RelativeLayout) findViewById(R.id.rl_body);
        tv_uname.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_six.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_unamedet.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_tafaseel.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_noresult = (NoDataFoundCustomTV) findViewById(R.id.tv_noresult);
        Realm.init(this);    //initialize to access database for this activity
        realm = Realm.getDefaultInstance();
        spinner = (ProgressBar) findViewById(R.id.progressBar);
        spinner.setVisibility(View.GONE);
        back_arrow.setVisibility(View.VISIBLE);
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT) {
            spinner.getIndeterminateDrawable().setColorFilter(getResources()
                    .getColor(R.color.progress_bar_color_white), PorterDuff.Mode.SRC_IN);

        }

        tv_six.setText(fromdetails);
        tv_tafaseel.setText(fromtitle);

    }

    public void clickListener() {
        back_arrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                objectBAJava.hideStatusBar();
                finish();
                generic.animEnd();

            }
        });

    }

}
