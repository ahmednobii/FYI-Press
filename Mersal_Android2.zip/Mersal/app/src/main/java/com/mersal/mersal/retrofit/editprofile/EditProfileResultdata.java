package com.mersal.mersal.retrofit.editprofile;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

/**
 * Created by Muhammad_Umar_Ch on 07/12/2017.
 */

public class EditProfileResultdata {


    @SerializedName("profile")
    private EditProfileResultdataProfile editProfileResultdataProfile;

    @SerializedName("services")
    private ArrayList<EditProfileServices> servicesdataServices;

    public ArrayList<EditProfileServices> getservicesdataServices() {

        return servicesdataServices;
    }

    public EditProfileResultdataProfile getEditProfileResultdataProfile() {

        return editProfileResultdataProfile;
    }

}