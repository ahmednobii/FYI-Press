package com.mersal.mersal.fcm;

import android.preference.PreferenceManager;

import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;

public class FirebaseIDService extends FirebaseInstanceIdService {
    private static final String TAG = "FirebaseIDService";

    @Override
    public void onTokenRefresh() {
        String refreshedToken = FirebaseInstanceId.getInstance().getToken();
        PreferenceManager.getDefaultSharedPreferences(FirebaseIDService.this).edit().putString("device_token", refreshedToken).apply();
        System.out.println("its device token " + refreshedToken);
    }
}
