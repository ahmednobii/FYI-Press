package com.mersal.mersal.retrofit.votinglist;

import com.google.gson.annotations.SerializedName;
import com.mersal.mersal.retrofit.general.Citiesdatasectors;

import java.util.ArrayList;

/**
 * Created by Muhammad_Umar_Ch on 07/12/2017.
 */

public class Votingdata {

    @SerializedName("elections")
    private VotingElections elections;

    public VotingElections getelections() {
        return elections;
    }


}
