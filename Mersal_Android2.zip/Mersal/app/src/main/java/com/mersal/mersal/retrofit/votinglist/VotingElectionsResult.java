package com.mersal.mersal.retrofit.votinglist;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

/**
 * Created by Muhammad_Umar_Ch on 07/12/2017.
 */

public class VotingElectionsResult {

    @SerializedName("counter")
    private int counter;
    @SerializedName("id")
    private String id = "";
    @SerializedName("title")
    private String title = "";
    @SerializedName("date")
    private String date = "";
    @SerializedName("short_description")
    private String short_description;

    public int getcounter() {

        return counter;
    }

    public String getid() {

        if (id == null) {
            return "";
        }
        return id;
    }

    public String gettitle() {
        if (title == null) {
            return "";
        }
        return title;
    }

    public String getdate() {
        if (date == null) {
            return "";
        }
        return date;
    }

    public String getshort_description() {
        if (short_description == null) {
            return "";
        }
        return short_description;
    }

}
