package com.mersal.mersal.retrofit.editprofile;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

/**
 * Created by Muhammad_Umar_Ch on 07/12/2017.
 */

public class EditProfileResultdataProfile {

    private String user_id = "";
    private String username = "";
    private String email = "";
    private String full_name = "";
    private String phone = "";
    private String dob = "";
    private String gender = "";
    private String last_name = "";
    private String family_name = "";
    private String blood_group = "";
    private String image_url = "";
    private boolean is_user_services = false;

    @SerializedName("services")
    private ArrayList<EditProfileServices> servicesdataServices;

    public ArrayList<EditProfileServices> getservicesdataServices() {

        return servicesdataServices;
    }


    public boolean getis_user_services() {

        return is_user_services;
    }


    public String getfamily_name() {
        if (family_name == null) {
            return "";
        }
        return family_name;
    }

    public String getblood_group() {
        if (blood_group == null) {
            return "";
        }
        return blood_group;
    }

    public String getimage_url() {
        if (image_url == null || image_url.equals("")) {
            return "https://";
        }
        return image_url;
    }

    public String getdob() {
        if (dob == null) {
            return "";
        }
        return dob;
    }

    public String getgender() {
        if (gender == null) {
            return "";
        }
        return gender;
    }

    public String getlast_name() {
        if (last_name == null) {
            return "";
        }
        return last_name;
    }

    public String getuser_id() {
        if (user_id == null) {
            return "";
        }
        return user_id;
    }

    public String getuser_name() {
        if (username == null) {
            return "";
        }
        return username;
    }

    public String getEmail() {
        if (email == null) {
            return "";
        }

        return email;
    }

    public String getfull_name() {
        if (full_name == null) {
            return "";
        }
        return full_name;
    }

    public String getphoneNumber() {
        if (phone == null) {
            return "";
        }
        return phone;
    }


}