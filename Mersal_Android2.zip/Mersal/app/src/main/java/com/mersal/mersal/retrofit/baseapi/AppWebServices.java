package com.mersal.mersal.retrofit.baseapi;

public interface AppWebServices {

    public static final String BASE_URL = "https://mersallwati.com/v1/";
    public static final String BASE_URL_FOR_OTP = "https://www.ismartsms.net/";
    public static final String OTP = "iBulkSMS/HttpWS/SMSDynamicAPI.aspx/";
    public static final String register = "auth/register";
    public static final String login = "auth/login";
    public static final String votinglist = "election/index";
    public static final String electorslist = "election/get_electors";
    public static final String electordetails = "election/get_elector";
    public static final String getprofile = "user/get_profile";
    public static final String saveprofile = "user/save_profile";
    public static final String addidcard = "user/add_id_card";
    public static final String services = "user/get_user_services";
    public static final String verifyphone = "auth/verify_phone";
    public static final String vote_elector = "election/vote_elector";
    public static final String logout = "auth/logout";
    public static final String forgetpassword = "password/forgot";
    public static final String forgetpasswordByPhone = "password/forgotbyphone";
    public static final String resetpassword = "password/reset";
    public static final String resetpasswordbyphone = "password/resetbyphone";
    public static final String changepassword = "user/change_password";
    public static final String invitation = "invitation/get_invitations";
    public static final String notification = "notification/get_notifications";
    public static final String update_device = "user/update_device";
    public static final String phonenumber = "auth/validate_phone_number";
    public static final String validate_user = "auth/validate_user";
    public static final String check_id_number = "general/check_id_number";
    public static final String saveservicesForReg = "user/save_user_services";
}