package com.mersal.mersal.retrofit.baseapi;


import com.mersal.mersal.retrofit.Login.LoginResult;
import com.mersal.mersal.retrofit.defualt.DefaultResult;
import com.mersal.mersal.retrofit.editprofile.EditProfileResult;
import com.mersal.mersal.retrofit.electors.ElectorsResult;
import com.mersal.mersal.retrofit.electorsdetails.ElectorDetailsResult;
import com.mersal.mersal.retrofit.invitations.InvitationsResult;
import com.mersal.mersal.retrofit.notifications.NotificatiionsResult;
import com.mersal.mersal.retrofit.otp.OtpResult;
import com.mersal.mersal.retrofit.services.ServicesResult;
import com.mersal.mersal.retrofit.signup.SignUpResult;
import com.mersal.mersal.retrofit.votinglist.VotingResult;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.Map;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface ApiService {

//    @FormUrlEncoded
//    @POST(AppWebServices.register)
//    Call<DefaultResult> register(@FieldMap Map<String, String> params);

    // Sign up
    @FormUrlEncoded
    @POST(AppWebServices.register)
    Call<SignUpResult> register(
            @Field("username") String username,
            @Field("first_name") String first_name,
            @Field("last_name") String last_name,
            @Field("phone") String phone,
            @Field("password") String password,
            @Field("confirm_password") String confirm_password,
            @Field("gender") String gender,
            @Field("blood_group") String blood_group,
            @Field("family_name") String family_name,
            @Field("dob") String dob,
            @Field("email") String email,
            @Field("services[]") ArrayList<String> services,
            @Field("device_type") String device_type,
            @Field("user_agent") String user_agent,
            @Field("platform") String platform);

    @FormUrlEncoded
    @POST(AppWebServices.register)
    Call<SignUpResult> registernew(
            @Field("username") String username,
            @Field("full_name") String full_name,
            @Field("phone") String phone,
            @Field("password") String password,
            @Field("confirm_password") String confirm_password,
            @Field("gender") String gender,
            @Field("blood_group") String blood_group,
            @Field("id_dob") String dob,
            @Field("email") String email,
            @Field("id_front") String id_front,
            @Field("id_front_ext") String id_front_ext,
            @Field("id_back") String id_back,
            @Field("id_back_ext") String id_back_ext,
            @Field("id_name") String id_name,
            @Field("id_expiry_date") String id_expiry_date,
            @Field("id_number") String id_number,
            @Field("device_type") String device_type,
            @Field("user_agent") String user_agent,
            @Field("platform") String platform);

    @FormUrlEncoded
    @POST(AppWebServices.saveprofile)
    Call<DefaultResult> saveprofile(
            @Field("auth_token") String auth_token,
            @Field("full_name") String first_name,
            @Field("email") String email,
            @Field("phone") String phone,
            @Field("blood_group") String blood_group,
            @Field("dob") String dob,
            @Field("image") String image,
            @Field("image_ext") String image_ext,
            @Field("device_type") String device_type,
            @Field("user_agent") String user_agent,
            @Field("platform") String platform);

    @FormUrlEncoded
    @POST(AppWebServices.saveprofile)
    Call<DefaultResult> saveprofileFeatures(
            @Field("auth_token") String auth_token,
            @Field("full_name") String first_name,
            @Field("email") String email,
            @Field("phone") String phone,
            @Field("blood_group") String blood_group,
            @Field("dob") String dob,
            @Field("device_type") String device_type,
            @Field("user_agent") String user_agent,
            @Field("platform") String platform);


    @FormUrlEncoded
    @POST(AppWebServices.vote_elector)
    Call<DefaultResult> vote_elector(
            @Field("auth_token") String auth_token,
            @Field("election_id") String election_id,
            @Field("elector_ids[]") ArrayList<String> elector_ids,
            @Field("device_type") String device_type,
            @Field("user_agent") String user_agent,
            @Field("platform") String platform);


    @FormUrlEncoded
    @POST(AppWebServices.saveservicesForReg)
    Call<DefaultResult> saveservicesForReg(
            @Field("auth_token") String auth_token,
            @Field("user_services") JSONArray user_services);

    @FormUrlEncoded
    @POST(AppWebServices.services)
    Call<ServicesResult> services(@FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST(AppWebServices.update_device)
    Call<DefaultResult> update_device(@FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST(AppWebServices.phonenumber)
    Call<DefaultResult> phonenumber(@FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST(AppWebServices.check_id_number)
    Call<DefaultResult> check_id_number(@FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST(AppWebServices.validate_user)
    Call<DefaultResult> validate_user(@FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST(AppWebServices.addidcard)
    Call<DefaultResult> addidcard(@FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST(AppWebServices.forgetpassword)
    Call<DefaultResult> forgetpassword(@FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST(AppWebServices.forgetpasswordByPhone)
    Call<DefaultResult> forgetpasswordByPhone(@FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST(AppWebServices.resetpassword)
    Call<DefaultResult> resetpassword(@FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST(AppWebServices.resetpasswordbyphone)
    Call<DefaultResult> resetpasswordbyphone(@FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST(AppWebServices.changepassword)
    Call<DefaultResult> changepassword(@FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST(AppWebServices.logout)
    Call<DefaultResult> logout(@FieldMap Map<String, String> params);

//    @FormUrlEncoded
//    @POST(AppWebServices.vote_elector)
//    Call<DefaultResult> vote_elector(@FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST(AppWebServices.verifyphone)
    Call<OtpResult> verifyphone(@FieldMap Map<String, String> params);

//    @FormUrlEncoded
//    @POST(AppWebServices.saveprofile)
//    Call<DefaultResult> saveprofile(@FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST(AppWebServices.getprofile)
    Call<EditProfileResult> getprofile(@FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST(AppWebServices.login)
    Call<LoginResult> login(@FieldMap Map<String, String> params);


    @FormUrlEncoded
    @POST(AppWebServices.OTP)
    Call<String> OTP(@FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST(AppWebServices.votinglist)
    Call<VotingResult> votinglist(@FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST(AppWebServices.electorslist)
    Call<ElectorsResult> electorslist(@FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST(AppWebServices.electordetails)
    Call<ElectorDetailsResult> electordetails(@FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST(AppWebServices.invitation)
    Call<InvitationsResult> invitation(@FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST(AppWebServices.notification)
    Call<NotificatiionsResult> notification(@FieldMap Map<String, String> params);
}
