package com.mersal.mersal.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.mersal.mersal.R;
import com.mersal.mersal.fragment.ElectorsFragment;
import com.mersal.mersal.fragment.InvitationsFragment;
import com.mersal.mersal.retrofit.electors.Electorsdataelectors;
import com.mersal.mersal.retrofit.invitations.InvitationsDataInvitations;
import com.mersal.mersal.retrofit.invitations.InvitationsDataInvitationsGallery;
import com.mersal.mersal.retrofit.notifications.NotificationsDatanotifications;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Collections;

import de.hdodenhof.circleimageview.CircleImageView;
import jp.wasabeef.picasso.transformations.CropCircleTransformation;

import static com.mersal.mersal.activites.base.BaseActivity.objectBAJava;


public class InvitationsLvAdapter extends ArrayAdapter<String> {
    private final Context context;
    ArrayList<InvitationsDataInvitations> activitiesDataArray = new ArrayList<>();
    ArrayList<NotificationsDatanotifications> notificationsactivitiesDataArray = new ArrayList<>();
    LayoutInflater inflater = null;
    InvitationsFragment fragment;
    boolean isNotificationsTab = true;

    public InvitationsLvAdapter(Context context, ArrayList<InvitationsDataInvitations> activitiesDataArray, ArrayList<NotificationsDatanotifications> notificationsactivitiesDataArray, InvitationsFragment fragment_, boolean isNotificationsTab) {
        super(context, R.layout.lv_invitations_item);
        this.context = context;
        this.fragment = fragment_;
        this.isNotificationsTab = isNotificationsTab;
        this.activitiesDataArray = activitiesDataArray;
        Collections.reverse(notificationsactivitiesDataArray);
        Collections.reverse(activitiesDataArray);
        this.notificationsactivitiesDataArray = notificationsactivitiesDataArray;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        if (isNotificationsTab) {
            return notificationsactivitiesDataArray.size();
        } else
            return activitiesDataArray.size();
    }

    private class ViewHolder {
        TextView tv_fmname_title;
        com.mersal.mersal.utilties.RoundRectCornerImageView iv_image;
        RelativeLayout rl_body, rl_eight;
    }

    @Override
    public View getView(final int position, View convertView, final ViewGroup parent) {

        final ViewHolder holder;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.lv_invitations_item, parent, false);
            holder = new ViewHolder();
            holder.tv_fmname_title = (TextView) convertView.findViewById(R.id.tv_fmname_title);
            holder.iv_image = (com.mersal.mersal.utilties.RoundRectCornerImageView) convertView.findViewById(R.id.iv_image);
            holder.rl_body = (RelativeLayout) convertView.findViewById(R.id.rl_body);
            holder.rl_eight = (RelativeLayout) convertView.findViewById(R.id.rl_eight);

            convertView.setTag(holder);

        } else
            holder = (ViewHolder) convertView.getTag();
//        holder.tv_fmname_title.setTypeface(objectBAJava.roboto_regular);
//        holder.tv_udetails.setTypeface(objectBAJava.roboto_regular);
        holder.tv_fmname_title.setTypeface(objectBAJava.Tahoma_Regular_font);

        if (isNotificationsTab) {

            if (notificationsactivitiesDataArray.size() > 0) {
                holder.tv_fmname_title.setText(notificationsactivitiesDataArray.get(position).gettitle() + "\n \n" + notificationsactivitiesDataArray.get(position).gettext());
                holder.iv_image.setVisibility(View.GONE);
                holder.rl_eight.setVisibility(View.GONE);
            }
        } else {

            if (activitiesDataArray.size() > 0) {
                if (activitiesDataArray.get(position).getgallery() != null) {
                    holder.tv_fmname_title.setText(activitiesDataArray.get(position).gettitle());

//                Glide.with(context)
//                        .load(activitiesDataArray.get(position).getgallery().getimage_path())
//                        .override(600, 200) // resizes the image to these dimensions (in pixel). resize does not respect aspect ratio
//                        .placeholder(R.drawable.no_image_available)
//                        .error(R.drawable.no_image_available)
//                        .into(holder.iv_image);
                    Picasso.get()
                            .load(activitiesDataArray.get(position).getgallery().getimage_path())
                            .resize(600, 200)
                            .placeholder(R.drawable.no_image_available)
                            .error(R.drawable.no_image_available)
                            .into(holder.iv_image);

                } else {
                    holder.rl_body.setVisibility(View.GONE);
                }

            } else {
               // holder.rl_body.setVisibility(View.GONE);
            }

        }

//        holder.rl_body.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//
//            }
//        });

        holder.iv_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                fragment.showWorkPictures(activitiesDataArray.get(position).getgallery().getimage_path());

            }
        });

        return convertView;
    }

}



