
package com.mersal.mersal.retrofit.editprofile;


import com.google.gson.annotations.SerializedName;
import com.mersal.mersal.retrofit.Login.LoginResultdata;
import com.mersal.mersal.retrofit.services.ServicesdataServices;

import java.util.ArrayList;

public class EditProfileResult {
    @SerializedName("status")
    private Boolean status = false;

    @SerializedName("message")
    private String message = "";

    @SerializedName("data")
    private EditProfileResultdata EditProfileResultdata;

    public Boolean getstatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public EditProfileResultdata getdata() {
        return EditProfileResultdata;
    }

}