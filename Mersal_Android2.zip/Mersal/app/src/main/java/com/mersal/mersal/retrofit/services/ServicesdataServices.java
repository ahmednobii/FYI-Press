package com.mersal.mersal.retrofit.services;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Muhammad_Umar_Ch on 07/12/2017.
 */

public class ServicesdataServices {

    @SerializedName("id")
    private String id;

    @SerializedName("title")
    private String title;

    @SerializedName("status")
    private String status;

    public String getstatus() {

        if (status == null) {
            return status = "";
        }
        return status;
    }

    public String gettitle() {

        if (title == null) {
            return title = "";
        }
        return title;
    }

    public String getid() {

        if (id == null) {
            return id = "";
        }
        return id;
    }

    private Boolean statusforinapp = false;

    public Boolean getstatusinapp() {
        return statusforinapp;
    }

    public void setstatusinapp(boolean statusforinapp_) {

        statusforinapp = statusforinapp_;
    }


    public void setid(String value_) {

        id = value_;
    }

    public void settitle(String value_) {

        title = value_;
    }

    public void setstatus(String value_) {

        status = value_;
    }

}
