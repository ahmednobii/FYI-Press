package com.mersal.mersal.activites.registerdocuments;

import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.ml.vision.FirebaseVision;
import com.google.firebase.ml.vision.common.FirebaseVisionImage;
import com.google.firebase.ml.vision.text.FirebaseVisionText;
import com.google.firebase.ml.vision.text.FirebaseVisionTextRecognizer;
import com.mersal.mersal.R;
import com.mersal.mersal.activites.base.BaseActivity;
import com.mersal.mersal.customviews.HeaderCustomTV;
import com.mersal.mersal.customviews.NoDataFoundCustomTV;
import com.mersal.mersal.generic.Interfaces.Generic;
import com.mersal.mersal.internetconnections.NetworkConnection;
import com.mersal.mersal.retrofit.baseapi.ApiService;
import com.mersal.mersal.retrofit.baseapi.AppWebServices;
import com.mersal.mersal.retrofit.defualt.DefaultResult;
import com.theartofdev.edmodo.cropper.CropImage;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static com.mersal.mersal.utilties.RealPathUtil.realPathUtil;
import static com.mersal.mersal.utilties.StaticStrings.ISFROMREGISTERID;

public class RegisterVoteWithScanActivity extends BaseActivity {

    TextView tv_takepic, tv_back_name, tv_front_civil, tv_front_dob, tv_already, tv_front_expdt, tv_submit;
    RelativeLayout rl_submit, rl_body, header_left_rl;
    String st_email = "";
    ImageView iv_idpic, iv_idpicback;
    ProgressBar progressBar;
    NoDataFoundCustomTV tv_noresult;
    public static RegisterVoteWithScanActivity OtpRegisterVoteActivity;
    NetworkConnection ntobj = new NetworkConnection(RegisterVoteWithScanActivity.this);
    Generic generic;
    ImageView back_arrow;
    HeaderCustomTV toolbar_title;
    private static final int CAMERA_REQUEST_FRONT = 1888;
    private static final int CAMERA_REQUEST_BACK = 1000;
    Bitmap companyavatar_FRONT, companyavatar_BACK;
    String docimageencode_FRONT = "", docimageencode_BACK = "", avatar_FRONT = "", avatar_BACK = "";
    ProgressBar spinner;
    Uri imageUri, imageUriBack;
    File file, fileBack;
    String civil_number = "", expiry_date = "", date_of_birth = "", back_name = "";
    Uri imageUriForCrop;
    boolean isClickForNext = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_vote_scan);

        ISFROMREGISTERID = true;
        if (RegisterVoteWithScanActivity.this instanceof BaseActivity) {
            generic = (Generic) RegisterVoteWithScanActivity.this;
        }
        generic.hideStatusBarForAuth();
        OtpRegisterVoteActivity = this;

        init();
        clickListener();
        objectBAJava.hideKeyboard();
    }

    public void init() {
        header_left_rl = (RelativeLayout) findViewById(R.id.header_left_rl);
        iv_idpic = (ImageView) findViewById(R.id.iv_idpic);
        iv_idpicback = (ImageView) findViewById(R.id.iv_idpicback);
        tv_takepic = (TextView) findViewById(R.id.tv_takepic);
        tv_already = (TextView) findViewById(R.id.tv_already);
        tv_front_expdt = (TextView) findViewById(R.id.tv_front_expdt);
        tv_front_civil = (TextView) findViewById(R.id.tv_front_civil);
        tv_back_name = (TextView) findViewById(R.id.tv_back_name);
        tv_front_dob = (TextView) findViewById(R.id.tv_front_dob);
        tv_submit = (TextView) findViewById(R.id.tv_submit);
        rl_submit = (RelativeLayout) findViewById(R.id.rl_submit);
        rl_body = (RelativeLayout) findViewById(R.id.rl_body);
        tv_takepic.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_front_dob.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_submit.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_front_civil.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_front_expdt.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_back_name.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_noresult = (NoDataFoundCustomTV) findViewById(R.id.tv_noresult);
        spinner = (ProgressBar) findViewById(R.id.progressBar);
        toolbar_title = (HeaderCustomTV) findViewById(R.id.toolbar_title);
        back_arrow = (ImageView) findViewById(R.id.back_arrow);
        toolbar_title.setText("إنشاء حساب");
        back_arrow.setVisibility(View.VISIBLE);

        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        progressBar.setVisibility(View.GONE);

        tv_front_civil.setVisibility(View.GONE);
        tv_front_dob.setVisibility(View.GONE);
        tv_front_expdt.setVisibility(View.GONE);
        tv_back_name.setVisibility(View.GONE);


        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT) {
            progressBar.getIndeterminateDrawable().setColorFilter(getResources()
                    .getColor(R.color.progress_bar_color_white), PorterDuff.Mode.SRC_IN);
        }
    }

    public void clickListener() {
        rl_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

//                objectBAJava.hideStatusBar();
//                Intent mainIntent = new Intent(RegisterVoteActivity.this, SignUpActivity.class);
//                startActivity(mainIntent);
//                overridePendingTransition(R.anim.start_slide_in_left, R.anim.start_slide_out_left);
//                objectBAJava.hideStatusBar();

                if (isClickForNext) {

                } else {
                    isClickForNext = true;
                    velidation();
                }

            }
        });

        back_arrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                objectBAJava.hideKeyboard();
                objectBAJava.hideProgressBar(spinner);
                finish();
                animEnd();

            }
        });

        iv_idpic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (AskForPermissions()) {

                    takePic();


//                    Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
//                    startActivityForResult(cameraIntent, CAMERA_REQUEST_FRONT);
                }


            }
        });

        iv_idpicback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (AskForPermissions()) {
                    takeBackPic();
//                    Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
//                    startActivityForResult(cameraIntent, CAMERA_REQUEST_BACK);
                }
            }
        });

    }

    public void velidation() {

        if (docimageencode_FRONT.equals("")) {
            isClickForNext = false;
            generic.showSnackbar(rl_body, "مطلوب بطاقة الهوية الجبهة بيك", Snackbar.LENGTH_LONG, "close", false);
        } else if (docimageencode_BACK.equals("")) {
            isClickForNext = false;

            generic.showSnackbar(rl_body, "مطلوب بطاقة الهوية مرة أخرى بيك", Snackbar.LENGTH_LONG, "close", false);
        } else if (civil_number.equals("")) {
            isClickForNext = false;

            generic.showSnackbar(rl_body, "الرقم المدني غير صحيح ، امسح بطاقتك مرة أخرى", Snackbar.LENGTH_LONG, "close", false);
        } else if (expiry_date.equals("")) {
            isClickForNext = false;

            generic.showSnackbar(rl_body, "تاريخ انتهاء الصلاحية غير مناسب ، امسح بطاقتك مرة أخرى", Snackbar.LENGTH_LONG, "close", false);
        } else if (date_of_birth.equals("")) {
            isClickForNext = false;

            generic.showSnackbar(rl_body, "تاريخ الميلاد غير مناسب ، امسح بطاقتك مرة أخرى", Snackbar.LENGTH_LONG, "close", false);
        } else if (back_name.equals("")) {
            isClickForNext = false;

            generic.showSnackbar(rl_body, "الاسم غير مناسب ، امسح بطاقتك مرة أخرى", Snackbar.LENGTH_LONG, "close", false);
        } else {
            if (ntobj.isConnectingToInternet()) {
                objectBAJava.hideKeyboard();
                apiCallUploadDocuments();
            } else {
                isClickForNext = false;

                String Message = PreferenceManager.getDefaultSharedPreferences(RegisterVoteWithScanActivity.this).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
                generic.showSnackbar(rl_body, Message, Snackbar.LENGTH_LONG, "close", false);
            }
        }
    }

    public void apiCallUploadDocuments() {
        tv_noresult.setVisibility(View.GONE);
        generic.showProgressBar(spinner);
        Map<String, String> params = generic.setBasicParams();
        params.put("auth_token", generic.getAuthTockenFromDb());
        params.put("id_FRONT_ext", "jpg");
        params.put("id_back_ext", "jpg");
        params.put("name", back_name);
        params.put("dob", date_of_birth);
        params.put("expiry_date", expiry_date);
        params.put("id_number", civil_number);

        if (!docimageencode_FRONT.equals("")) {
            params.put("id_front", "data:image/jpeg;base64," + docimageencode_FRONT);
        }

        if (!docimageencode_BACK.equals("")) {
            params.put("id_back", "data:image/jpeg;base64," + docimageencode_BACK);
        }

        OkHttpClient client = generic.setHeaderForReqs().build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(AppWebServices.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();

        ApiService service = retrofit.create(ApiService.class);
        Call<DefaultResult> call = service.addidcard(params);
        call.enqueue(new Callback<DefaultResult>() {

            @Override
            public void onResponse(Call<DefaultResult> call, retrofit2.Response<DefaultResult> response) {

//                reqIsInProgress = false;
                if (response.code() == 200) {

                    Boolean status = response.body().getstatus();
                    String Message = response.body().getMessage();

                    if (status) {

                        generic.hideProgressBar(spinner);
                        generic.showSnackbar(tv_noresult, Message, Snackbar.LENGTH_LONG, "close", true);
                        finish();
                        animEnd();

                    } else {
                        isClickForNext = false;

                        generic.showSnackbar(tv_noresult, Message, Snackbar.LENGTH_LONG, "close", false);
                    }

                } else {
                    isClickForNext = false;

                    generic.hideProgressBar(spinner);
                    try {

//                        spinner.setVisibility(View.GONE);
                        generic.hideProgressBar(spinner);

                        String userMessage = PreferenceManager.getDefaultSharedPreferences(RegisterVoteWithScanActivity.this).getString("oops", "هناك خطأ ما");
                        JSONObject jObjError = new JSONObject(response.errorBody().string());
                        try {
                            userMessage = jObjError.getString("message");
                        } catch (Exception e) {
                        }

                        String dataArrayMessage = "";
                        try {
                            JSONArray jsonArray = jObjError.getJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                dataArrayMessage = dataArrayMessage + jsonArray.getString(i) + "\n";
                            }

                        } catch (Exception e) {
                        }


                        String maintenanceBtnText = "Try Again";
                        try {
                            maintenanceBtnText = jObjError.optString("btn_text");
                        } catch (Exception e) {
                        }

                        generic.genericCodes(rl_body, response.code(), userMessage, dataArrayMessage, maintenanceBtnText);

                    } catch (Exception e) {

//                        spinner.setVisibility(View.GONE);
                        generic.hideProgressBar(spinner);

                        Snackbar snackbar = Snackbar.make(rl_body, PreferenceManager.getDefaultSharedPreferences(RegisterVoteWithScanActivity.this).getString("oops", "هناك خطأ ما"), Snackbar.LENGTH_LONG);
                        snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
                        snackbar.show();

                    }
                }
            }

            @Override
            public void onFailure(Call<DefaultResult> call, Throwable t) {
//                spinner.setVisibility(View.GONE);
                generic.hideProgressBar(spinner);
                isClickForNext = false;

                Snackbar snackbar = Snackbar.make(rl_body, PreferenceManager.getDefaultSharedPreferences(RegisterVoteWithScanActivity.this).getString("oops", "هناك خطأ ما"), Snackbar.LENGTH_LONG);
                snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
                snackbar.show();
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 100: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.

                } else {
                    AskForPermissions();
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.);
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Bitmap photo = null;
        Bitmap photoBack = null;

        if (requestCode == CAMERA_REQUEST_FRONT && resultCode == Activity.RESULT_OK) {

            try {
                String[] filePathColumn = {MediaStore.Images.Media.DATA};
                Cursor cursor = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, filePathColumn, null, null, null);
                if (cursor == null)
                    return;
                // find the file in the media area
                cursor.moveToLast();
                int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                String filePath = "file:///" + cursor.getString(columnIndex);
                cursor.close();
                photo = uriToBitmap(this, Uri.parse(filePath));
                //  setImageInProfile(photo);
                // CALL THIS METHOD TO GET THE URI FROM THE BITMAP
                Uri tempUri = getImageUri(RegisterVoteWithScanActivity.this, photo);
                // CALL THIS METHOD TO GET THE ACTUAL PATH
                File finalFile = new File(getRealPathFromURI(tempUri));
                convertiInToBase64(finalFile, tempUri);
                imageUriForCrop = tempUri;
//                performCrop(1, tempUri);

                Intent intent = CropImage.activity(tempUri)
                        .getIntent(RegisterVoteWithScanActivity.this);
                startActivityForResult(intent, 1);

            } catch (Exception e) {
                e.printStackTrace();
            }


        } else if (requestCode == 1) {

//            try {
//                if (android.os.Build.VERSION.SDK_INT <= Build.VERSION_CODES.N_MR1) {
//
//                    Bundle extras = data.getExtras();
//                    photo = extras.getParcelable("data");
//
//                } else {
//
//                    Uri extras = data.getData();
//                    String filePath = "file:///" + getRealPathFromUri(this, extras);
//                    photo = uriToBitmap(this, Uri.parse(filePath));
//
//                }
//                // get the returned data
////                Bundle extras = data.getExtras();
////                // get the cropped bitmap
////                photo = extras.getParcelable("data");
//                setImageInProfile(photo);
//                // CALL THIS METHOD TO GET THE URI FROM THE BITMAP
//                Uri tempUri = getImageUri(RegisterVoteWithScanActivity.this, photo);
//                // CALL THIS METHOD TO GET THE ACTUAL PATH
//                File finalFile = new File(getRealPathFromURI(tempUri));
//                convertiInToBase64(finalFile, tempUri);
//
//                //     performCrop(1, tempUri);
//
//            } catch (Exception e) {
//                e.printStackTrace();
//            }

            try {
                CropImage.ActivityResult result = CropImage.getActivityResult(data);

                if (resultCode == RESULT_OK) {
                    Uri resultUri = result.getUri();
                    iv_idpic.setImageURI(resultUri);
                    iv_idpic.buildDrawingCache();
                    photo = iv_idpic.getDrawingCache();
                    setImageInProfile(photo);
                    Uri tempUri = getImageUri(RegisterVoteWithScanActivity.this, photo);
                    File finalFile = new File(getRealPathFromURI(tempUri));
                    convertiInToBase64(finalFile, tempUri);


                } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                    Exception error = result.getError();
                }

            } catch (Exception e) {
                e.printStackTrace();
            }

        } else if (requestCode == CAMERA_REQUEST_BACK && resultCode == Activity.RESULT_OK) {

            try {
                String[] filePathColumn = {MediaStore.Images.Media.DATA};
                Cursor cursor = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, filePathColumn, null, null, null);
                if (cursor == null)
                    return;
                // find the file in the media area
                cursor.moveToLast();
                int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                String filePath = "file:///" + cursor.getString(columnIndex);
                cursor.close();
                photoBack = uriToBitmapBack(this, Uri.parse(filePath));
                // setImageInProfile_BACK(photoBack);
                Uri tempUriBack = getImageUri(RegisterVoteWithScanActivity.this, photoBack);
                File finalFileBack = new File(getRealPathFromURI(tempUriBack));
                convertiInToBase64_BACK(finalFileBack, tempUriBack);

                // performCrop(2, tempUriBack);

//                CropImage.activity(tempUriBack)
//                        .start(this);

                Intent intent = CropImage.activity(tempUriBack)
                        .getIntent(RegisterVoteWithScanActivity.this);
                startActivityForResult(intent, 2);

            } catch (Exception e) {
                e.printStackTrace();
            }

        } else if (requestCode == 2) {

            try {
                CropImage.ActivityResult result = CropImage.getActivityResult(data);
                if (resultCode == RESULT_OK) {
                    Uri resultUri = result.getUri();
                    iv_idpicback.setImageURI(resultUri);
                    iv_idpicback.buildDrawingCache();
                    photoBack = iv_idpicback.getDrawingCache();
                    setImageInProfile_BACK(photoBack);
                    Uri tempUriBack = getImageUri(RegisterVoteWithScanActivity.this, photoBack);
                    File finalFileBack = new File(getRealPathFromURI(tempUriBack));
                    convertiInToBase64_BACK(finalFileBack, tempUriBack);
                } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                    Exception error = result.getError();
                }

            } catch (Exception e) {
                e.printStackTrace();
            }

        } else {
            generic.showSnackbar(rl_body, "لم تقم باختيار الصورة", Snackbar.LENGTH_LONG, "close", false);
        }

    }

    public void setImageInProfile(Bitmap photo) {
//        iv_idpic.setImageBitmap(photo);
        companyavatar_FRONT = photo;
        avatar_FRONT = String.valueOf(photo);

        FirebaseVisionImage image = FirebaseVisionImage.fromBitmap(photo);
        FirebaseVisionTextRecognizer recognizer = FirebaseVision.getInstance().getOnDeviceTextRecognizer();

        recognizer.processImage(image).addOnSuccessListener(
                new OnSuccessListener<FirebaseVisionText>() {
                    @Override
                    public void onSuccess(FirebaseVisionText texts) {
                        processTextRecognitionResultFron(texts);
                    }
                })
                .addOnFailureListener(
                        new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                // Task failed with an exception
                                e.printStackTrace();
                            }
                        });

    }

    private void processTextRecognitionResultFron(FirebaseVisionText texts) {
        List<FirebaseVisionText.TextBlock> blocks = texts.getTextBlocks();
        //   showToast(rl_body, "Text is = " + texts.getText(), Toast.LENGTH_SHORT, RegisterVoteWithScanActivity.this);
        String text = texts.getText();
        String linese[] = text.split("\\r?\\n");
        if (linese.length == 0) {
            showToast(rl_body, "No text found", Toast.LENGTH_SHORT, RegisterVoteWithScanActivity.this);
            return;
        } else {
            for (int i = 0; i < linese.length; i++) {

                if (linese[i].contains("IDENTITY CARD") || linese[i].contains("RESIDENT CARD") || linese[i].contains("CARD")) {
                    try {
                        civil_number = linese[i + 1];
                        expiry_date = linese[i + 2];
                        date_of_birth = linese[i + 3];
//                        civil_number = "74787467";
//                        expiry_date = "03/11/2017";
//                        date_of_birth = "14/09/1978";

                        civil_number = civil_number.replaceAll("\\D+", "");
//                        expiry_date = expiry_date.replaceAll("\\D+", "");
//                        date_of_birth = date_of_birth.replaceAll("\\D+", "");
                        tv_front_expdt.setText("تاريخ الإنتهاء: " + expiry_date);
                        tv_front_civil.setText("الرقم المدني: " + civil_number);
                        tv_front_dob.setText("تاريخ الميلاد: " + date_of_birth);

                        tv_front_civil.setVisibility(View.VISIBLE);
                        tv_front_dob.setVisibility(View.VISIBLE);
                        tv_front_expdt.setVisibility(View.VISIBLE);

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }

//            Expiry date >>> تاريخ الانتهاء
//            Date of birth >>> تاريخ الميلاد
//            Civil number >>> الرقم المدني

        }
//        for (int i = 0; i < blocks.size(); i++) {
//            List<FirebaseVisionText.Line> lines = blocks.get(i).getLines();
//            for (int j = 0; j < lines.size(); j++) {
//                List<FirebaseVisionText.Element> elements = lines.get(j).getElements();
//                for (int k = 0; k < elements.size(); k++) {
//                    //  showToast(rl_body, "Text is = " + elements.get(k).getText(), Toast.LENGTH_SHORT, RegisterVoteWithScanActivity.this);
//
//
//                        // showToast(rl_body, "date_of_birth is = " + date_of_birth, Toast.LENGTH_SHORT, RegisterVoteWithScanActivity.this);
//
//
//                        //   showToast(rl_body, "Text is = " + elements.get(k).getText(), Toast.LENGTH_SHORT, RegisterVoteWithScanActivity.this);
//
//
//
//
//                }
//            }
//        }

//        showToast("No face Text" + texts.getText());

    }

    private void processTextRecognitionResultBack(FirebaseVisionText texts) {
        List<FirebaseVisionText.TextBlock> blocks = texts.getTextBlocks();
        // showToast(rl_body, "Text is = " + texts.getText(), Toast.LENGTH_SHORT, RegisterVoteWithScanActivity.this);
        String text = texts.getText();
        String linese[] = text.split("\\r?\\n");
        if (linese.length == 0) {
            showToast(rl_body, "No text found", Toast.LENGTH_SHORT, RegisterVoteWithScanActivity.this);
            return;
        } else {
            for (int i = 0; i < linese.length; i++) {

//                if (linese[i].contains("NAME")) {
//                    try {
//                        back_name = linese[i];
//                        String[] separated = back_name.split("NAME");
//                        back_name = separated[1].trim();
//                        tv_back_name.setText("الإسم: " + back_name);
//                        tv_back_name.setVisibility(View.VISIBLE);
//
//                    } catch (Exception e) {
//                        e.printStackTrace();
//                    }
//                }
                if (linese[i].contains("NAME")) {
                    try {
                        back_name = linese[i];
                        String[] separated = back_name.split("NAME");
                        back_name = separated[1].trim();
                        if (linese.length > i + 1) {
                            if (linese[i + 1].contains("<")) {
                                tv_back_name.setText("الإسم: " + back_name);

                            } else {
                                back_name = back_name + " " + linese[i + 1];
                                tv_back_name.setText("الإسم: " + back_name);
                            }
                            tv_back_name.setVisibility(View.VISIBLE);
                        }
                        System.out.println("here is Back NAME : " + back_name);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
//            Expiry date >>> تاريخ الانتهاء
//            Date of birth >>> تاريخ الميلاد
//            Civil number >>> الرقم المدني

        }
//        for (int i = 0; i < blocks.size(); i++) {
//            List<FirebaseVisionText.Line> lines = blocks.get(i).getLines();
//            for (int j = 0; j < lines.size(); j++) {
//                List<FirebaseVisionText.Element> elements = lines.get(j).getElements();
//                for (int k = 0; k < elements.size(); k++) {
//                    //  showToast(rl_body, "Text is = " + elements.get(k).getText(), Toast.LENGTH_SHORT, RegisterVoteWithScanActivity.this);
//
//
//                        // showToast(rl_body, "date_of_birth is = " + date_of_birth, Toast.LENGTH_SHORT, RegisterVoteWithScanActivity.this);
//
//
//                        //   showToast(rl_body, "Text is = " + elements.get(k).getText(), Toast.LENGTH_SHORT, RegisterVoteWithScanActivity.this);
//
//
//
//
//                }
//            }
//        }

//        showToast("No face Text" + texts.getText());

    }

    public void setImageInProfile_BACK(Bitmap photo_) {
//        iv_idpicback.setImageBitmap(photo_);
        companyavatar_BACK = photo_;
        avatar_BACK = String.valueOf(photo_);

        FirebaseVisionImage image = FirebaseVisionImage.fromBitmap(photo_);
        FirebaseVisionTextRecognizer recognizer = FirebaseVision.getInstance().getOnDeviceTextRecognizer();
        recognizer.processImage(image).addOnSuccessListener(
                new OnSuccessListener<FirebaseVisionText>() {
                    @Override
                    public void onSuccess(FirebaseVisionText texts) {
                        processTextRecognitionResultBack(texts);
                    }
                })
                .addOnFailureListener(
                        new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                // Task failed with an exception
                                e.printStackTrace();
                            }
                        });

    }

    public void convertiInToBase64(File path, Uri tempUri) {
//        Bitmap bm = BitmapFactory.decodeFile(String.valueOf(path));

        Bitmap bms = null;
        try {
            bms = BitmapFactory.decodeStream(getContentResolver().openInputStream(tempUri));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
//        Bitmap bm = Bitmap.createScaledBitmap(bms, 1080, 1920, false);


        Bitmap bm = Bitmap.createScaledBitmap(bms, 937, 576, false);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.JPEG, 100, baos); //bm is the bitmap object
        byte[] byteArrayImage = baos.toByteArray();
        String encodedImage = Base64.encodeToString(byteArrayImage, Base64.DEFAULT);
        System.out.print("its image path2 " + encodedImage);
        docimageencode_FRONT = encodedImage;
    }

    public void convertiInToBase64_BACK(File path, Uri tempUri) {
        Bitmap bms = null;
        try {
            bms = BitmapFactory.decodeStream(getContentResolver().openInputStream(tempUri));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        Bitmap bm = Bitmap.createScaledBitmap(bms, 937, 576, false);

//        Bitmap bm = BitmapFactory.decodeFile(String.valueOf(path));
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.JPEG, 100, baos); //bm is the bitmap object
        byte[] byteArrayImage = baos.toByteArray();
        String encodedImage = Base64.encodeToString(byteArrayImage, Base64.DEFAULT);
        System.out.print("its image path2 _BACK" + encodedImage);
        docimageencode_BACK = encodedImage;
    }

    public Uri getImageUri(Context inContext, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(inContext.getContentResolver(), inImage, "Title", null);
        return Uri.parse(path);
    }

    public String getRealPathFromURI(Uri uri) {

        File finalFile = new File(realPathUtil.getRealPath(RegisterVoteWithScanActivity.this, uri));
        return finalFile.toString();
    }

    boolean AskForPermissions() {
        // Here, thisActivity is the current activity
        if (ContextCompat.checkSelfPermission(RegisterVoteWithScanActivity.this, android.Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(RegisterVoteWithScanActivity.this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(RegisterVoteWithScanActivity.this, android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(RegisterVoteWithScanActivity.this, android.Manifest.permission.READ_EXTERNAL_STORAGE) == true
                    || ActivityCompat.shouldShowRequestPermissionRationale(RegisterVoteWithScanActivity.this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == true
                    || ActivityCompat.shouldShowRequestPermissionRationale(RegisterVoteWithScanActivity.this, android.Manifest.permission.CAMERA) == true) {
                DialogBox();

            } else {

                // No explanation needed, we can request the permission.

                ActivityCompat.requestPermissions(RegisterVoteWithScanActivity.this,
                        new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE, android.Manifest.permission.WRITE_EXTERNAL_STORAGE, android.Manifest.permission.CAMERA},
                        100);
            }
            return false;
        }
        return true;
    }

    public void DialogBox() {

        final Dialog dialog = new Dialog(RegisterVoteWithScanActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.contest_pop);

        Button settings = (Button) dialog.findViewById(R.id.settings);
        Button cancle = (Button) dialog.findViewById(R.id.cancle);
        cancle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

                startInstalledAppDetailsActivity();

            }
        });
        dialog.show();
    }

    public void startInstalledAppDetailsActivity() {

        final Intent i = new Intent();
        i.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        i.addCategory(Intent.CATEGORY_DEFAULT);
        i.setData(Uri.parse("package:" + getPackageName()));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        i.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
        i.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
        startActivity(i);
    }

    private void takePic() {

        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        file = new File(Environment.getExternalStorageDirectory(), "/DCIM" + "/photo_" + timeStamp + ".png");
        imageUri = FileProvider.getUriForFile(
                RegisterVoteWithScanActivity.this,
                "com.mersal.mersal.provider", file);
//        imageUri = Uri.fromFile(file);

        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
        startActivityForResult(intent, CAMERA_REQUEST_FRONT);
    }

    public Bitmap uriToBitmap(Context c, Uri uri) {
        if (c == null && uri == null) {
            return null;
        }
        try {
            return MediaStore.Images.Media.getBitmap(c.getContentResolver(), Uri.fromFile(file));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public Bitmap uriToBitmapBack(Context c, Uri uri) {
        if (c == null && uri == null) {
            return null;
        }
        try {
            return MediaStore.Images.Media.getBitmap(c.getContentResolver(), Uri.fromFile(fileBack));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    private void takeBackPic() {

        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        fileBack = new File(Environment.getExternalStorageDirectory(), "/DCIM" + "/photoback_" + timeStamp + ".png");
        imageUriBack = FileProvider.getUriForFile(
                RegisterVoteWithScanActivity.this,
                "com.mersal.mersal.provider", fileBack);
//        imageUri = Uri.fromFile(file);

        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUriBack);
        startActivityForResult(intent, CAMERA_REQUEST_BACK);
    }

    private void performCrop(int CROP_PIC, Uri picUri) {
        // take care of exceptions
        try {
            // call the standard crop action intent (the user device may not
            // support it)
            Intent cropIntent = new Intent("com.android.camera.action.CROP");
            // indicate image type and Uri
            cropIntent.setDataAndType(picUri, "image/*");
            // set crop properties
            // indicate aspect of desired crop
//            cropIntent.putExtra("aspectX", 1);
//            cropIntent.putExtra("aspectY", 1);
//            // indicate output X and Y
//            cropIntent.putExtra("outputX", 200);
//            cropIntent.putExtra("outputY", 300);
            cropIntent.putExtra("crop", "true");
            cropIntent.putExtra("outputX", 450);
            cropIntent.putExtra("outputY", 450);
            cropIntent.putExtra("scale", true);
            cropIntent.putExtra("scaleUpIfNeeded", true);//learn it from gallery2 source code
//            cropIntent.putExtra("max-width", 400);
//            cropIntent.putExtra("max-height", 400);

            // retrieve data on return
            cropIntent.putExtra("return-data", true);
            // start the activity - we handle returning in onActivityResult
            startActivityForResult(cropIntent, CROP_PIC);

        }
        // respond to users whose devices do not support the crop action
        catch (ActivityNotFoundException anfe) {
            Toast toast = Toast
                    .makeText(this, "This device doesn't support the crop action!", Toast.LENGTH_SHORT);
            toast.show();
        }
    }

    public static String getRealPathFromUri(Context context, Uri contentUri) {
        Cursor cursor = null;
        try {
            String[] proj = {MediaStore.Images.Media.DATA};
            cursor = context.getContentResolver().query(contentUri, proj, null, null, null);
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            cursor.moveToFirst();
            return cursor.getString(column_index);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    public String getDeviceName() {
        String manufacturer = Build.MANUFACTURER;
        String model = Build.MODEL;
        if (model.toLowerCase().startsWith(manufacturer.toLowerCase())) {
            return capitalize(model);
        } else {
            return capitalize(manufacturer) + " " + model;
        }
    }

    private String capitalize(String s) {
        if (s == null || s.length() == 0) {
            return "";
        }
        char first = s.charAt(0);
        if (Character.isUpperCase(first)) {
            return s;
        } else {
            return Character.toUpperCase(first) + s.substring(1);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        isClickForNext = false;

    }


}

