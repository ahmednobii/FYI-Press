package com.mersal.mersal.activites.electors;

import android.content.Intent;
import android.graphics.PorterDuff;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.Snackbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.signature.StringSignature;
import com.mersal.mersal.R;
import com.mersal.mersal.activites.base.BaseActivity;
import com.mersal.mersal.activites.editprofile.EditProfileActivity;
import com.mersal.mersal.adapter.ElectorsLvAdapter;
import com.mersal.mersal.customviews.HeaderCustomTV;
import com.mersal.mersal.customviews.NoDataFoundCustomTV;
import com.mersal.mersal.generic.Interfaces.Generic;
import com.mersal.mersal.internetconnections.NetworkConnection;
import com.mersal.mersal.retrofit.baseapi.ApiService;
import com.mersal.mersal.retrofit.baseapi.AppWebServices;
import com.mersal.mersal.retrofit.electors.Electorsdataelectors;
import com.mersal.mersal.retrofit.electorsdetails.ElectorDetailsResult;
import com.mersal.mersal.retrofit.votinglist.VotingElectionsResult;
import com.mersal.mersal.utilties.CircleTransform;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Map;

import io.realm.Realm;
import jp.wasabeef.picasso.transformations.CropCircleTransformation;
import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ElectorsDetailsActivity extends BaseActivity {

    TextView tv_unamedet, tv_six, tv_uname, tv_tafaseel;
    HeaderCustomTV toolbar_title;
    ProgressBar spinner;
    RelativeLayout rl_body;
    Generic generic;
    String fromPrevId = "";
    ImageView back_arrow, iv_profile;
    ArrayList<Electorsdataelectors> activitiesData = new ArrayList<>();
    public static ElectorsDetailsActivity objElectorsDetailsActivity;
    NetworkConnection ntobj = new NetworkConnection(ElectorsDetailsActivity.this);
    NoDataFoundCustomTV tv_noresult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_elector_details);

        if (ElectorsDetailsActivity.this instanceof BaseActivity) {
            generic = (Generic) ElectorsDetailsActivity.this;
        }
        generic.hideStatusBarForAuth();
        objElectorsDetailsActivity = this;
        init();
        clickListener();

        objectBAJava.hideKeyboard();

        Bundle extras = getIntent().getExtras();
        if (extras != null)
            fromPrevId = extras.getString("id");


        callApiFirsttime();
    }

    public void init() {
        toolbar_title = (HeaderCustomTV) findViewById(R.id.toolbar_title);
        back_arrow = (ImageView) findViewById(R.id.back_arrow);
        toolbar_title.setText("التفاصيل");
        iv_profile = (ImageView) findViewById(R.id.iv_profile);
        tv_unamedet = (TextView) findViewById(R.id.tv_unamedet);
        tv_tafaseel = (TextView) findViewById(R.id.tv_tafaseel);
        tv_six = (TextView) findViewById(R.id.tv_six);
        tv_uname = (TextView) findViewById(R.id.tv_uname);
        rl_body = (RelativeLayout) findViewById(R.id.rl_body);

        tv_uname.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_six.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_unamedet.setTypeface(objectBAJava.Tahoma_Regular_font);
        tv_tafaseel.setTypeface(objectBAJava.Tahoma_Regular_font);

        tv_noresult = (NoDataFoundCustomTV) findViewById(R.id.tv_noresult);
        Realm.init(this);    //initialize to access database for this activity
        realm = Realm.getDefaultInstance();
        spinner = (ProgressBar) findViewById(R.id.progressBar);
        spinner.setVisibility(View.GONE);
        back_arrow.setVisibility(View.VISIBLE);
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT) {
            spinner.getIndeterminateDrawable().setColorFilter(getResources()
                    .getColor(R.color.progress_bar_color_white), PorterDuff.Mode.SRC_IN);

        }
    }

    public void clickListener() {
        back_arrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                objectBAJava.hideStatusBar();
                finish();
                generic.animEnd();

            }
        });

    }

    public void apiCallElectorsList() {
        tv_noresult.setVisibility(View.GONE);
//        reqIsInProgress = true;

        activitiesData.clear();
        generic.showProgressBar(spinner);

        Map<String, String> params = generic.setBasicParams();
        params.put("auth_token", generic.getAuthTockenFromDb());
        params.put("elector_id", fromPrevId);
//        params.put("page_no", String.valueOf(page));
//        params.put("order", "asc");
//        params.put("order_by", "date");
//        params.put("keyword", "");


        OkHttpClient client = generic.setHeaderForReqs().build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(AppWebServices.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();

        ApiService service = retrofit.create(ApiService.class);
        Call<ElectorDetailsResult> call = service.electordetails(params);
        call.enqueue(new Callback<ElectorDetailsResult>() {

            @Override
            public void onResponse(Call<ElectorDetailsResult> call, retrofit2.Response<ElectorDetailsResult> response) {

                if (response.code() == 200) {

                    Boolean status = response.body().getstatus();
                    String Message = response.body().getMessage();

                    if (status) {

                        generic.hideProgressBar(spinner);
                        rl_body.setVisibility(View.VISIBLE);
                        tv_noresult.setVisibility(View.GONE);

                        String fullname = response.body().getdata().getelectors().getfull_name();
                        String moredetails = response.body().getdata().getelectors().getmore_detail();

//                        Glide.with(ElectorsDetailsActivity.this)
//                                .load(response.body().getdata().getelectors().getimage_url())
//                                .placeholder(R.drawable.profile_icon)
//                                .error(R.drawable.profile_icon)
//                                .into(iv_profile);

//                        Glide.with(ElectorsDetailsActivity.this)
//                                .load(response.body().getdata().getelectors().getimage_url())
//                                .override(600, 200) // resizes the image to these dimensions (in pixel). resize does not respect aspect ratio
//                                .error(R.drawable.profile_icon)
//                                .transform(new CircleTransform(ElectorsDetailsActivity.this))
//                                .into(iv_profile);

                        Picasso.get()
                                .load(response.body().getdata().getelectors().getimage_url())
                                .resize(100, 100)
                                .transform(new CropCircleTransformation())
                                .placeholder(R.drawable.profile_icon)
                                .error(R.drawable.profile_icon)
                                .into(iv_profile);

                        tv_unamedet.setText(fullname);
                        tv_six.setText(moredetails);

                    } else {
                        generic.hideProgressBar(spinner);
                        if (activitiesData.size() == 0) {
                            tv_noresult.setVisibility(View.VISIBLE);
                            rl_body.setVisibility(View.GONE);
                        }

                        Snackbar snackbar = Snackbar.make(rl_body, Message, Snackbar.LENGTH_LONG);
                        snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
                        snackbar.show();
                    }

                } else {
                    generic.hideProgressBar(spinner);
                    try {

                        if (activitiesData.size() == 0) {
                            tv_noresult.setVisibility(View.VISIBLE);
                            rl_body.setVisibility(View.GONE);
                        }

//                        spinner.setVisibility(View.GONE);
                        generic.hideProgressBar(spinner);

                        String userMessage = PreferenceManager.getDefaultSharedPreferences(ElectorsDetailsActivity.this).getString("oops", "هناك خطأ ما");
                        JSONObject jObjError = new JSONObject(response.errorBody().string());
                        try {
                            userMessage = jObjError.getString("message");
                        } catch (Exception e) {
                        }

                        String dataArrayMessage = "";
                        try {
                            JSONArray jsonArray = jObjError.getJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                dataArrayMessage = dataArrayMessage + jsonArray.getString(i) + "\n";
                            }

                        } catch (Exception e) {
                        }


                        String maintenanceBtnText = "Try Again";
                        try {
                            maintenanceBtnText = jObjError.optString("btn_text");
                        } catch (Exception e) {
                        }

                        generic.genericCodes(rl_body, response.code(), userMessage, dataArrayMessage, maintenanceBtnText);

                    } catch (Exception e) {

//                        spinner.setVisibility(View.GONE);
                        generic.hideProgressBar(spinner);
                        if (activitiesData.size() == 0) {
                            tv_noresult.setVisibility(View.VISIBLE);
                            rl_body.setVisibility(View.GONE);
                        }

                        Snackbar snackbar = Snackbar.make(rl_body, PreferenceManager.getDefaultSharedPreferences(ElectorsDetailsActivity.this).getString("oops", "هناك خطأ ما"), Snackbar.LENGTH_LONG);
                        snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
                        snackbar.show();

                    }
                }
            }

            @Override
            public void onFailure(Call<ElectorDetailsResult> call, Throwable t) {
//                spinner.setVisibility(View.GONE);
                generic.hideProgressBar(spinner);

                Snackbar snackbar = Snackbar.make(rl_body, PreferenceManager.getDefaultSharedPreferences(ElectorsDetailsActivity.this).getString("oops", "هناك خطأ ما"), Snackbar.LENGTH_LONG);
                snackbar.getView().setBackgroundColor(getResources().getColor(R.color.snack_bar_red));
                snackbar.show();

                if (activitiesData.size() == 0) {
                    tv_noresult.setVisibility(View.VISIBLE);
                    rl_body.setVisibility(View.GONE);
                }
            }
        });
    }

    public void callApiFirsttime() {

        if (ntobj.isConnectingToInternet()) {
            rl_body.setVisibility(View.GONE);
            objectBAJava.hideKeyboard();
            activitiesData.clear();
            generic.showProgressBar(spinner);
            apiCallElectorsList();
        } else {
            String Message = PreferenceManager.getDefaultSharedPreferences(ElectorsDetailsActivity.this).getString("no_connection", "لا يوجد اتصال , تفحص الانترنت و حاول مرة اخرى");
            generic.showSnackbar(tv_noresult, Message, Snackbar.LENGTH_LONG, "close", false);
            tv_noresult.setVisibility(View.VISIBLE);
            generic.hideProgressBar(spinner);
            rl_body.setVisibility(View.GONE);
            activitiesData.clear();
        }
    }

    public void goOnActivity(String id) {
        Intent intent = new Intent(ElectorsDetailsActivity.this, ElectorsDetailsActivity.class);
        intent.putExtra("id", id);
        startActivity(intent);
        ElectorsDetailsActivity.this.overridePendingTransition(R.anim.start_slide_in_left, R.anim.start_slide_out_left);
    }

}
